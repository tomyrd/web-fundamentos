#include <stdio.h>

int main (int argc, char* argv[]) {
    printf("Se recibieron %i argumentos\n\n", argc);
    for(int i = 0; i < argc; i++) {
        printf("Argumento %i: %s\n", i, argv[i]);
    }
}