#include <stdio.h>

const int ERROR = -1;

#define MAX_PALABRA 100

int main () {

    FILE* los_simpsons = fopen("los_simpsons.txt", "r");

    if (!los_simpsons) {
        printf("Error al abrir el archivo\n");
        return ERROR;
    }

    char palabra[MAX_PALABRA];

    int leido = fscanf(los_simpsons, "%s", palabra);
    while(leido != EOF) {
        printf("%s\n", palabra);
        leido = fscanf(los_simpsons, "%s", palabra);
    }

    fclose(los_simpsons);
    
    return 0;
}