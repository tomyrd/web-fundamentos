#include <stdio.h>

const int ERROR = -1;

#define MAX_LINEA 1000

int main () {

    FILE* los_simpsons = fopen("los_simpsons.txt", "r");

    if (!los_simpsons) {
        printf("Error al abrir el archivo\n");
        return ERROR;
    }

    char linea[MAX_LINEA];

    int leido = fscanf(los_simpsons, "%[^\n]\n", linea);
    while(leido != EOF) {
        printf("%s\n\n", linea);
        leido = fscanf(los_simpsons, "%[^\n]\n", linea);
    }

    fclose(los_simpsons);

    return 0;
}