#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "munieca.h"

#define ARCH_MUNIECAS "muniecas.csv"
#define ARCH_FRASES "frases_muniecas.csv"
#define ARCH_FRASES_LISA "frases_lisa.txt"
#define COMANDO_FILTRAR "filtrar"
#define FORMATO_MUNIECAS "%i;%[^\n]\n"
#define FORMATO_FRASE "%i;%[^;];%c\n"
#define MAX_FRASE 500
#define MAX_PALABRA 40
#define MAX_PALABRAS_PROHIBIDAS 2
#define NOMBRE_MUNIECA_LISA "Lisa Corazón de León"

const char* PALABRAS_PROHIBIDAS[2] = {"chica", "tonta"};

const int NO_ENCONTRADO = -1; 
const int ERROR = -1; 
const char NO_REGISTRADO = 'F';
const int CANT_ARGS_ESPERADA = 3;
const int POS_COMANDO = 1;
const int POS_PALABRA_FILTRAR = 2;

// Pre: recibe etc
// Post: devuelve -1 si no encuentra a la munieca
int id_munieca(char nombre[MAX_NOMBRE]){
    FILE* arch_muniecas = fopen(ARCH_MUNIECAS, "r");
    if(!arch_muniecas) {
        printf("No se pudo abrir el archivo de muñecas\n");
        return NO_ENCONTRADO;
    }

    int id;
    int id_munieca = NO_ENCONTRADO;
    char nombre_leido[MAX_NOMBRE];
    bool encontrado = false;

    int leido = fscanf(arch_muniecas, FORMATO_MUNIECAS, &id, nombre_leido);

    while(leido != EOF && !encontrado){
        if(strcmp(nombre, nombre_leido) == 0){
            encontrado = true;
            id_munieca = id;
        }
        leido = fscanf(arch_muniecas, FORMATO_MUNIECAS, &id, nombre_leido);
    }

    fclose(arch_muniecas);
    return id_munieca;
}

bool frase_valida(char frase[MAX_FRASE], char registrado){
    bool tiene_palabra_prohibida = false;

    for(int i = 0; i < MAX_PALABRAS_PROHIBIDAS; i++){
        // el strstr se fija si el primer string contiene el segundo string 
        tiene_palabra_prohibida = strstr(frase, PALABRAS_PROHIBIDAS[i]) != NULL;
    }

    return registrado == NO_REGISTRADO && !tiene_palabra_prohibida;
}

// PRE: `munieca` fue creado usando munieca_crear().
// POST: devuelve -1 si no pudo abrir el archivo o si hubo un error agregando una frase a la muñeca. Devuelve 0 si sale todo ok :)
int cargar_frases(munieca_t* munieca){
    FILE* arch_frases = fopen(ARCH_FRASES, "r");
    if(!arch_frases){
        printf("No se pudo abrir el archivo de frases\n");
        return ERROR;
    }

    int id;
    char frase[MAX_FRASE];
    char registrado;
    bool se_puede_agregar = true;

    int leido = fscanf(arch_frases, FORMATO_FRASE, &id, frase, &registrado);

    while(leido != EOF && se_puede_agregar){
        if(id == munieca->id && frase_valida(frase, registrado)){
            se_puede_agregar = agregar_frase(munieca, frase);
        }
        leido = fscanf(arch_frases, FORMATO_FRASE, &id, frase, &registrado);
    }

    if(!se_puede_agregar){
        printf("No se pudo agregar la frase\n");
        fclose(arch_frases);
        return ERROR;
    }

    fclose(arch_frases);
    return 0;
}

// POST etcs
int descargar_frases(munieca_t* munieca){
    FILE* arch_frases_lisa = fopen(ARCH_FRASES_LISA, "w");
    if(!arch_frases_lisa){
        printf("Error al abrir el archivos de las frases de lisa\n");
        return ERROR;
    }

    char* frase = sacar_frase(munieca);
    while(frase){
        fprintf(arch_frases_lisa, "%s\n", frase);
        free(frase);
        frase = sacar_frase(munieca);
    }

    fclose(arch_frases_lisa);
    return 0;

}

int filtrar_palabras(munieca_t* munieca, char palabra_filtrar[MAX_PALABRA]){
    munieca_t* munieca_aux = munieca_crear(munieca->id, munieca->nombre);
    
    if(!munieca_aux){
        printf("No se pudo crear la muñeca auxiliar\n");
        return ERROR;
    }

    bool se_puede_agregar_aux = true;
    char* frase_aux = sacar_frase(munieca);
    while(frase_aux && se_puede_agregar_aux){
        if(!strstr(frase_aux, palabra_filtrar)){
            se_puede_agregar_aux = agregar_frase(munieca_aux, frase_aux);
        }
        free(frase_aux);
        frase_aux = sacar_frase(munieca);
    }

    // paso frases de la aux a la original
    bool se_puede_agregar = true;
    char* frase = sacar_frase(munieca_aux);
    while(frase && se_puede_agregar){
        se_puede_agregar = agregar_frase(munieca, frase);
        free(frase);
        frase = sacar_frase(munieca_aux);
    }

    liberar_munieca(munieca_aux);

}

int main(int argc, char* argv[]) {
    char palabra_filtrar[MAX_PALABRA] = "";
    if(argc == CANT_ARGS_ESPERADA){
        if(strcmp(argv[POS_COMANDO], COMANDO_FILTRAR) == 0){
            strcpy(palabra_filtrar, argv[POS_PALABRA_FILTRAR]);
        }
    }

    int id_lisa = id_munieca(NOMBRE_MUNIECA_LISA);

    if(id_lisa == NO_ENCONTRADO){
        printf("No está la muñeca en el archivo\n");
        return 1;
    }

    munieca_t* munieca_lisa = munieca_crear(id_lisa, NOMBRE_MUNIECA_LISA);

    if(!munieca_lisa){
        printf("No se pudo crear la muñeca\n");
        return 1;
    }

    cargar_frases(munieca_lisa);

    if(strcmp(palabra_filtrar, "") != 0){
        filtrar_palabras(munieca_lisa, palabra_filtrar);
    }

    descargar_frases(munieca_lisa);

    liberar_munieca(munieca_lisa);

    return 0;
}
