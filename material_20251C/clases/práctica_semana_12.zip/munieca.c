#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "munieca.h"


// Post: Crea un TDA muñeca. Devuelve un puntero a una muñeca.
//      Al terminar de usarlo debe ser destruido con vec_destruir().
//   	Devuelve NULL si no se pudo crear.
munieca_t* munieca_crear(int id, char* nombre) {
    munieca_t* munieca = malloc(sizeof(munieca_t));
    if (!munieca) return NULL;

    munieca->id = id;
    strcpy(munieca->nombre, nombre);
    munieca->frases = NULL;
    munieca->cantidad_frases = 0;

    return munieca;
}


// Pre: `munieca` fue creado usando munieca_crear().
// Post: Agrega una frase al principio del vector de frases de la munieca, moviendo las frase hacia la derecha.
//   	Devuelve true si se pudo agregar, false en caso contrario.
bool agregar_frase(munieca_t* munieca, char* frase){
    if (!munieca || !frase) return false;

    char** nuevo_vector = realloc(munieca->frases, (munieca->cantidad_frases + 1) * sizeof(char*));
    if (!nuevo_vector) return false;

    munieca->frases = nuevo_vector;
    for (int i = munieca->cantidad_frases; i > 0; i--) {
        munieca->frases[i] = munieca->frases[i - 1];
    }

    munieca->frases[0] = malloc(strlen(frase) + 1);
    if (!munieca->frases[0]) return false;
    strcpy(munieca->frases[0], frase);

    munieca->cantidad_frases++;
    return true;
}


// Pre: `munieca` fue creado usando munieca_crear().
// Post: Devuelve la última frase del vector de frases de la munieca, quitándola del vector.
char* sacar_frase(munieca_t * munieca) {
    if (!munieca || munieca->cantidad_frases == 0) return NULL;

    char* ultima_frase = munieca->frases[munieca->cantidad_frases - 1];
    munieca->cantidad_frases--;

    if (munieca->cantidad_frases > 0) {
        char** nuevo_vector = realloc(munieca->frases, munieca->cantidad_frases * sizeof(char*));
        if (nuevo_vector) {
            munieca->frases = nuevo_vector;
        } else {
            free(ultima_frase);
        }
    } else {
        free(munieca->frases);
        munieca->frases = NULL;
    }

    return ultima_frase;
}

// Pre: `munieca` fue creado usando munieca_crear().
// Post: Destruye la muñeca creada.
void liberar_munieca(munieca_t* munieca) {
    if (!munieca) return;

    for (int i = 0; i < munieca->cantidad_frases; i++) {
        free(munieca->frases[i]);
    }
    free(munieca->frases);
    free(munieca);
    munieca = NULL;
}
