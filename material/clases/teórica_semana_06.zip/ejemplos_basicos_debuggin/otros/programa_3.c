#include <stdio.h>

int main() {
    int *ptr;
    *ptr = 5;
    
    return 0;
}