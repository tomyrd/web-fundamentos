#include<stdio.h>



int main (){
    int numero = 84;
    float otro_numero = 84;
    // Casteo implicito
    float numero_casteado_a_float = (float) numero;
    // Casteo explicito
    char numero_casteado_a_char = (char) numero;

    return 0;
}
