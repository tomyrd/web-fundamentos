#include <stdio.h>

int main() {
    int a = 10;
    int b = 10 - a;
    int c = a / b;

    printf("Resultado: %d\n", c);

    return 0;
}
