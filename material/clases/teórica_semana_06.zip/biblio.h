#define MAX_NOMBRE 31
#define MAX_CASAS 20

typedef struct casa
{
    char direccion[MAX_NOMBRE];
    int cant_plata;
    int cant_caramelos;
} casa_t;

void inicializar_casas(casa_t casas[MAX_CASAS], int* tope_casas);

int caramelos_vendidos(casa_t casas[MAX_CASAS], int tope_casas, int caramelos_acumulados, int plata_acumulada, int i);
