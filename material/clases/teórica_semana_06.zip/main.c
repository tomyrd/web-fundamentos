#include<stdio.h>
#include"biblio.h"

int main(){
	casa_t casas[MAX_CASAS];
    int tope_casas = 0;
	inicializar_casas(casas, &tope_casas);

    int numero = 0;
    printf("ingrese un numero:");
    scanf("%i", &numero);

    printf("La cantidad de caramelos a vender es: %i\n", caramelos_vendidos(casas, tope_casas, 0, 0, 0));

    int cant_caramelos = 0;
    int cant_plata = 0;
    for (int i = 0; i < tope_casas; i++){
       cant_caramelos += casas[i].cant_caramelos;
       cant_plata += casas[i].cant_plata;
    }

    printf("cant caramelos: %i y cant plata: %i\n", cant_caramelos, cant_plata);

	return 0;
}
