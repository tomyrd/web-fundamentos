#include <stdio.h>
#include <stdlib.h>

typedef struct alumno {
    char* nombre;
    char* apellido;
    int padron;
} alumno_t;


/* Pre condiciones: El parámetro 'descripcion' tiene que ser un string (finalizar con '\0').
 * Post condiciones: Solicita al usuario mostrando por pantalla 'descripcion' y devuelve por referencia un valor entero mayor a 0.
 */
void pedir_cantidad_natural(int* cantidad, char descripcion[]) {
    printf("%s\n", descripcion);
    scanf("%i", cantidad);

    while((*cantidad) <= 0) {
        printf("Cantidad ingresada inválida. Ingrese un valor entero positivo\n%s\n", descripcion);
        scanf("%i", cantidad);
    }
}


int main () {
    alumno_t alumno;
    int cantidad_letras_nombre = 0;
    int cantidad_letras_apellido = 0;

    pedir_cantidad_natural(&cantidad_letras_nombre, "¿Cuántas letras tiene su nombre?");
    char* nombre_heap = malloc((cantidad_letras_nombre + 1) * sizeof(char));
    if (!nombre_heap){
        printf("Hubo un problema con el malloc\n");
        return -1;
    }

    pedir_cantidad_natural(&cantidad_letras_apellido, "¿Cuántas letras tiene su apellido?");
    char* apellido_heap = malloc((cantidad_letras_apellido + 1) * sizeof(char));
    //Si falla el malloc y salgo, no debo olvidarme de liberar la memoria que ya reservé
    if (!apellido_heap){
        free(nombre_heap);
        printf("Hubo un problema con el malloc\n");
        return -1;
    }

    alumno.nombre = nombre_heap;
    alumno.apellido = apellido_heap;

    printf("Ingrese su nombre y apellido\n");
    scanf(" %s %s", alumno.nombre, alumno.apellido);

    pedir_cantidad_natural(&(alumno.padron), "¿Cuál es su padrón?");
    printf("El padrón %i corresponde al alumno %s %s\n", alumno.padron, alumno.nombre, alumno.apellido);

    free(alumno.apellido);
    free(alumno.nombre);
    
    free(apellido_heap);
    free(nombre_heap);
    

    return 0;
}

