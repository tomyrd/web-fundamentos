#include <stdio.h>
#include <stdbool.h>

const int PRECIO_CHUPETIN = 100;
const int PRECIO_CARAMELO = 30;
const int PRECIO_CHICLE = 50;
const int PRECIO_BOLSA_ROSA = 40;
const int PRECIO_BOLSA_CELESTE = 50;
const int PRECIO_BOLSA_VERDE = 20;
const char BOLSA_ROSA = 'R';
const char BOLSA_CELESTE = 'C';
const char BOLSA_VERDE = 'V';

// pre: -
// post: pide al usuario la cantidad de chupetines que desea comprar, y la guarda en la variable 
void preguntar_cant_chupetin(int* cant_chupetin){
    printf("Ingrese la cantidad de chupetines que desea comprar: ");
    scanf("%i", cant_chupetin);
}

// pre: -
// post: pide al usuario la cantidad de caramelos que desea comprar, y la guarda en la variable
void preguntar_cant_caramelo(int* cant_caramelo){
    printf("Ingrese la cantidad de caramelos que desea comprar: ");
    scanf("%i", cant_caramelo);
}

// pre: -
// post: pide al usuario la cantidad de chicles que desea comprar, y la guarda en la variable
void preguntar_cant_chicle(int* cant_chicle){
    printf("Ingrese la cantidad de chicles que desea comprar: ");
    scanf("%i", cant_chicle);
}

// pre: -
// post: devuelve true si el tipo de bolsa es R, C o V, false en caso contrario
bool es_bolsa_valida(char tipo_bolsa){
    return (tipo_bolsa == BOLSA_ROSA || tipo_bolsa == BOLSA_CELESTE || tipo_bolsa == BOLSA_VERDE);
}

// pre: -
// post: pide al usuario el tipo de bolsa que desea comprar, y lo guarda en la variable. El tipo de bolsa será R, C o V
void preguntar_tipo_bolsa(char* tipo_bolsa){
    printf("Ingrese el tipo de bolsa que desea comprar (A: bolsa de chupetines, B: bolsa de caramelos, C: bolsa de chicles): ");
    scanf(" %c", tipo_bolsa);
    while(!es_bolsa_valida(*tipo_bolsa)){
        printf("El tipo de bolsa ingresado no es válido. Ingrese un tipo de bolsa válido (A: bolsa de chupetines, B: bolsa de caramelos, C: bolsa de chicles): ");
        scanf(" %c", tipo_bolsa);
    }
}

// pre: las cantidades deben ser números positivos
// post: devuelve el gasto total en golosinas
int gasto_golosinas(int cant_chupetin, int cant_caramelo, int cant_chicle){
    return ((cant_chupetin * PRECIO_CHUPETIN) + (cant_caramelo * PRECIO_CARAMELO) + (cant_chicle * PRECIO_CHICLE));
}

// pre: las cantidades deben ser números positivos
// post: devuelve el gasto total en golosinas y bolsa
int gasto_total(int cant_chupetin, int cant_caramelo, int cant_chicle, char tipo_bolsa){
    int precio_total = 0;
    precio_total = gasto_golosinas(cant_chupetin, cant_caramelo, cant_chicle);
    if(tipo_bolsa == BOLSA_ROSA){
        precio_total += PRECIO_BOLSA_ROSA;
    } else if(tipo_bolsa == BOLSA_CELESTE){
        precio_total += PRECIO_BOLSA_CELESTE;
    } else if(tipo_bolsa == BOLSA_VERDE){
        precio_total += PRECIO_BOLSA_VERDE;
    }

    return precio_total;
}

int main(){
    int cant_chupetin;
    int cant_caramelo;
    int cant_chicle;
    char tipo_bolsa;
    preguntar_cant_chupetin(&cant_chupetin);
    preguntar_cant_caramelo(&cant_caramelo);
    preguntar_cant_chicle(&cant_chicle);
    preguntar_tipo_bolsa(&tipo_bolsa);
    printf("El gasto total para el invitado es de $%i\n", gasto_total(cant_chupetin, cant_caramelo, cant_chicle, tipo_bolsa));
    return 0;
}