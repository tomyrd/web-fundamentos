#include <stdio.h>
#include <stdbool.h>

const char CALIDAD_EXCELENTE = 'E';
const char CALIDAD_ESTANDAR = 'N';
const char CALIDAD_BAJA = 'B';

bool es_calidad_valida(char calidad) {
    return (calidad == CALIDAD_EXCELENTE || calidad == CALIDAD_ESTANDAR || calidad == CALIDAD_BAJA);
}

/*
    pre: -
    post: pide la calidad y la guarda, puede ser E, N o B 
*/
void preguntar_calidad(char* calidad){
    printf("Que calidad queres las ruedas???? (opciones N, E o B)\n");
    scanf(" %c", calidad);
    while(!es_calidad_valida(*calidad)){
        printf("Nooooo, poneme N, E o B. Que calidad queres las ruedas????\n");
        scanf(" %c", calidad);
    }
}


int main(){
    char calidad_rueda;
    preguntar_calidad(&calidad_rueda);
    return 0;
}