#include <stdio.h>
#include <stdbool.h>

const int NOTA_MINIMA_APROBADO = 4;
const int NOTA_MAXIMA = 10;
const int NOTA_MINIMA = 1;
const char OPINION_ME_ENCANTO = 'E';
const char OPINION_BIEN = 'B';
const char OPINION_ODIO = 'O';
const char OPINION_NO_HECHA = 'N';

// pre: -
// post: devuelve true si la nota esta aprobada, o sea está entre 4 y 10, false en caso contrario
bool es_nota_aprobada(int nota){
    return (nota >= NOTA_MINIMA_APROBADO && nota <= NOTA_MAXIMA);
}

// pre: -
// post: devuelve true si la nota está entre 1 y 10, false en caso contrario
bool es_nota_valida(int nota){
    return (nota >= NOTA_MINIMA && nota <= NOTA_MAXIMA);
}

// pre: -
// post: pide al usuario la nota de fisica, y la guarda en la variable nota. La nota estará entre 1 y 10
void preguntar_nota_fisica(int* nota){
    printf("Ingrese la nota de fisica (entre 1 y 10): ");
    scanf("%i", nota);
    while(!es_nota_valida(*nota)){
        printf("La nota ingresada no es válida. Ingrese una nota entre 1 y 10: ");
        scanf("%i", nota);
    }
}

// pre: -
// post: devuelve true si la opinion es E, B, O o N, false en caso contrario
bool es_opinion_valida(char opinion){
    return (opinion == OPINION_ME_ENCANTO || opinion == OPINION_BIEN || opinion == OPINION_ODIO || opinion == OPINION_NO_HECHA);
}

// pre: -
// post: pide al usuario su opinión sobre la materia fisica, y la guarda en la variable opinion. La opinion será E, B, O o N
void preguntar_opinion(char* opinion){
    printf("Ingrese su opinión sobre la materia fisica (E: me encanto, B: estuvo bien, O: la odie, N: no la hice todavía): ");
    scanf(" %c", opinion);
    while(!es_opinion_valida(*opinion)){
        printf("La opinión ingresada no es válida. Ingrese una opinión válida (E: me encanto, B: estuvo bien, O: la odie, N: no la hice todavía): ");
        scanf(" %c", opinion);
    }
}

// pre: nota debe contener un valor entre 0 y 10 inclusives y opinion un valor valido que puede ser OPINION_ME_ENCANTO, OPINION_BIEN, OPINION_ODIO u OPINION_NO_HECHA
// post: devuelve true si la nota es aprobada y la opinion es E o B, false en caso contrario
bool esta_de_acuerdo(int nota, char opinion){
    return (es_nota_aprobada(nota) && (opinion == OPINION_ME_ENCANTO || opinion == OPINION_BIEN));
}

int main(){
    int nota_fisica;
    char opinion;
    preguntar_nota_fisica(&nota_fisica);
    preguntar_opinion(&opinion);
    if(esta_de_acuerdo(nota_fisica, opinion)){
        printf("El colab está de acuerdo con la cambiar la temática.\n");
    }else{
        printf("El colab no está de acuerdo con cambiar la temática\n");
    }
    return 0;

}