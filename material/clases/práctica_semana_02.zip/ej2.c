#include <stdio.h>
#include <stdbool.h>

const int PUNTAJE_MAX = 10;
const int PUNTAJE_MIN = 1;
const int HORA_MIN = 0;
const int HORA_MAX = 23;
const float MINUTO_MIN = 0.0;
const float MINUTO_MAX = 0.59;
const int HORA_INVALIDA = -1;
const float MINUTOS_INVALIDOS = -0.1;
const int HORA_LUIGI_MIN = 20;
const int HORA_LUIGI_MAX = 22;
const float MINUTO_LUIGI_MIN = 0.0;
const float MINUTO_LUIGI_MAX = 0.59;

#define MAX_PUNTAJES 50

bool es_puntaje_valido(int puntaje){
    return puntaje >= PUNTAJE_MIN && puntaje <= PUNTAJE_MAX;
}

void preguntar_puntaje(int* puntaje){
    printf("Que puntaje le pones al plato???? Tiene que estar entre 1 y 10\n");
    scanf("%i", puntaje);
    while(!es_puntaje_valido(*puntaje)){
        printf("Ese valor es incorrecto. Que puntaje le pones al plato???? Tiene que estar entre 1 y 10\n");
        scanf("%i", puntaje);
    }
}

void separar_horas(float horario, int* hora, float* minutos){
    (*hora) = (int)horario;
    (*minutos) = horario - (*hora);
}

bool es_hora_valida(float horario, int hora_min, int hora_max, float minutos_min, float minutos_max){
    int hora = HORA_INVALIDA;
    float minutos = MINUTOS_INVALIDOS;
    separar_horas(horario, &hora, &minutos);
    bool hora_valida = hora >= hora_min && hora <= hora_max;
    bool mins_valido = minutos >= minutos_min && minutos <= minutos_max;
    return hora_valida && mins_valido;
}

void preguntar_hora(float* horario){
    printf("Que hora fuiste al resto???? Tiene que estar entre 00.00 y 23.59\n");
    scanf("%.2f", horario);
    while(!es_hora_valida(*horario, HORA_MIN, HORA_MAX, MINUTO_MIN, MINUTO_MAX)){
        printf("Nooo, esa hora no existe. Que hora fuiste al resto???? Tiene que estar entre 00.00 y 23.59\n");
        scanf("%.2f", horario);
    }
}

bool es_horario_luigi(float horario){
    return es_hora_valida(horario, HORA_LUIGI_MIN, HORA_LUIGI_MAX - 1, MINUTO_LUIGI_MIN, MINUTO_LUIGI_MAX) || horario == (float)HORA_LUIGI_MAX;
}

void agregar_puntaje(int puntajes[MAX_PUNTAJES], int* tope_puntajes, float horario, int puntaje){
    if(es_horario_luigi(horario)){
        puntajes[(*tope_puntajes)] = puntaje;
        (*tope_puntajes)++;
    }
}

int main(){
    int puntajes[MAX_PUNTAJES];
    int tope_puntajes = 0;
    int puntaje = 0;
    float horario = -0.1;

    preguntar_puntaje(&puntaje);
    preguntar_hora(&horario);

    agregar_puntaje(puntajes, &tope_puntajes, horario, puntaje);
    
    return 0;
}