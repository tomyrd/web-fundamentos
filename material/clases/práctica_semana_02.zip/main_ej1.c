#include <stdio.h>
#define MAX 20

//pre: El valor de tope debe ser mayor a cero y menor al máximo (MAX)
//post: Imprime el vector recibido por parametro
void imprimir_vector(int vector[MAX], int tope){
	for (int i = 0; i < tope; i++){
		printf("%i ", vector[i]);
	}
	printf("\n");
}


//pre: El valor de tope debe ser mayor a cero y menor al máximo (MAX)
//post: Devuelve el promedio 
float promedio(int vector[MAX], int tope){
	float suma = 0;
	for( int i=0 ; i<tope ; i++ ){
		suma += vector[i];
	}
	return suma/tope;
}

int main()
{
	int puntajes[MAX] = {8, 8, 7, 8, 5};
	int tope_puntajes = 5;



	imprimir_vector(puntajes, tope_puntajes);
	printf("el promedio del primer vector es: 7.2\n");

	int calificaciones[MAX] = {10, 10, 9};
	int tope_calificaciones = 3;
	imprimir_vector(calificaciones, tope_calificaciones);
	printf("el promedio del primer vector es: 9.66\n");

	

	float primer_promedio = promedio(vector, tope);
	float segundo_promedio = promedio(otro_vector, otro_tope);

	printf("El primer promedio vale: %.2f\nEl segundo promedio vale: %.2f\n", primer_promedio, segundo_promedio);

	

	return 0;
}