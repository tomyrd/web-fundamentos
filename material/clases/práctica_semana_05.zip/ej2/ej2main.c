#include "inventario.h"

int main(){

    inventario_t inventario;
    inventario.tope_baules = 0;

    char nombre_baul[MAX_NOMBRE];
    strcpy(nombre_baul, "Baul 1");
    agregar_baul(&inventario, nombre_baul);

    char nombre_baul2[MAX_NOMBRE];
    strcpy(nombre_baul2, "Baul 2");
    agregar_baul(&inventario, nombre_baul2);

    juguete_t juguete1;
    strcpy(juguete1.nombre, "Buzz Lightyear");
    juguete1.anio_comprado = 2000;
    juguete1.valor = 1000;
    strcpy(juguete1.tipo, "Electronico");

    juguete_t juguete2;
    strcpy(juguete2.nombre, "Minion");
    juguete2.anio_comprado = 2024;
    juguete2.valor = 500000;
    strcpy(juguete2.tipo, "Plastico");

    juguete_t juguete3;
    strcpy(juguete3.nombre, "Cara de papa");
    juguete3.anio_comprado = 1996;
    juguete3.valor = 10;
    strcpy(juguete3.tipo, "Plastico");

    juguete_t juguete4;
    strcpy(juguete4.nombre,"Nintendo Switch 65");
    juguete4.anio_comprado = 2024;
    juguete4.valor = 300;
    strcpy(juguete4.tipo, "Electronico");

    juguete_t juguete5;
    strcpy(juguete5.nombre,"Barbie Informatica");
    juguete5.anio_comprado = 2024;
    juguete5.valor = 300;
    strcpy(juguete5.tipo, "Electronico");

    agregar_juguete(&inventario, juguete1);
    agregar_juguete(&inventario, juguete2);
    agregar_juguete(&inventario, juguete3);
    
    contar_juguetes_por_tipo(inventario);

    juguete_t juguetes_a_vender[MAX_JUGUETES];
    int tope_juguetes_a_vender = 0;

    calcular_juguetes_a_vender(inventario, juguetes_a_vender, &tope_juguetes_a_vender);
}