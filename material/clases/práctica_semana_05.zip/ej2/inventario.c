#include "inventario.h"

#define ELECTRONICO "Electronico"
#define PLASTICO "Plastico"
#define PELUCHE "Peluche"

const int ANIO_ACTUAL = 2024;
const int MINIMA_ANTIGUEDAD_VALIDA = 10;

// Pre: nuevo_juguete debe ser un juguete inicializado. inventario está correctamente inicializado.
// Pos: Se agrega el juguete al baúl con menos juguetes y se muestra un mensaje con la etiqueta del baúl al que fue agregado.
void agregar_juguete(inventario_t* inventario, juguete_t nuevo_juguete){
    if(inventario->tope_baules == 0){
        printf("Che no tenes bauleeessss\n");
        return;
    }

    int indice_menor = 0;
    int menor_tope_juguetes = inventario->baules[indice_menor].tope_juguetes;
    for (int i = 1; i < inventario->tope_baules; i++){
        if (inventario->baules[i].tope_juguetes < menor_tope_juguetes){
            menor_tope_juguetes = inventario->baules[i].tope_juguetes;
            indice_menor = i;
        } 
    }

    inventario->baules[indice_menor].juguetes[inventario->baules[indice_menor].tope_juguetes] = nuevo_juguete;
    inventario->baules[indice_menor].tope_juguetes++;
    printf("Agregamos juguete al Baul: %s\n", inventario->baules[indice_menor].etiqueta);
}

// Pre: inventario debe estar inicializado y los tipos de los juguetes deben ser “Electrónico", "Peluche", o "Plástico"
// Pos: Se cuentan y muestran la cantidad de cada tipo de juguete por pantalla.
void contar_juguetes_por_tipo(inventario_t inventario){
    int cant_electronicos = 0, cant_peluche = 0, cant_plastico = 0;

    for (int i = 0; i < inventario.tope_baules; i++){
        for (int j = 0; j < inventario.baules[i].tope_juguetes; j++){
            juguete_t juguete = inventario.baules[i].juguetes[j];
            if(strcmp(juguete.tipo, ELECTRONICO) == 0){
                cant_electronicos++;
            }else if(strcmp(juguete.tipo, PLASTICO) == 0){
                cant_plastico++;
            }else{
                cant_peluche++;
            }
        }    
    }

    printf("Cant electronicos: %i\n", cant_electronicos);
    printf("Cant plastico: %i\n", cant_plastico);
    printf("Cant peluche: %i\n", cant_peluche);
}

// Pre: inventario debe estar correctamente inicializado.
// Pos: Crea un nuevo baúl vacío para guardar juguetes con la etiqueta que recibe.
void agregar_baul(inventario_t* inventario, char etiqueta[MAX_NOMBRE]){
    if(inventario->tope_baules < MAX_BAULES){
        strcpy(inventario->baules[inventario->tope_baules].etiqueta,etiqueta);
        inventario->baules[inventario->tope_baules].tope_juguetes = 0;
        inventario->tope_baules++;
        printf("Nuevo baul %s guardado\n", etiqueta);
    }else{
        printf("Uy te quedaste sin espacio para baules\n");
    }
}

bool se_puede_vender(juguete_t juguete_a_vender, int antiguedad){
    return(strcmp(juguete_a_vender.tipo, PELUCHE) != 0 && antiguedad > MINIMA_ANTIGUEDAD_VALIDA);
}

// Pre: inventario debe estar correctamente inicializado, así como también el vector de juguetes a vender vacío con su tope inicializado correctamente.
// Pos: Guarda en el vector de juguetes aquellos que pueden ser vendidos (no peluches y más de 10 años de antigüedad).
void calcular_juguetes_a_vender(inventario_t inventario, juguete_t juguetes_a_vender[MAX_JUGUETES], int* tope_juguetes_a_vender){
    
    for (int i = 0; i < inventario.tope_baules; i++){
        for (int j = 0; j < inventario.baules[i].tope_juguetes; j++){
            juguete_t juguete_a_vender = inventario.baules[i].juguetes[j];
            int antiguedad = ANIO_ACTUAL - juguete_a_vender.anio_comprado;
            if(se_puede_vender(juguete_a_vender, antiguedad)){
                juguetes_a_vender[*tope_juguetes_a_vender] = juguete_a_vender;
                (*tope_juguetes_a_vender)++;
            }
        }    
    }

    printf("Se agregaron %i cantidad de juguetes a la lista de venta\n", *tope_juguetes_a_vender);
    
}