#ifndef INVENTARIO_H
#define INVENTARIO_H

#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_TIPO 20
#define MAX_JUGUETES 100
#define MAX_NOMBRE 50
#define MAX_BAULES 10

typedef struct juguete {
    char nombre[MAX_NOMBRE];
    int anio_comprado;
    int valor;
    char tipo[MAX_TIPO]; // "Electrónico", "Peluche", "Plástico"
} juguete_t;

typedef struct baul {
    juguete_t juguetes[MAX_JUGUETES];
    char etiqueta[MAX_NOMBRE];
    int tope_juguetes;
} baul_t;

typedef struct inventario {
    baul_t baules[MAX_BAULES];
    int tope_baules;
} inventario_t;

// Pre: nuevo_juguete debe ser un juguete inicializado. inventario está correctamente inicializado.
// Pos: Se agrega el juguete al baúl con menos juguetes y se muestra un mensaje con la etiqueta del baúl al que fue agregado.
void agregar_juguete(inventario_t* inventario, juguete_t nuevo_juguete);

// Pre: inventario debe estar inicializado y los tipos de los juguetes deben ser “Electrónico", "Peluche", o "Plástico"
// Pos: Se cuentan y muestran la cantidad de cada tipo de juguete por pantalla.
void contar_juguetes_por_tipo(inventario_t inventario);

// Pre: inventario debe estar correctamente inicializado.
// Pos: Crea un nuevo baúl vacío para guardar juguetes con la etiqueta que recibe.
void agregar_baul(inventario_t* inventario, char etiqueta[MAX_NOMBRE]);

// Pre: inventario debe estar correctamente inicializado, así como también el vector de juguetes a vender vacío con su tope inicializado correctamente.
// Pos: Guarda en el vector de juguetes aquellos que pueden ser vendidos (no peluches y más de 10 años de antigüedad).
void calcular_juguetes_a_vender(inventario_t inventario, juguete_t juguetes_a_vender[MAX_JUGUETES], int* tope_juguetes_a_vender);

#endif