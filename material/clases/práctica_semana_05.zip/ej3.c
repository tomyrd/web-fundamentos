#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE 40
#define MAX_CASAS 20

const int TOTAL_ROMPEMUELAS = 75;
const int VALOR_CARAMELO = 5;
const int LLEGA_PLATA = 0;
const int NO_ALCANZA = -1;

typedef struct casa {
	char direccion[MAX_NOMBRE];
	int cant_plata;
	int cant_caramelos;
} casa_t;

void inicializar_casas(casa_t casas[MAX_CASAS], int* tope_casas) {
    strcpy(casas[0].direccion, "Av. Siempre Viva 742");
    casas[0].cant_plata = 5;
    casas[0].cant_caramelos = 3;

    strcpy(casas[1].direccion, "Calle Falsa 123");
    casas[1].cant_plata = 10;
    casas[1].cant_caramelos = 5;

    strcpy(casas[2].direccion, "Boulevard Central 456");
    casas[2].cant_plata = 5;
    casas[2].cant_caramelos = 2;

    strcpy(casas[3].direccion, "Pasaje Luna 789");
    casas[3].cant_plata = 5;
    casas[3].cant_caramelos = 8;

    strcpy(casas[4].direccion, "Diagonal Norte 321");
    casas[4].cant_plata = 8;
    casas[4].cant_caramelos = 4;

    strcpy(casas[5].direccion, "Calle Sol 555");
    casas[5].cant_plata = 12;
    casas[5].cant_caramelos = 6;

    /*strcpy(casas[6].direccion, "Av. Primavera 101");
    casas[6].cant_plata = 7;
    casas[6].cant_caramelos = 9;

    strcpy(casas[7].direccion, "Calle Invierno 202");
    casas[7].cant_plata = 1;
    casas[7].cant_caramelos = 1;

    strcpy(casas[8].direccion, "Pasaje Otoño 303");
    casas[8].cant_plata = 1;
    casas[8].cant_caramelos = 10;

    strcpy(casas[9].direccion, "Diagonal Sur 404");
    casas[9].cant_plata = 1;
    casas[9].cant_caramelos = 7;*/
    
    
    *tope_casas = 6;
}

// Pre: El tope tiene que estar entre el 0 y el MAX_CASAS y el parametro i debe inicializarse en 0.
// Pos:  - Retorna 0 si se llega al objetivo TOTAL_ROMPEMUELAS con la plata acumulada.
//       - Retorna -1 si no alcanza ni la plata acumulada ni los caramelos acumulados.
//       - Retorna la minima cantidad de caramelos a vender si es posible llegar al TOTAL_ROMPEMUELAS con la suma de plata acumulada y caramelos acumulados.

int caramelos_vendidos(casa_t casas[MAX_CASAS], int tope_casas, int caramelos_acumulados, int plata_acumulada, int i){

    if(i == tope_casas){

        if(plata_acumulada >= TOTAL_ROMPEMUELAS){
            return LLEGA_PLATA;
        }

        if(( plata_acumulada + (caramelos_acumulados * VALOR_CARAMELO)) < TOTAL_ROMPEMUELAS){
            return NO_ALCANZA;
        }

        int plata_faltante = TOTAL_ROMPEMUELAS - plata_acumulada;
        int caramelos_a_vender = (plata_faltante / VALOR_CARAMELO);
        if(plata_faltante % VALOR_CARAMELO != 0){
            caramelos_a_vender++;
        }

        return caramelos_a_vender;
    }

    plata_acumulada += casas[i].cant_plata;
    caramelos_acumulados += casas[i].cant_caramelos;

    return caramelos_vendidos(casas, tope_casas, caramelos_acumulados, plata_acumulada, i+1);
}

int main(){
	casa_t casas[MAX_CASAS];
    int tope_casas = 0;
	inicializar_casas(casas, &tope_casas);

    printf("La cantidad de caramelos a vender es: %i\n", caramelos_vendidos(casas, tope_casas, 0, 0, 0));

    int cant_caramelos = 0;
    int cant_plata = 0;
    for (int i = 0; i < tope_casas; i++){
       cant_caramelos += casas[i].cant_caramelos;
       cant_plata += casas[i].cant_plata;
    }

    printf("cant caramelos: %i y cant plata: %i\n", cant_caramelos, cant_plata);
    

	return 0;
}