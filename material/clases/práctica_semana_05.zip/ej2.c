#include <stdio.h>
#include <stdbool.h>

#define MAX_FRASE 50

const char REEMPLAZO = 'i';

/* 
* pre: debe ser letra minúscula
* post: devuelve true si la letra es vocal (a, e, i, o, u), false en caso contrario
*/
bool es_vocal(char letra){
    return letra == 'a' || letra == 'e' || letra == 'o' || letra == 'u' || letra == 'i';
}

/* pre: frase debe ser un string (terminar en \0) en minuscula. En el primer llamado i = 0
* post: intercambia las vocales de frase por la letra REEMPLAZO.
*/
void intercambiar_vocales(char frase[MAX_FRASE], int i){
    if(frase[i] == '\0'){
        return;
    }

    if(es_vocal(frase[i])){
        frase[i] = REEMPLAZO;
    }

    intercambiar_vocales(frase, i + 1);
}


int main(){
    char frase[MAX_FRASE] = "bart, eres muy insoportable";
    intercambiar_vocales(frase, 0);
    printf("frase: %s\n", frase);

    return 0;
}