#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#define MAX_COLOR 100
#define MAX_MONEDAS 1000
#define MAX_JOYAS 1000

#define COLOR_AZUL "azul"

const int ANTIGUEDAD_MINIMA = 5;

typedef struct joya {
    int valor;
    int antiguedad;
    char color[MAX_COLOR];
} joya_t;

typedef struct moneda {
    int valor;
    bool de_oro;
} moneda_t;

typedef struct tesoro {
    moneda_t monedas[MAX_MONEDAS];
    int tope_monedas;
    joya_t joyas[MAX_JOYAS];
    int tope_joyas;
    bool desenterrado;
} tesoro_t;

void inicializar_tesoro(tesoro_t* tesoro);
void imprimir_tesoro(tesoro_t tesoro);

// pre: -
// post: devuelve true si el color de la joya es azul y su antiguedad es menor a 5, false si no.
bool es_joya_nueva(joya_t joya){
    return(strcmp(joya.color, COLOR_AZUL) == 0 && joya.antiguedad < ANTIGUEDAD_MINIMA);
}

// pre: tesoro tiene que estar correctamente inicializado
// post: devuelve el valor total del tesoro, que seria la suma de los valores de las monedas y las joyas
int valor_tesoro(tesoro_t tesoro){
    int valor_total = 0;
    for(int i = 0; i < tesoro.tope_monedas; i++){
        if(tesoro.monedas[i].de_oro){
            valor_total += (tesoro.monedas[i].valor * 2);
        }else{
            valor_total += tesoro.monedas[i].valor;
        }
    }

    for(int j = 0; j < tesoro.tope_joyas; j++){
        if(es_joya_nueva(tesoro.joyas[j])){
            valor_total += tesoro.joyas[j].valor / 2;
        }else{
            valor_total += tesoro.joyas[j].valor;
        }
    }

    return valor_total;
}

// pre: el tesoro y la moneda tienen que estar correctamente inicializados. El tope monedas tiene
// que ser mayor o igual a 0 y menor a MAX_MONEDAS.
// post: guarda la moneda en el tesoro
void guardar_moneda(tesoro_t* tesoro, moneda_t moneda){
    tesoro->monedas[(*tesoro).tope_monedas] = moneda;
    tesoro->tope_monedas++;
}

int main(){
    tesoro_t tesoro;
    inicializar_tesoro(&tesoro);
    imprimir_tesoro(tesoro);

    int valor = valor_tesoro(tesoro);
    printf("\nvalor: %i\n", valor);
    moneda_t moneda = (moneda_t){5000, true};
    guardar_moneda(&tesoro, moneda);
    imprimir_tesoro(tesoro);
    return 0;
}














void inicializar_tesoro(tesoro_t* tesoro){
    tesoro->tope_monedas = 5;
    tesoro->tope_joyas = 5;
    tesoro->desenterrado = true;
    tesoro->monedas[0] = (moneda_t){10, true};
    tesoro->monedas[1] = (moneda_t){20, false};
    tesoro->monedas[2] = (moneda_t){30, true};
    tesoro->monedas[3] = (moneda_t){40, false};
    tesoro->monedas[4] = (moneda_t){50, true};
    tesoro->joyas[0] = (joya_t){100, 10, "rojo"};
    tesoro->joyas[1] = (joya_t){200, 4, "azul"};
    tesoro->joyas[2] = (joya_t){300, 30, "verde"};
    tesoro->joyas[3] = (joya_t){400, 40, "amarillo"};
    tesoro->joyas[4] = (joya_t){500, 50, "naranja"};
}

void imprimir_tesoro(tesoro_t tesoro){
    printf("TESORO: \n");
    printf("Monedas: \n");
    for (int i = 0; i < tesoro.tope_monedas; i++){
        printf("Valor: %i, %s\n", tesoro.monedas[i].valor, tesoro.monedas[i].de_oro ? "Oro" : "No oro");
    }
    printf("\nJoyas: \n");
    for (int i = 0; i < tesoro.tope_joyas; i++){
        printf("Valor: %i, Antiguedad: %i, Color: %s\n", tesoro.joyas[i].valor, tesoro.joyas[i].antiguedad, tesoro.joyas[i].color);
    }
}