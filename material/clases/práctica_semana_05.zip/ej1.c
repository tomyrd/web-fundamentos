// Lisa se despertó con ganas de escuchar una canción de su artista favorito: Murphy ‘Encías Sangrantes’.

// Se tiene el siguiente struct:
// typedef struct cancion {
// 	char nombre[MAX_NOMBRE];
// 	char genero[MAX_GENERO];
// 	char* artista[MAX_ARTISTA];
// 	int duracion;
// } cancion_t;


// Crear una función que, dado un vector de canciones ordenado alfabéticamente (A-Z)por artista, devuelva la posición de la canción que canta Murphy ‘Encías Sangrantes’.
#include <stdio.h>
#include <string.h>
#include <stdbool.h>


#define MAX_NOMBRE 30
#define MAX_GENERO 15
#define MAX_ARTISTA 40
#define MAX_CANCIONES 30

const char* ARTISTA_BUSCADO = "Murphy";

const int NO_ENCONTRADO = -1;
    
typedef struct cancion {
    char nombre[MAX_NOMBRE];
	char genero[MAX_GENERO];
	char artista[MAX_ARTISTA];
	int duracion;
} cancion_t;


void inicializar_canciones(cancion_t canciones[MAX_CANCIONES], int* tope_canciones){
    // Inicializa canciones de artistas reales y Murphy, ordenadas alfabéticamente por artista
	strcpy(canciones[0].nombre, "Amor de verano");
	strcpy(canciones[0].genero, "Pop");
	strcpy(canciones[0].artista, "Airbag");
	canciones[0].duracion = 200;

	strcpy(canciones[1].nombre, "Dangerous Woman");
	strcpy(canciones[1].genero, "Pop");
	strcpy(canciones[1].artista, "Ariana Grande");
	canciones[1].duracion = 215;

	strcpy(canciones[2].nombre, "Beautiful Things");
	strcpy(canciones[2].genero, "Pop");
	strcpy(canciones[2].artista, "Benson Boone");
	canciones[2].duracion = 195;

	strcpy(canciones[3].nombre, "Impostor");
	strcpy(canciones[3].genero, "Trap");
	strcpy(canciones[3].artista, "Catriel y Paco Amoroso");
	canciones[3].duracion = 210;

	strcpy(canciones[4].nombre, "Red Wine Supernova");
	strcpy(canciones[4].genero, "Pop");
	strcpy(canciones[4].artista, "Chapel Roan");
	canciones[4].duracion = 220;

	strcpy(canciones[5].nombre, "Judas");
	strcpy(canciones[5].genero, "Pop");
	strcpy(canciones[5].artista, "Lady Gaga");
	canciones[5].duracion = 210;

	strcpy(canciones[6].nombre, "Lokura");
	strcpy(canciones[6].genero, "Pop");
	strcpy(canciones[6].artista, "Lali");
	canciones[6].duracion = 205;

	strcpy(canciones[7].nombre, "Tramposa y Mentirosa");
	strcpy(canciones[7].genero, "Cumbia");
	strcpy(canciones[7].artista, "Leo Mattioli");
	canciones[7].duracion = 180;

	strcpy(canciones[8].nombre, "Quiero creer");
	strcpy(canciones[8].genero, "Cuarteto");
	strcpy(canciones[8].artista, "Luck Ra");
	canciones[8].duracion = 180;

	strcpy(canciones[9].nombre, "Easy Lover");
	strcpy(canciones[9].genero, "Pop");
	strcpy(canciones[9].artista, "Miley Cyrus");
	canciones[9].duracion = 210;

    strcpy(canciones[10].nombre, "166");
	strcpy(canciones[10].genero, "Trap");
	strcpy(canciones[10].artista, "Milo J");
	canciones[10].duracion = 180;

    strcpy(canciones[11].nombre, "Siempre que lo beso");
	strcpy(canciones[11].genero, "Pop");
	strcpy(canciones[11].artista, "Miranda");
	canciones[11].duracion = 200;
	

	strcpy(canciones[12].nombre, "Murphy's Jazz");
	strcpy(canciones[12].genero, "Jazz");
	strcpy(canciones[12].artista, "Murphy");
	canciones[12].duracion = 210;
    

	strcpy(canciones[13].nombre, "Loca");
	strcpy(canciones[13].genero, "Pop");
	strcpy(canciones[13].artista, "Tan Bionica");
	canciones[13].duracion = 200;

	strcpy(canciones[14].nombre, "Bad idea right?");
	strcpy(canciones[14].genero, "Pop");
	strcpy(canciones[14].artista, "Olivia Rodrigo");
	canciones[14].duracion = 200;

	strcpy(canciones[15].nombre, "Espresso");
	strcpy(canciones[15].genero, "Pop");
	strcpy(canciones[15].artista, "Sabrina Carpenter");
	canciones[15].duracion = 190;

	strcpy(canciones[16].nombre, "Lover");
	strcpy(canciones[16].genero, "Pop");
	strcpy(canciones[16].artista, "Taylor Swift");
	canciones[16].duracion = 220;

	*tope_canciones = 17;
}

void imprimir_canciones(cancion_t canciones[MAX_CANCIONES], int tope_canciones){
	printf("\nLista de canciones de Lisa:\n");
	printf("========================================================================================\n");
	printf("| %-3s | %-25s | 🎵 %-28s  |\n", "#", "Artista", "Título");
	printf("----------------------------------------------------------------------------------------\n");
	for(int i = 0; i < tope_canciones; i++) {
		printf("| %2d  | %-25s | 🎵 %-28s |\n", i, canciones[i].artista, canciones[i].nombre);
	}
	printf("========================================================================================\n");
}

/* Pre: El vector de canciones tiene que estar ordenado alfabéticamente por artista (A-Z), 0 <= tope_canciones < MAX_CANCIONES.
* Post: Devuelve el índice donde se encuentra artista_buscado, devuelve -1 si no se encuentra al artista.
*/
int indice_artista_bb(cancion_t canciones[MAX_CANCIONES], int tope_canciones, char artista_buscado[MAX_ARTISTA]){
    int inicio = 0;
    int fin = tope_canciones - 1;
    int centro = 0;

    bool encontrado = false;
    int indice_encontrado = NO_ENCONTRADO;

    while (inicio <= fin && !encontrado){
        centro = (fin + inicio) / 2;
        int comp = strcmp(canciones[centro].artista, artista_buscado);
        if(comp == 0){
            encontrado = true;
            indice_encontrado = centro;
        }else if(comp < 0){
            inicio = centro + 1;
        }else{
            fin = centro - 1;
        }
    }

    return indice_encontrado;
}

int main(){

    cancion_t canciones_de_lisa[MAX_CANCIONES];
    int tope_canciones = 0;
    inicializar_canciones(canciones_de_lisa, &tope_canciones);
    imprimir_canciones(canciones_de_lisa, tope_canciones);

	int indice = indice_artista_bb(canciones_de_lisa, tope_canciones, ARTISTA_BUSCADO);
	printf("El indice de Murphy es: %i\n", indice);

	return 0;
}