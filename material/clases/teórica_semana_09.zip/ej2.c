#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_NOMBRE 10
#define MAX_ARMAS 3
#define MAX_ARMA 50
#define MAX_FIL 10
#define MAX_COL 10

const int COL_INVALIDA = -1;

typedef struct enemigo {
    char letra_cinta;
    bool vencido;
    char armas[MAX_ARMAS][MAX_NOMBRE]; // espada, cuchillo, ballesta, etc
    int fuerza;
} enemigo_t;

const char INFILTRADO = 'M';
const char ARMA_BUSCADA[MAX_ARMA] = "ballesta";

// pre condicion: cada fila de armas debe ser un string (terminar en '\0').
// post condicion: devuelve true en caso de tener una ballesta o false en caso contrario.
bool tiene_ballesta(char armas[MAX_ARMAS][MAX_NOMBRE]) {
    bool ballesta_encontrada = false;
    int i = 0;
    while (i < MAX_ARMAS && !ballesta_encontrada) {
        if(strcmp(armas[i], ARMA_BUSCADA) == 0) {
            ballesta_encontrada = true;
        }
        i++;
    }   

    return ballesta_encontrada;
}

// pre condicion: cada fila del campo armas debe ser un string (terminar en '\0').
// post condicion: devuelve la fuerza del enemigo o 0 en caso de estar vencido o no es un enemigo.
int fuerza_enemigo(enemigo_t enemigo) {
    if(enemigo.vencido || enemigo.letra_cinta == INFILTRADO) {
        return 0;
    }

    if(tiene_ballesta(enemigo.armas)) {
        return enemigo.fuerza * 2;
    }

    return enemigo.fuerza;
}

// pre condición: topes >= 0 y menores a MAX_FIL y MAX_COL respectivamente.
// post condición: devuelve la columna por la que Mulan recibe menos daños o -1 si la matriz está vacía.
int columna_minima(enemigo_t campo[MAX_FIL][MAX_COL], int tope_fil, int tope_col) {
    
    int col_minima = COL_INVALIDA;
    int fuerza_minima = 0;

    for(int j = 0 ; j < tope_col; j++) {
        int fuerza_acumulada = 0;
        
        for(int i = 0 ; i < tope_fil; i++) {
            fuerza_acumulada += fuerza_enemigo(campo[i][j]);
        }

        if(j == 0) {
            col_minima = 0;
            fuerza_minima = fuerza_acumulada;
        } else if (fuerza_acumulada < fuerza_minima) {
            col_minima = j;
            fuerza_minima = fuerza_acumulada;
        }
    }

    return col_minima;
}
