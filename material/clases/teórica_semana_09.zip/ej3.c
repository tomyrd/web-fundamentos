#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE 50
#define MAX_FRASE 50
#define MAX_PALABRA 1000

typedef struct turno {
    char nombre[MAX_NOMBRE]; // “Abe”, “Gaspar”, etc
    char frase_dicha[MAX_FRASE];
    char palabra_dicha[MAX_PALABRA];
    int proximo;
} turno_t;

const int ULTIMO = -1;
#define MAX_ANCIANOS 10

// pre condición: 'nombre_perdedor' inicialmente vacío ("").
//                'frase_correcta' inicialmente vacío ("").
//                'actual' inicialmente en 0.
// post condición: llena 'nombre_perdedor' con el nombre del anciano que se equivoca o vacío si no se equivoca nadie.
void determinar_anciano_perdedor_rec(turno_t ancianos[MAX_ANCIANOS], int actual, char nombre_perdedor[MAX_NOMBRE], char frase_correcta[MAX_FRASE]) {
    // condicion de corte
    if (actual == ULTIMO) {
        return;
    }

    if (strcmp(frase_correcta, ancianos[actual].frase_dicha) != 0) {
        strcpy(nombre_perdedor, ancianos[actual].nombre);
        return;
    }

    // procesamiento
    if(strlen(frase_correcta) == 0) {
        strcpy(frase_correcta, ancianos[actual].palabra_dicha);
    } else {
        strcat(frase_correcta, ancianos[actual].palabra_dicha);
    }

    // llamado recursivo
    determinar_anciano_perdedor_rec(ancianos, ancianos[actual].proximo, nombre_perdedor, frase_correcta);
}

// pre condición: 'nombre_perdedor' inicialmente vacío ("").
// post condición: llena 'nombre_perdedor' con el nombre del anciano que se equivoca o vacío si no se equivoca nadie.
void determinar_anciano_perdedor(turno_t ancianos[MAX_ANCIANOS], char nombre_perdedor[MAX_NOMBRE]) {
    char frase_correcta[MAX_FRASE] = "";

    determinar_anciano_perdedor_rec(ancianos, 0, nombre_perdedor, frase_correcta);
}
