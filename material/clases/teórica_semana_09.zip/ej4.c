#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_TEXTO 100
#define MAX_COLOR 100

#define MAX_FIL 10
#define MAX_COL 10

typedef struct espacio {
    bool tiene_grafiti;
    char firma[MAX_TEXTO]; // “El Barto”, “Hombre Pie”, “Lenny Ponzoñoso”, etc
    char color[MAX_COLOR];
} espacio_t;

const char FIRMA_BARTO[MAX_TEXTO] = "El Barto";
const char COLOR_BARTO[MAX_COLOR] = "Rojo";

#define CANT_COLORES_SOBREESCRIBIBLES 2
const char COLORES_SOBREESCRIBIBLES[CANT_COLORES_SOBREESCRIBIBLES][MAX_COLOR] = {"Verde", "Amarillo"};

// pre condición: 'color' debe ser un string (terminar en '\0')
// post condición: devuelve true en caso de que el color sea de los sobreescribibles o false en caso contrario.
bool tiene_color_sobreescribible(char color[MAX_COLOR]) {
    bool sobreescribible = false;
    for (int i = 0; i < CANT_COLORES_SOBREESCRIBIBLES; i++) {
        if (strcmp(color, COLORES_SOBREESCRIBIBLES[i]) == 0) {
            sobreescribible = true;
        }
    }

    return sobreescribible;    
}

// pre condición: los campos 'firma' y 'color' deben ser strings (terminar en '\0').
// post condición: devuelve true si el espacio es vandalizable para El Barto o false en caso contrario.
bool es_vandalizable(espacio_t espacio) {
    return !espacio.tiene_grafiti || (strcmp(espacio.firma, FIRMA_BARTO) != 0 && tiene_color_sobreescribible(espacio.color));
}

// pre condición: cada fila de 'sprinfield' debe contener uno o más espacios vandalizables (por enunciado). 
//                  todos los campos los campos 'firma' y 'color' de los espacio_t deben ser strings (terminar en '\0').
//                  'i' y 'j' deben tener el valor 0 en el primer llamado.
//                  'tope_fil' y 'tope_col' deben ser mayor o iguales a 0 y menor a MAX_FIL y MAX_COL respectivamente.
// post condición: modifica la matriz 'sprinfield' vandalizando un registro de cada fila por El Barto.
void vandalizar_springfield(espacio_t sprinfield[MAX_FIL][MAX_COL], int tope_fil, int tope_col, int i, int j) {
    // condicion de corte
    if (i == tope_fil) {
        return;
    }

    // procesamiento
    if(es_vandalizable(sprinfield[i][j])) {
        sprinfield[i][j].tiene_grafiti = true;
        strcpy(sprinfield[i][j].firma, FIRMA_BARTO);
        strcpy(sprinfield[i][j].color, COLOR_BARTO);

        // llamado recursivo
        vandalizar_springfield(sprinfield, tope_fil, tope_col, i+1, 0);
    } else {
        // llamado recursivo
        vandalizar_springfield(sprinfield, tope_fil, tope_col, i, j+1);
    }
}
