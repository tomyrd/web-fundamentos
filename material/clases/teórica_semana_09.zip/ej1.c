#include <stdio.h>
#include <stdbool.h>
#include "string.h"

#define MAX_NOMBRE 50
#define MAX_AUTOS 50


typedef struct autoo { 
    char marca[MAX_NOMBRE]; // "Audi", "Ferrari", etc
    int antiguedad; // en años
    int estado; 
} auto_t;

// buen estado (>= 7)
// no sea audi
// el más antiguo
const int MIN_BUEN_ESTADO = 7;
const char MARCA_RECHAZADA[50] = "Audi";
const int NO_ENCONTRADO = -1;

// pre condicion: el campo 'marca' de los auto_t debe ser un string (terminar en '\0')
// post condicion: devuelve true si es un auto que le intersa al sr burns o false en caso contrario.
bool es_opcion(auto_t autoo) {
    return autoo.estado >= MIN_BUEN_ESTADO &&
    strcmp(autoo.marca, MARCA_RECHAZADA) != 0;
}

// pre condicion: 'tope' tiene que tener un valor >= 0 y menor a MAX_AUTOS.
//                 'elegido' valga -1 en el primer llamado.
//                  'i' valga 0 en el primer llamado.
//                  los campos 'marca' de los auto_t deben ser un string (terminar en '\0')
// post condicion: devuelve el indice del auto obtenido o -1 en caso de no encontrar.
int obtener_auto_burn(auto_t autos[MAX_AUTOS], int tope, int elegido, int i) {

    // condicion de corte
    if (i == tope){
        return elegido;
    }

    // procesamiento
    if(es_opcion(autos[i])) {
        if(elegido == NO_ENCONTRADO) {
            elegido = i;
        } else if (autos[i].antiguedad > autos[elegido].antiguedad){
            elegido = i;
        }
    }

    // llamada recursiva
    return obtener_auto_burn(autos, tope, elegido, i+1);
}
