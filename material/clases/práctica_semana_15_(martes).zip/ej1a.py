import csv

MOUSKEHERRAMIENTAS = 'mouskeherramientas.csv'
ULTIMA_AVENTURA = 'ultima_aventura.csv'
ARCHIVO_AUXILIAR = 'aux.csv'

MODO_LECTURA = 'r'
MODO_ESCRITURA = 'w'


ID = 0
FUE_UTILIZADA = 1
HERRAMIENTA_UTILIZADA = 1


# Dado los dos archivos con cantidades de Mouskeherramientas que entran en memoria, crear una función que actualice el archivo de  Mouskeherramientas nunca utilizadas.

def actualizar_mouskeherramientas():
    try:
        mouskeherramientas_file = open(MOUSKEHERRAMIENTAS, MODO_LECTURA)
    except:
        print(f"Error al intentar abrir el archivo {MOUSKEHERRAMIENTAS}")
        return
    
    try:
        ultima_aventura_file = open(ULTIMA_AVENTURA, MODO_LECTURA)
    except:
        print(f"Error al intentar abrir el archivo {ULTIMA_AVENTURA}")
        mouskeherramientas_file.close()
        return

    # readlines() -> devuelve una lista con todo el contenido del archivo
    mouskeherramientas_reader = csv.reader(mouskeherramientas_file, delimiter='-')
    ultima_aventura_reader = csv.reader(ultima_aventura_file, delimiter='-')

    mouskeherramientas = list(mouskeherramientas_reader)
    ultima_aventura = list(ultima_aventura_reader)

    for ua in ultima_aventura:
        if int(ua[FUE_UTILIZADA]) == HERRAMIENTA_UTILIZADA:
            for mh in mouskeherramientas:
                if int(ua[ID]) == int(mh[ID]):
                    mouskeherramientas.remove(mh)
    

    mouskeherramientas_file.close()
    ultima_aventura_file.close()

    try:
        mouskeherramientas_file = open(MOUSKEHERRAMIENTAS, MODO_ESCRITURA)
    except:
        print(f"Error al intentar abrir el archivo {MOUSKEHERRAMIENTAS}")
        return

    writer = csv.writer(mouskeherramientas_file, delimiter='-')
    writer.writerows(mouskeherramientas)
    
    mouskeherramientas_file.close()


if __name__ == "__main__":
    actualizar_mouskeherramientas()