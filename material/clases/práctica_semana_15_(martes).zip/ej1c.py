import os
import csv

MOUSKEHERRAMIENTAS = 'mouskeherramientas.csv'
ULTIMA_AVENTURA = 'ultima_aventura.csv'
ARCHIVO_AUXILIAR = 'aux.csv'

MODO_LECTURA = 'r'
MODO_ESCRITURA = 'w'


ID = 0
FUE_UTILIZADA = 1
HERRAMIENTA_UTILIZADA = 1


# Dado los dos archivos con cantidades de Mouskeherramientas que NO entran en memoria, crear una función que actualice el archivo de  Mouskeherramientas nunca utilizadas.
def actualizar_mouskeherramientas():
    try:
        mouskeherramientas_file = open(MOUSKEHERRAMIENTAS, MODO_LECTURA)
    except:
        print(f"Error al intentar abrir el archivo {MOUSKEHERRAMIENTAS}")
        return
    
    try:
        ultima_aventura_file = open(ULTIMA_AVENTURA, MODO_LECTURA)
    except:
        print(f"Error al intentar abrir el archivo {ULTIMA_AVENTURA}")
        mouskeherramientas_file.close()
        return
    
    try:
        aux_file = open(ARCHIVO_AUXILIAR, MODO_ESCRITURA)
    except:
        print(f"Error al intentar abrir el archivo {ARCHIVO_AUXILIAR}")
        mouskeherramientas_file.close()
        ultima_aventura_file.close()
        return

    writer = csv.writer(aux_file, delimiter='-')

    mh = mouskeherramientas_file.readline()
    ua = ultima_aventura_file.readline()

    while mh != "" and ua != "":
        mh_l = mh.rstrip().split('-')
        ua_l = ua.rstrip().split('-')

        if int(mh_l[ID]) == int(ua_l[ID]):
            if int(ua_l[FUE_UTILIZADA]) != HERRAMIENTA_UTILIZADA:
                writer.writerow(mh_l)
            mh = mouskeherramientas_file.readline()
            ua = ultima_aventura_file.readline()

        if int(mh_l[ID]) < int(ua_l[ID]):
            writer.writerow(mh_l)
            mh = mouskeherramientas_file.readline()

        # if mh_l[ID] > ua_l[ID]: # este caso no va a suceder por precondicion

    mh = mouskeherramientas_file.readline()
    while mh != "":
        mh_l = mh.rstrip().split('-')
        writer.writerow(mh_l)
        mh = mouskeherramientas_file.readline()



    mouskeherramientas_file.close()
    ultima_aventura_file.close()
    aux_file.close()

    os.rename(ARCHIVO_AUXILIAR, MOUSKEHERRAMIENTAS)


if __name__ == "__main__":
    actualizar_mouskeherramientas()