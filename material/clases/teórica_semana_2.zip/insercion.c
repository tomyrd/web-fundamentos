#include <stdio.h>
#define MAXIMO_VEC_NUMEROS 10

int main() {

    char abc[MAXIMO_VEC_NUMEROS] = {'a', 'b', 'd', 'e'};
    int tope = 4;

    char valor_nuevo = 'c';
    int indice_nuevo = 2;

    for(int i = tope ; i > indice_nuevo; i--) {
        abc[i] = abc[i-1];

    }
    abc[indice_nuevo] = valor_nuevo;
    tope++;

    for (int i = 0; i < tope; i++) {
        printf(" %c", abc[i]);
    }


    return 0;
}

// gcc insercion.c -o insercion
// ./insercion
