#include <stdio.h>

int main() {
    printf("Holus Fundamendez 😊!\n");
    char vocales[5];
    vocales[1] = 'a';
    vocales[1] = 'e';

    printf("%c\n", vocales[1]);


    return 0;
}

// gcc vocales.c -o vocales
// ./vocales
