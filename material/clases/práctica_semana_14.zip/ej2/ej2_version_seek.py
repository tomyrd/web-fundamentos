HOBBIES_ANNIE = "hobbies_annie.txt"
HOBBIES_HALLIE = "hobbies_hallie.txt"
HOBBIES_COMUN = "hobbies_comun.txt"
MODO_LECTURA = "r"
MODO_ESCRITURA = "w"

def crear_hobbies_en_comun():
    try:
        with open(HOBBIES_ANNIE, MODO_LECTURA) as hobbies_annie, open(HOBBIES_HALLIE, MODO_LECTURA) as hobbies_hallie, open(HOBBIES_COMUN, MODO_ESCRITURA) as hobbies_comun:
                       
            linea_annie = hobbies_annie.readline()
            while(linea_annie != ""):
                linea_hallie = hobbies_hallie.readline()
                while(linea_hallie != ""):
                    if(linea_annie == linea_hallie):
                        hobbies_comun.write(linea_annie)
                    
                    linea_hallie = hobbies_hallie.readline()
                
                linea_hallie.seek(0)
                    
                linea_annie = hobbies_annie.readline()

    except:
        print('Error al acceder a alguno de los archivos')
                
                        

if __name__ == "__main__":
    crear_hobbies_en_comun()