import os

ARCHIVO_DISCURSO = "discursso.txt"
MODO_LECTURA = "r"
ARCHIVO_AUX = "discurso_aux.txt"
MODO_ESCRITURA = "w"

def cambiar_discurso():
    # abrir el archivo
    try:
        arch_discurso = open(ARCHIVO_DISCURSO, MODO_LECTURA)
    except:
        print("Error abriendo el discurso")
        return
    
    try:
        arch_auxiliar = open(ARCHIVO_AUX, MODO_ESCRITURA)
    except:
        print("Error abriendo el auxiliar")
        arch_discurso.close()
        return

    # operar
    linea = arch_discurso.readline()
    while len(linea) > 0:
        linea = linea.replace("Hallie", "Annie")
        linea = linea.replace("California", "Londres")
        linea = linea.replace("papá", "mamá")
        arch_auxiliar.write(linea)
        linea = arch_discurso.readline()


    # cerrarlo
    arch_discurso.close()
    arch_auxiliar.close()

    os.rename(ARCHIVO_AUX, ARCHIVO_DISCURSO)


if __name__ == "__main__":
    cambiar_discurso()