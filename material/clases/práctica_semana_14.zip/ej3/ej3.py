import csv

ARCHIVO_RECETAS =  "recetas.csv"
MODO_LECTURA = "r"
ARCHIVO_SOPAS =  "sopas.csv"
MODO_ESCRITURA = "w"

INGREDIENTES_CARNIVOROS = ["POLLO", "MARISCOS", "CARNE"]

NO_VEGGIE = "NV"
VEGGIE = "V"
ING_IMPORTANTE_SOPA = "CALDO"

def es_vegetariano(ingredientes):
    es_veggie = True
    for ingrediente in ingredientes: # nos fijamos si es vegetariana o no
        if ingrediente in INGREDIENTES_CARNIVOROS:
            es_veggie = False
    return es_veggie

def sopa_clasificada(ingredientes):            
    # clasificacion = VEGGIE if es_veggie else NO_VEGGIE
    # es lo mismo que hacer esto:

    if es_vegetariano(ingredientes):
        clasificacion = VEGGIE
    else: 
        clasificacion = NO_VEGGIE

    # tambien se puede hacer así
    # return ingredientes + [clasificacion]

    ingredientes.append(clasificacion)

    return ingredientes


def guardar_sopas():
    # abrimos
    try:
        arch_recetas = open(ARCHIVO_RECETAS, MODO_LECTURA)
    except:
        print("error")
        return
    
    try:
        arch_sopas = open(ARCHIVO_SOPAS, MODO_ESCRITURA)
    except:
        arch_recetas.close()
        print("error")
        return
    
    # procesamos 
    csv_reader = csv.reader(arch_recetas, delimiter=";")
    csv_writer = csv.writer(arch_sopas, delimiter=";")

    for ingredientes in csv_reader:
        if ING_IMPORTANTE_SOPA in ingredientes: # nos fijamos si es sopa
            sopa = sopa_clasificada(ingredientes) # vemos si es vegetariana o no
            csv_writer.writerow(sopa) # escribe solo en un csv

    # cerramos
    arch_sopas.close()
    arch_recetas.close()


if __name__ == "__main__":
    guardar_sopas()