// Nodo de la lista enlazada (pez en la hilera)
typedef struct pez {
    int id;
    struct pez* siguiente; // NULL si es el final
} pez_t;

// Tipo abstracto de la lista
typedef struct hilera hilera_t;

/**
 * Pre: -
 * Post: Devuelve un puntero a una hilera vacia reservada en el heap, o NULL si falla la reserva.
 */
hilera_t* hilera_crear();

/**
 * Pre: `hilera` fue creada con `hilera_crear`.
 * Post: Se libera toda la memoria de la hilera. No debe usarse luego de esta operacion.
 */
void hilera_destruir(hilera_t* hilera);

/**
 * Pre: `hilera` fue creada correctamente. `id` apunta a un entero valido.
 * Post: Se agrega un nuevo pez con ese id al comienzo de la hilera.
 */
void hilera_agregar_al_inicio(hilera_t* hilera, int id);

/**
 * Pre: `hilera` fue creada correctamente. `id` apunta a un entero valido.
 * Post: Se agrega un nuevo pez con ese id al final de la hilera.
 */
void hilera_agregar_al_final(hilera_t* hilera, int id);

/**
 * Pre: `hilera` fue creada correctamente y no está vacia.
 * Post: Se elimina el primer pez. Se devuelve el puntero a su id.
 */
int* hilera_quitar_primero(hilera_t* hilera);

/**
 * Pre: `hilera` fue creada correctamente y no está vacia.
 * Post: Se elimina el ultimo pez. Se devuelve el puntero a su id.
 */
int* hilera_quitar_ultimo(hilera_t* hilera);

/**
 * Pre: `hilera` fue creada correctamente.
 * Post: Devuelve un puntero al primer pez, o NULL si la hilera esta vacia.
 */
pez_t* hilera_primero(hilera_t* hilera);
