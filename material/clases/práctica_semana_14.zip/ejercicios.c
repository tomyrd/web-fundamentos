#include "hilera.h"
#include <stdlib.h>
#include <stdbool.h>


/*
 * Pre: La hilera debe ser creada previamente con crear_hilera
 * Post: Devuelve la cantidad de peces en la hilera
 */
int contar_peces(hilera_t *hilera){
    pez_t* pez_actual = hilera_primero(hilera);
    int cantidad = 0;

    while (pez_actual != NULL) {
        cantidad++;
        pez_actual = pez_actual->siguiente;
    }

    return cantidad;
}


/*
 * Pre: La hilera debe ser creada previamente con crear_hilera
 * Post: Devuelve un puntero al pez con el id buscado o NULL si no se encuentra en la hilera
 */
pez_t* buscar_pez(hilera_t *hilera, int id_buscado){
    pez_t* pez_actual = hilera_primero(hilera);
    bool encontrado = false;

    while (pez_actual != NULL && !encontrado) {
        if (pez_actual->id == id_buscado){
            encontrado = true;
        } else {
            pez_actual = pez_actual->siguiente;
        }
    }

    if (!encontrado) {
        return NULL;
    }

    return pez_actual;
}

bool agregar_pez_en_posicion(hilera_t *hilera, int id, int posicion) {
    pez_t* pez_actual = hilera_primero(hilera);
    int i = 1;

    while (i < posicion-1) {
        pez_actual = pez_actual->siguiente;
        i++;
    }

    // Acá pez_actual es el pez en la pos ANTERIOR a la que quiero agregar

    pez_t* nuevo_pez = malloc(sizeof(pez_t));

    if (nuevo_pez == NULL) {
        return false;
    }

    nuevo_pez->id = id;

    nuevo_pez->siguiente = pez_actual->siguiente;

    pez_actual->siguiente = nuevo_pez;

    return true;
}


void concatenar_hileras(hilera_t** hilera_base, hilera_t* hilera_a_concatenar) {
    pez_t* pez_actual = hilera_primero(*hilera_base);

    if (pez_actual == NULL) {
        *hilera_base = hilera_a_concatenar;
    }

    while (pez_actual->siguiente != NULL) {
        pez_actual = pez_actual->siguiente;
    }

    pez_actual->siguiente = hilera_primero(hilera_a_concatenar);
}
