#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_NOMBRE 100
#define MAX_LUGAR 50
#define CANT_LUGARES 4

const char* FORMATO_LECTURA = "%[^;];%[^;];%c;%i\n";
const char* FORMATO_ESCRITURA = "%s;%s;%c;%i\n";
const char* NOMBRE_ARCH_DECO_PARA_TIRAR = "decoraciones_para_tirar.csv";
const char* NOMBRE_ARCH_LUGARES_DECO = "lugares_decoraciones.txt";
const char* NOMBRE_ARCH_DECORACIONES = "decoraciones.csv";
const char* NOMBRE_ARCH_DECORACIONES_AUX = "decoraciones_aux.csv";
const char DESCOLORIDA = 'S';
const int ANIO_ACTUAL = 2025;
const int ANTIGUEDAD_MINIMA = 10;
const int ERROR = -1;
const char LUGARES_DECORACIONES[CANT_LUGARES][MAX_LUGAR] = {"patio", "ventana", "pared", "puerta"};

// nombre;lugar que decora;esta_descolorido;año que se compró
// ● Si está descolorido o no se representa con una S o N. El lugar que
// decora puede ser “puerta”, “ventana”, “pared” o “patio”.
// a. Realizar un procedimiento que dado un archivo con el listado de
// decoraciones, cree dos nuevos archivos:
// ● decoraciones_para_tirar.csv. Tendrá todas las decoraciones que
// están descoloridas y que fueron compradas hace más de 10 años.
// ● lugares_decoraciones.txt. Tendrá la cantidad de decoraciones
// que se pueden poner en cada lugar, no se van a tener en cuenta
// las decoraciones que se tienen que tirar. El formato de este
// archivo tiene que ser el siguiente:
// puerta: x
// ventana: x
// pared: x
// patio: x
// Además, se deberá actualizar el archivo original, eliminando
// las decoraciones que hay que tirar.


// pre: -
// post: devuelve true si la decoracion esta descolorida y tiene más de 10 años de antiguedad, false si no
bool es_decoracion_para_tirar(char esta_descolorida, int anio){
    return (esta_descolorida == DESCOLORIDA && ANIO_ACTUAL - anio > ANTIGUEDAD_MINIMA);
}

// pre: lugar_decorado debe ser string (terminar con \0).
// post: suma uno al valor del vector que esté en la posición que coincida con el lugar_decorado
void contar_lugares(int cant_lugares[CANT_LUGARES], char lugar_decorado[MAX_LUGAR]){
    for(int i = 0; i < CANT_LUGARES; i++){
        if(strcmp(lugar_decorado, LUGARES_DECORACIONES[i]) == 0){
            cant_lugares[i]++;
        }
    }
}

// pre: el archivo decoraciones esta abierto en modo lectura
// post: crea los archivos NOMBRE_ARCH_DECO_PARA_TIRAR y NOMBRE_ARCH_LUGARES_DECO con la información de las decoraciones a tirar
// y la cantidad de decoraciones en cada lugar, respectivamente. Actualiza el archivo de decoraciones, eliminando las que se tiran.
int organizar_decoraciones_jualowin(FILE* decoraciones){
    FILE* decoraciones_aux = fopen(NOMBRE_ARCH_DECORACIONES_AUX, "w");
    if(!decoraciones_aux){
        printf("Error al abrir el archivo de decoraciones auxiliar\n");
        return ERROR;
    }

    FILE* deco_para_tirar = fopen(NOMBRE_ARCH_DECO_PARA_TIRAR, "w");
    if(!deco_para_tirar){
        printf("Error al abrir el archivo de decoraciones para tirar\n");
        fclose(decoraciones_aux);
        return ERROR;
    }

    FILE* lugares_deco = fopen(NOMBRE_ARCH_LUGARES_DECO, "w");
    if(!lugares_deco){
        printf("Error al abrir el archivo de lugares decoraciones\n");
        fclose(decoraciones_aux);
        fclose(deco_para_tirar);
        return ERROR;
    }

    char nombre[MAX_NOMBRE];
    char lugar_decorado[MAX_LUGAR];
    char esta_descolorido;
    int anio;

    int cant_lugares[CANT_LUGARES] = {0, 0, 0, 0};

    int leido = fscanf(decoraciones, FORMATO_LECTURA, nombre, lugar_decorado, &esta_descolorido, &anio);
    while(leido != EOF){
        if(!es_decoracion_para_tirar(esta_descolorido, anio)){
            fprintf(decoraciones_aux, FORMATO_ESCRITURA, nombre, lugar_decorado, esta_descolorido, anio);
            contar_lugares(cant_lugares, lugar_decorado);
        }else{
            fprintf(deco_para_tirar, FORMATO_ESCRITURA, nombre, lugar_decorado, esta_descolorido, anio);
        }

        leido = fscanf(decoraciones, FORMATO_LECTURA, nombre, lugar_decorado, &esta_descolorido, &anio);
    }
    
    for(int i = 0; i < CANT_LUGARES; i++){
        fprintf(lugares_deco, "%s: %i\n", LUGARES_DECORACIONES[i], cant_lugares[i]);
    }

    remove(NOMBRE_ARCH_DECORACIONES);
    rename(NOMBRE_ARCH_DECORACIONES_AUX, NOMBRE_ARCH_DECORACIONES);
    
    fclose(decoraciones_aux);
    fclose(deco_para_tirar);
    fclose(lugares_deco);
    return 0;
}




int main(){
    FILE* decoraciones = fopen(NOMBRE_ARCH_DECORACIONES, "r");
    if(!decoraciones){
        printf("Error al abrir el archivo de decoraciones\n");
        return ERROR;
    }

    if(organizar_decoraciones_jualowin(decoraciones) == ERROR){
        return ERROR;
    }

    fclose(decoraciones);

    return 0;
}