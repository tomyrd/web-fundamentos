#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_DISFRAZ 20

const int ERROR = -1;
const int CANTIDAD_ARGS_MIN = 3;
const int CANTIDAD_ARGS_OPCIONAL = 4;
const int INDICE_PATTY = 1;
const int INDICE_SELMA = 2;
const int INDICE_OPCIONAL = 3;
const char* FORMATO_LECTURA = "%[^\n]\n";
const char* FORMATO_ESCRITURA = "Patty puede ir disfrazada de %s y Selma de %s\n";



int main(int argc, char *argv[]) {

    if(argc < CANTIDAD_ARGS_MIN){
        printf("Uso: ./ej1 archivo1 archivo2 [archivo3]\n");
        return ERROR;
    }

    FILE* patty = fopen(argv[INDICE_PATTY], "r");
    if(!patty)
        return ERROR;

    FILE* selma = fopen(argv[INDICE_SELMA], "r");
    if(!selma){
        fclose(patty);
        return ERROR;
    }

    FILE* combinaciones = NULL;
    if(argc == CANTIDAD_ARGS_OPCIONAL){
        combinaciones = fopen(argv[INDICE_OPCIONAL], "w");
        if(!combinaciones){
            fclose(patty);
            fclose(selma);
            return ERROR;
        }
    }

    char disfraz_patty[MAX_DISFRAZ];
    char disfraz_selma[MAX_DISFRAZ];

    int leido_patty = fscanf(patty, FORMATO_LECTURA, disfraz_patty);
    int leido_selma = fscanf(selma, FORMATO_LECTURA, disfraz_selma);


    while(leido_patty != EOF && leido_selma != EOF){
        if(argc == CANTIDAD_ARGS_OPCIONAL)
            fprintf(combinaciones, FORMATO_ESCRITURA, disfraz_patty, disfraz_selma);
        else
            printf("Patty puede ir disfrazada de %s y Selma de %s\n", disfraz_patty, disfraz_selma);
        leido_patty = fscanf(patty, FORMATO_LECTURA, disfraz_patty);
        leido_selma = fscanf(selma, FORMATO_LECTURA, disfraz_selma);
    }

    fclose(patty);
    fclose(selma);
    if(argc == CANTIDAD_ARGS_OPCIONAL){
        fclose(combinaciones);
    }

    return 0;
}

