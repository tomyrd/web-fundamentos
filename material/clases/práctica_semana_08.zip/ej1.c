#include <stdio.h>
#include <stdbool.h>
#include <string.h>


#define MAX_VINOS 30
#define MAX_NOMBRE 50

const char *VIOLETA = "\x1b[35m";
const char *RESET   = "\x1b[0m";
const char *NEGRITA = "\x1b[1m";




typedef struct vino{
    char nombre[MAX_NOMBRE];
    int edad;
} vino_t;

void inicializar_vinos(vino_t vinos[MAX_VINOS], int *tope) {
    strcpy(vinos[0].nombre, "Cosecha Moe Especial");
    vinos[0].edad = 2013;

    strcpy(vinos[1].nombre, "Merlot de Ned Flanders");
    vinos[1].edad = 2023;

    strcpy(vinos[2].nombre, "Tinto Don Barney");
    vinos[2].edad = 2025;

    strcpy(vinos[3].nombre, "Reserva Sr. Burns");
    vinos[3].edad = 2010;

    strcpy(vinos[4].nombre, "Rosado Marge Azul");
    vinos[4].edad = 2024;

    strcpy(vinos[5].nombre, "Cabernet de la Taberna");
    vinos[5].edad = 2020;

    strcpy(vinos[6].nombre, "Chardonnay Lisa Inteligente");
    vinos[6].edad = 2018;

    strcpy(vinos[7].nombre, "Shiraz del Payaso Krusty");
    vinos[7].edad = 2025;

    strcpy(vinos[8].nombre, "Pinot Noir del Jefe Gorgory");
    vinos[8].edad = 2024;

    strcpy(vinos[9].nombre, "Blanco de la Tienda de Apu");
    vinos[9].edad = 2022;

    strcpy(vinos[10].nombre, "Espumante Disco Stu");
    vinos[10].edad = 2021;

    strcpy(vinos[11].nombre, "Malbec Springfield");
    vinos[11].edad = 2018;

    strcpy(vinos[12].nombre, "Tinto del Inspector Chalmers");
    vinos[12].edad = 2020;

    strcpy(vinos[13].nombre, "Blend Milhouse Reserva");
    vinos[13].edad = 2025;

    strcpy(vinos[14].nombre, "Rose Patty y Selma");
    vinos[14].edad = 2016;

    *tope = 15;
}

void imprimir_vinos(vino_t vinos[], int tope) {

    int ESPACIO_NOMBRE = 55;

    printf("\n%32s%s%s%s\n", "", NEGRITA, "🍇🍷  VINOS DE MOE'S  🍷🍇", RESET);
    printf("\x1b[90m═════════════════════════════════════════════════════════════════════════════════════%s\n", RESET);

    printf("%s%-4s%-*s%s%s\n", NEGRITA, "#", ESPACIO_NOMBRE, "Nombre del vino", "Año", RESET);
    printf("\x1b[90m─────────────────────────────────────────────────────────────────────────────────────%s\n", RESET);

    for (int i = 0; i < tope; i++) {
        printf("%s%2d)%s %s%-*s%s\x1b[90;1m%4d%s 🍾\n",
               VIOLETA, i + 1, RESET,
               NEGRITA, ESPACIO_NOMBRE, vinos[i].nombre, RESET,
               vinos[i].edad, RESET);
    }

    printf("\x1b[90m═════════════════════════════════════════════════════════════════════════════════════%s\n\n", RESET);
}

bool es_mayor(vino_t vino_1, vino_t vino_2){
    if(vino_1.edad > vino_2.edad){
        return true;
    }else if(vino_1.edad == vino_2.edad){
        return strcmp(vino_1.nombre, vino_2.nombre) < 0;
    }
    return false;
}

void ordenar_vinos(vino_t vinos[MAX_VINOS], int tope_vinos)
{
    int j = 0;
    vino_t aux;

    for(int i = 1; i < tope_vinos; i++){
        j = i;
        aux = vinos[i];
        while(j > 0 && es_mayor(aux, vinos[j-1])){
            vinos[j] = vinos[j-1];
            j--;
        }
        vinos[j] = aux;
    }
}


int main()
{
    vino_t vinos[MAX_VINOS];
    int tope = 0;
    inicializar_vinos(vinos, &tope);
    imprimir_vinos(vinos, tope);
    

    ordenar_vinos(vinos, tope);
    imprimir_vinos(vinos, tope);

    return 0;
}