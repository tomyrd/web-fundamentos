// Si gastas más de $100.000, tenés un 20% de descuento pagando en efectivo
// Crear un programa que le pregunte a Marge el total de su compra en Kwik-E-Mart y qué medio de pago usó (los disponibles son: Efectivo, Crédito o Débito) y calcule cuánto debe pagar finalmente.

// MODULARIZACIón, BUENOS NOMBRES, CONSTANTES, indentación, NO ESCRIBIR COMENTARIOS INNECESARIOS EN EL CODIGO. NO USAR VARIABLES GLOBALES, SER CLAROS CON EL USUARIO.
// NO RETURN O BREAK DENTRO DE CICLOS.
#include <stdio.h>
#include <stdbool.h>

const char CREDITO = 'C';
const char DEBITO = 'D';
const char EFECTIVO = 'E';

const int GASTO_DESCUENTO = 100000;
const float DESCUENTO = 0.2;

// procedimiento: función que no tiene valor de retorno, se llaman con verbos en infinitivo. 
// la comunicación del usuario se hace en un procedimiento.

// pre son las condiciones que tienen que cumplir los parametros de entrada para que se cumpla lo que dice la post condicion (o sea, para que la funcion funcione bien). 

// pre: -
// post: se guarda en gasto el valor ingresado por el usuario.
void preguntar_gasto(int* gasto){
    printf("¿Cuánto gastaste Marge?\n");
    scanf("%i", gasto);
    while((*gasto) < 0) {
        printf("Marge no seas mentirosa flaca ¿Cuánto gastaste?\n");
        scanf("%i", gasto);
    }
}

// las funciones booleanas se llaman como lo que responden.

// pre: -
// post: devuelve true si medio_de_pago es EFECTIVO, DEBITO o CREDITO. False en caso contrario.
bool es_medio_de_pago_valido(char medio_de_pago) {
    return (medio_de_pago == CREDITO || medio_de_pago == EFECTIVO || medio_de_pago == DEBITO);
}

// pre: -
// post: se guarda en medio_de_pago un valor valido ingresado por el usuario.
void preguntar_medio_de_pago(char* medio_de_pago){
    printf("¿Cómo pagaste Marge?  (E)Efectivo, (C)Crédito o (D)Débito \n");
    scanf(" %c", medio_de_pago);
    while(!es_medio_de_pago_valido(*medio_de_pago)) {
        printf("Marge no seas mentirosa flaca ¿Cómo gastaste?  (E)Efectivo, (C)Crédito o (D)Débito\n");
        scanf(" %c", medio_de_pago);
    }
}

// las funciones se llaman como lo que devuelven

// pre: gasto debe ser mayor o igual a cero
// post: devuelve el gasto con o sin descuento
float total_a_pagar(float gasto, char medio_de_pago) {
    if(medio_de_pago == EFECTIVO && gasto > GASTO_DESCUENTO) {
        return gasto - (gasto * DESCUENTO);
    }
    return gasto;
}

// tipo de dato, nombre, parámetros
int main(){
    int gasto = -1; // inicializar variables
    char medio_de_pago = ' ';

    preguntar_gasto(&gasto);
    preguntar_medio_de_pago(&medio_de_pago);

    int total = total_a_pagar((float)gasto, medio_de_pago);

    printf("Lo que gastaste es %i\n", total);
    
    return 0;
}