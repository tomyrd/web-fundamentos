#include <stdio.h>

int main () {
    printf("Hola simpson mundo!\n");
    return 0;
}
