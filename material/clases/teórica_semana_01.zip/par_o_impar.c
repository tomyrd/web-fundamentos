#include <stdio.h>

int main () {
    int numero;
    printf("Ingrese un numero:\n");
    scanf("%i", &numero);

    if (numero % 2 == 0) {
        printf("es par, vas a morir moe wiii\n");
    }
    else {
        printf("es impar, ouchhh\n");
    }
    return 0;
}