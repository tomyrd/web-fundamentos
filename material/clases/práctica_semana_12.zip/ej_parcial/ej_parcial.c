#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_SONIDO 10
#define MAX_NOTAS 20

const int INTENSIDAD_MINIMA = 6;
const char* NOTA_BUSCADA = "RE";
const char* NOTA_ANTERIOR_BUSCADA = "LA";
const char CORCHEA = 'C';
const char SEMI_CORCHEA = 'S';


typedef struct nota {
	char sonido[MAX_SONIDO]; // "LA", "RE", ...
	char figura_musical; //Semicorchea('S'), corchea('C'), ...
	int duracion_ms;
	int intensidad;
	bool es_silencio;
} nota_t;


//pre: tope valido, ...
//post: devuelve true si ...
bool cumple_condicion_lisa(nota_t notas[MAX_NOTAS], int tope_notas, int posicion){
	bool cumple_condicion = false;
	if (notas[posicion].figura_musical == CORCHEA && !notas[posicion].es_silencio && notas[posicion].intensidad >= INTENSIDAD_MINIMA){
		cumple_condicion = true;
	}
	else if (posicion != 0){
		if (strcmp(notas[posicion-1].sonido, NOTA_ANTERIOR_BUSCADA) == 0 && notas[posicion-1].figura_musical == SEMI_CORCHEA) {
			cumple_condicion = true;
		}
	}
	return cumple_condicion;
}


//pre: tope_notas valido ...
//post: devuelve el promedio en ms de las notas buscadas
float promedio_duracion_notas_lisa(nota_t notas[MAX_NOTAS], int tope_notas, int posicion, int sumatoria_ms, int cantidad_notas_lisa){
	if (posicion >= tope_notas){
		if (cantidad_notas_lisa == 0){
			return 0.0f;
		}
		return (float)sumatoria_ms/cantidad_notas_lisa;
	}

	if (strcmp(notas[posicion].sonido, NOTA_BUSCADA) == 0){
		if (cumple_condicion_lisa(notas, tope_notas, posicion)){
			sumatoria_ms += notas[posicion].duracion_ms;
			cantidad_notas_lisa++;
		}
	}

	return promedio_duracion_notas_lisa(notas, tope_notas, posicion+1, sumatoria_ms, cantidad_notas_lisa);
}


int main() {
    nota_t notas[MAX_NOTAS] = {
        {"MI", 'S', 100, 5, false},
        {"RE", 'C', 200, 6, true},
        {"RE", 'C', 300, 8, false},
        {"LA", 'S', 100, 5, false},
        {"RE", 'C', 250, 4, false},

    };
    int tope_notas = 5;

    float promedio_duracion = promedio_duracion_notas_lisa(notas, tope_notas, 0, 0, 0);

    printf("Promedio de duraciones de notas Lisa: %f ms\n", promedio_duracion);
    return 0;
}