#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_SONIDO 10
#define MAX_NOTAS 20

typedef struct nota {
    char sonido[MAX_SONIDO]; // "LA", "RE", ...
    char figura_musical; // Semicorchea('S'), corchea('C'), ...
    int duracion_ms;
    int intensidad;
    bool es_silencio;
} nota_t;

const char* NOTA_BUSCADA = "RE";
const char CORCHEA = 'C';
const int INTENSIDAD_MINIMA = 6;

const char* NOTA_ANTERIOR_BUSCADA = "LA";
const char SEMICORCHEA = 'S';


// PRE: La posición tiene que ser igual o mayor a 0 y menor a MAX_NOTAS. El vector partitura está correctamente inicializado.
// POST: La nota en la posición que se recibe por parámetros cumple con las siguientes condiciones: 
// Es corchea, no esa silencios y tiene una intensidad mayor a 5 o la nota anterior es una nota "LA" semicorchea.
bool es_nota_valida(nota_t partitura[MAX_NOTAS], int posicion){
    if(strcmp(partitura[posicion].sonido, NOTA_BUSCADA) != 0){
        return false;
    }

    nota_t nota_actual = partitura[posicion];
    
    if(nota_actual.figura_musical == CORCHEA && !nota_actual.es_silencio && nota_actual.intensidad >= INTENSIDAD_MINIMA){
        return true;
    }

    if(posicion != 0){
        nota_t nota_anterior = partitura[posicion - 1];
        if(strcmp(nota_anterior.sonido, NOTA_ANTERIOR_BUSCADA) == 0 &&  nota_anterior.figura_musical == SEMICORCHEA){
            return true;
        }
    }
    return false;
}


/*
PRE: El tope es mayor o igual a 0 y menor a MAX_NOTAS y se corresponde con el vector. posicion, suma_duracion y cantidad_notas_validas tienen que ser 0.
POST: devuelve el promedio de la duración de las notas que cumplen con la condición pedida.
*/
int promedio_duracion_notas_rec(nota_t partitura[MAX_NOTAS], int tope_partitura, int posicion, int suma_duracion, int cantidad_notas_validas){
    if(posicion == tope_partitura){
        if(cantidad_notas_validas == 0){
            return 0;
        }
        else {
            return suma_duracion / cantidad_notas_validas;
        }
    }

    if(es_nota_valida(partitura, posicion)){
        suma_duracion += partitura[posicion].duracion_ms;
        cantidad_notas_validas++;
    }

    return promedio_duracion_notas_rec(partitura, tope_partitura, posicion + 1, suma_duracion, cantidad_notas_validas);
}


int promedio_duracion_notas_lisa(nota_t partitura[MAX_NOTAS], int tope_partitura){
    return promedio_duracion_notas_rec(partitura, tope_partitura, 0, 0, 0);
}



int main() {
    nota_t notas[MAX_NOTAS] = {
        {"MI", 'S', 100, 5, false},
        {"RE", 'C', 200, 6, true},
        {"RE", 'C', 300, 8, false},
        {"LA", 'S', 100, 5, false},
        {"RE", 'C', 250, 4, false},
    };
    int tope_notas = 5;

    float promedio_duracion = promedio_duracion_notas_lisa(notas, tope_notas);

    printf("Promedio de duraciones de notas Lisa: %f ms\n", promedio_duracion);
    return 0;
}