#include <stdio.h>
#include <stdbool.h>

#define MAX_NOMBRE 100
#define MAX_ELEMENTOS 20
#define MAX_COLOR 30
#define MAX 20
#define ELEMENTO_IMPORTANTE "mascota"

const int BARRIO_INVALIDO = -1;

typedef struct casa_robada {
    char elementos_robados[MAX_NOMBRE][MAX_ELEMENTOS];
    // "mascota", "saxofón", "horno", etc.
    int cant_elementos_robados;
    bool cerradura_forzada;
    char color_fachada[MAX_COLOR];
    int cant_familiares;
} casa_robada_t;

bool casa_robada_por_gato(casa_robada_t casa_robada){
    bool se_robo_mascota = false;

    for(int i = 0; i < casa_robada.cant_elementos_robados; i++){
        if(strcmp(casa_robada.elementos_robados[i], ELEMENTO_IMPORTANTE) == 0){
            se_robo_mascota = true;
        }
    }

    return casa_robada.cerradura_forzada && (casa_robada.cant_elementos_robados == casa_robada.cant_familiares || se_robo_mascota); 
}



int barrio_no_robado(casa_robada_t casas_robadas[MAX][MAX]){
    int barrio_no_robado = BARRIO_INVALIDO;
    for(int j = 0; j < MAX; j++){
        bool tiene_casa_robada = false;
        for(int i = 0; i < MAX; i++){
            if(casa_robada_por_gato(casas_robadas[i][j])) {
                tiene_casa_robada = true;
            }
        }
        if(!tiene_casa_robada){
            barrio_no_robado = j;
        }
    }

    return barrio_no_robado;
}