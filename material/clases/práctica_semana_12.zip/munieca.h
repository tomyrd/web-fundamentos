#ifndef MUNIECA_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_NOMBRE 100

/*
	Interfaz de un TDA muñeca.
	Las posiciones del vector de frases se numeran desde 0.
*/

typedef struct munieca{
    int id;
    char nombre[MAX_NOMBRE];
    char** frases;
    int cantidad_frases;
} munieca_t;


// Post: Crea un TDA muñeca. Devuelve un puntero a una muñeca.
//      Al terminar de usarlo debe ser destruido con liberar_munieca().
//   	Devuelve NULL si no se pudo crear.
munieca_t* munieca_crear(int id, char* nombre);


// Pre: `munieca` fue creado usando munieca_crear().
// Post: Agrega una frase al principio del vector de frases de la munieca, moviendo las frase hacia la derecha.
//   	Devuelve true si se pudo agregar, false en caso contrario.
bool agregar_frase(munieca_t* munieca, char* frase);


// Pre: `munieca` fue creado usando munieca_crear().
// Post: Devuelve la última frase del vector de frases de la munieca, quitándola del vector. Si esta vacía, devuelve NULL.
// Una vez usada la frase, hay que liberarla.
char* sacar_frase(munieca_t * munieca);

// Pre: `munieca` fue creado usando munieca_crear().
// Post: Destruye la muñeca creada.
void liberar_munieca(munieca_t* munieca);

#endif // MUNIECA_H