#ifndef TARJETA_H
#define TARJETA_H

#include <stdbool.h>
#define MAX_DESCRIPCION 200


typedef struct deuda {
   int monto_total;
   char descripcion[MAX_DESCRIPCION];
   int cantidad_cuotas;
   int cuota_actual;
} deuda_t;


typedef struct tarjeta {
   int limite_disponible;
   deuda_t* deudas;
   int cantidad_deudas;
} tarjeta_t;


// Post: Crea un TDA tarjeta de crédito. Devuelve un puntero a una tarjeta si se pudo crear o NULL en caso de error.
//       El límite debe ser mayor a 0. Al terminar de usarlo debe ser destruido con tarjeta_destruir().
tarjeta_t* tarjeta_crear(int limite);


// Pre: `tarjeta` fue creado usando tarjeta_crear().
// Post: Agrega una deuda a la tarjeta. Devuelve true si se pudo agregar, false en caso contrario. Para que se pueda agregar debe tener un monto menor al límite de la tarjeta y no debe superar el límite de la tarjeta.
bool agregar_deuda(tarjeta_t* tarjeta, deuda_t deuda);


// Pre: `tarjeta` fue creado usando tarjeta_crear().
// Post: Devuelve en dedua_sacada la deuda del principio del vector de la tarjeta, quitándola del mismo. Devuelve true si se pudo sacar, false en caso contrario.
bool sacar_deuda(tarjeta_t* tarjeta, deuda_t* deuda_sacada);


// Pre: `tarjeta` fue creado usando tarjeta_crear().
// Post: Destruye la tarjeta creada.
void tarjeta_destruir(tarjeta_t* tarjeta);


#endif // TARJETA_H
