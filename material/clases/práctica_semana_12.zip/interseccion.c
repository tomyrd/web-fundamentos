// pre: -'archivo1' debe apuntar a un archivo ordenado ascendentemente abierto con fopen en modo lectura.
// -'archivo2' debe apuntar a un archivo ordenado ascendentemente abierto con fopen en modo lectura.
// -'resultado' debe apuntar a un archivo abierto con fopen en modo escritura.
// post: devuelve por referencia de 'resultado' la intersección.
void intersecar_archivos(FILE* archivo1, FILE* archivo2, FILE* resultado) {
    // leo el primer elemento de archivo1
    int elemento1;
    int leidos1 = fscanf(archivo1, "%i\n", &elemento1);

    // leo el primer elemento de archivo2
    int elemento2;
    int leidos2 = fscanf(archivo2, "%i\n", &elemento2);

    // esto hasta que uno termine
    while(leidos1 != EOF && leidos2 != EOF) {
        if (elemento1 < elemento2) {
            // ignoramos elemento1 y avanzamos archivo1
            leidos1 = fscanf(archivo1, "%i\n", &elemento1);
        } else if (elemento1 > elemento2) {
            // ignoramos elemento2 y avanzamos archivo2
            leidos2 = fscanf(archivo2, "%i\n", &elemento2);
        } else {
            // imprimimos elemento1 o elemento2 en resultado y avanzamos ambos archivos
            fprintf(resultado, "%i\n", elemento2);
            leidos1 = fscanf(archivo1, "%i\n", &elemento1);
            leidos2 = fscanf(archivo2, "%i\n", &elemento2);
        }
    }
}
