#include <stdio.h>

#define MAX_DESCRIPCION 100
#define MAX_MISIONES 20

typedef struct mision {
    int id;
    int prioridad;
    char descripcion[MAX_DESCRIPCION];
} mision_t;

// [1 2 4 36 59 100]
const int NO_ESTA = -2;

int buscar_mision(mision_t misiones[MAX_MISIONES], int tope, int prioridad_buscada) {
    int inicio = 0;
    int fin = tope-1;
    int centro = (inicio + fin) / 2;

    while(misiones[centro].prioridad != prioridad_buscada && fin >= inicio) {
        if(misiones[centro].prioridad > prioridad_buscada) {
            fin = centro - 1;
        }
        else {
            inicio = centro + 1;
        }

        centro = (inicio + fin) / 2;

    }

    if(misiones[centro].prioridad == prioridad_buscada)
        return centro;

    return NO_ESTA;
}


// Crear una función que reciba un vector de mision_t ordenado 
// ascendentemente por prioridad, su tope y una nueva misión y 
// la agregue al mismo manteniendo el orden.

void mover_elementos(mision_t misiones[MAX_MISIONES], int *tope, int inicio_corrimiento) {
    (*tope)++;

    for(int i = (*tope)-2; i >= inicio_corrimiento; i--) {
        misiones[i+1] = misiones[i]; 
    }
}

int buscar_posicion(mision_t misiones[MAX_MISIONES], int tope, int prioridad_a_agregar) {
    // ???    
}

int main() {
    mision_t misiones[MAX_MISIONES] = {
        {0, 1, "Hacer el tp2 sin CHATGPT"},
        {1, 4, "Conquistar Disney porque somos CN"},
        {2, 8, "Matar a Perry"},
        {3, 20, "No usar return dentro de while"},
        {4, 41, "Conquistar Discovery Channel porque somos CN"},
        {5, 67, "Plantar un arbol"},
        {6, 69, "Conquistar Nickelodeon porque somos CN"},
        {7, 77, "Que Tomy aprenda que no somos de Disney"},
        {8, 92, "No compartir codigo"},
        {9, 100, "Traer torta en mi cumpleaños"},
    };
    int tope = 10;

    int pos_buscada = buscar_mision(misiones, tope, 78);
    if(pos_buscada == NO_ESTA) {
        printf("ufa no esta");
    }
    else {
        printf("la mision esta en la pos %i", pos_buscada);
    }
    return 0;
}