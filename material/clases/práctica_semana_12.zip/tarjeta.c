#include "tarjeta.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

tarjeta_t* tarjeta_crear(int limite) {
    if (limite <= 0) return NULL;

    tarjeta_t* tarjeta = malloc(sizeof(tarjeta_t));
    if (!tarjeta) return NULL;

    tarjeta->limite_disponible = limite;
    tarjeta->deudas = NULL;
    tarjeta->cantidad_deudas = 0;
    return tarjeta;
}


bool agregar_deuda(tarjeta_t* tarjeta, deuda_t deuda) {
    if (!tarjeta) return false;
    
    int cuotas_restantes = deuda.cantidad_cuotas - deuda.cuota_actual + 1;
    if (cuotas_restantes <= 0) return false;
    
    int monto_cuota = deuda.monto_total / deuda.cantidad_cuotas;
    int monto_restante = monto_cuota * cuotas_restantes;
    
    if (monto_restante > tarjeta->limite_disponible) return false;

    deuda_t* nuevas = realloc(tarjeta->deudas, (tarjeta->cantidad_deudas + 1) * sizeof(deuda_t));
    if (!nuevas) return false;

    tarjeta->deudas = nuevas;

    strcpy(tarjeta->deudas[tarjeta->cantidad_deudas].descripcion, deuda.descripcion);
    tarjeta->deudas[tarjeta->cantidad_deudas].monto_total = deuda.monto_total;
    tarjeta->deudas[tarjeta->cantidad_deudas].cantidad_cuotas = deuda.cantidad_cuotas;
    tarjeta->deudas[tarjeta->cantidad_deudas].cuota_actual = deuda.cuota_actual;

    tarjeta->limite_disponible -= monto_restante;

    tarjeta->cantidad_deudas++;
    return true;
}

bool sacar_deuda(tarjeta_t* tarjeta, deuda_t* deuda_sacada) {
    if (!tarjeta || tarjeta->cantidad_deudas == 0) return false;

    deuda_t deuda = tarjeta->deudas[0];

    for (int i = 1; i < tarjeta->cantidad_deudas; i++) {
        tarjeta->deudas[i - 1] = tarjeta->deudas[i];
    }

    tarjeta->cantidad_deudas--;
    
    int cuotas_restantes = deuda.cantidad_cuotas - deuda.cuota_actual + 1;
    int monto_cuota = deuda.monto_total / deuda.cantidad_cuotas;
    int monto_restante = monto_cuota * cuotas_restantes;
    
    // Devolver al límite solo lo que estaba ocupando
    tarjeta->limite_disponible += monto_restante;
    
    if (tarjeta->cantidad_deudas == 0) {
        free(tarjeta->deudas);
        tarjeta->deudas = NULL;
    } else {
        tarjeta->deudas = realloc(tarjeta->deudas, tarjeta->cantidad_deudas * sizeof(deuda_t));
    }

    *deuda_sacada = deuda;
    return true;
}

void tarjeta_destruir(tarjeta_t* tarjeta) {
    if (!tarjeta) return;

    free(tarjeta->deudas);
    free(tarjeta);
}
