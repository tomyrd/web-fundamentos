#include <stdio.h>
#include <stdbool.h>

#define MAX_LETRAS 50

bool es_vocal(char letra){
    return (letra == 'a' || letra == 'e'  ||letra == 'i' ||letra == 'o' ||letra == 'u' );
}

int cant_vocales_rec(char palabra[MAX_LETRAS], int i, int contador){
    // condicion de corte
    if(palabra[i] == '\0'){
        return contador;
    }
    // procesamiento
    if(es_vocal(palabra[i])){
        contador++;
    }
    // llamado recursivo con los parámetros
    return cant_vocales_rec(palabra, i+1, contador);
}

int cant_vocales(char palabra[MAX_LETRAS]){
    return cant_vocales_rec("otorrinolaringologo", 0, 0);
}

int main(){
    int cantidad_vocales = cant_vocales("otorrinolaringologo");
    printf("La cantidad de vocales es %i", cantidad_vocales);


    return 0;
}