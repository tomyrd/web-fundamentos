#include <stdio.h>
#include "tarjeta.h"

#define MAX_PALABRAS 2
#define MAX_LETRAS 50
const char* ARCH_DEUDAS = "deudas.csv";
const char* FORMATO_LECTURA = "%i;%[^;];%i;%i\n";
const char* FORMATO_ESCRITURA = "%i;%s;%i;%i\n";
const int ERROR = -1;
const int EXITO = 0;
const int LIMITE_TARJETA = 1000000;
const char PALABRAS_NAVIDENIAS[MAX_PALABRAS][MAX_LETRAS] = {"navidad", "fiestas"};

int inicializar_tarjeta(tarjeta_t* tarjeta){
    FILE* deudas = fopen(ARCH_DEUDAS, "r");
    if(!deudas){
        printf("Error al abrir el archivo de deudas\n");
        return ERROR;
    }

    deuda_t deuda_leida;
    int leidos = fscanf(deudas, FORMATO_LECTURA, &deuda_leida.monto_total, deuda_leida.descripcion, &deuda_leida.cantidad_cuotas, &deuda_leida.cuota_actual);
    bool se_pudo_agregar = true;
    while(leidos != EOF && se_pudo_agregar){
        se_pudo_agregar = agregar_deuda(tarjeta, deuda_leida);
        leidos = fscanf(deudas, FORMATO_LECTURA, &deuda_leida.monto_total, deuda_leida.descripcion, &deuda_leida.cantidad_cuotas, &deuda_leida.cuota_actual);
    }

    fclose(deudas);
    return EXITO;
}

bool es_deuda_navidenia(deuda_t deuda){
    bool esta = false;
    int i = 0;
    while(i < MAX_PALABRAS && !esta){
        esta = strstr(deuda.descripcion, PALABRAS_NAVIDENIAS[i]) != NULL;
        i++;
    }
    return esta;
}

int monto_restante_pagar(deuda_t deuda){
    int valor_cuota = deuda.monto_total / deuda.cantidad_cuotas;
    int cuotas_restantes = deuda.cantidad_cuotas - deuda.cuota_actual;

    return valor_cuota * cuotas_restantes;
}

int deudas_navidenias(tarjeta_t** tarjeta){
    deuda_t deuda;
    bool pudo_sacar = true;
    int deuda_total = 0;
    
    tarjeta_t* tarjeta_aux = tarjeta_crear(LIMITE_TARJETA);
    if(!tarjeta_aux){
        printf("No se pudo crear la tarjeta auxiliar\n");
        return ERROR;
    }

    bool pudo_agregar = true;
    while(pudo_sacar && pudo_agregar){
        pudo_sacar = sacar_deuda(tarjeta, &deuda);
        if(es_deuda_navidenia(deuda)){
            deuda_total += monto_restante_pagar(deuda);
        }
        pudo_agregar = agregar_deuda(tarjeta_aux, deuda);
    }
    
    tarjeta_destruir(*tarjeta);
    (*tarjeta) = tarjeta_aux;
    
    return deuda_total;
}

int guardar_deudas(tarjeta_t* tarjeta){
    FILE* deudas = fopen(ARCH_DEUDAS, "w");
    if(!deudas){
        printf("No se pudo abrir el archivo de deudas\n");
        return ERROR;
    } 

    deuda_t deuda;
    while(sacar_deuda(tarjeta, &deuda)){
        fprintf(deudas, FORMATO_ESCRITURA, deuda.monto_total, deuda.descripcion, deuda.cantidad_cuotas, deuda.cuota_actual);
    }

    fclose(deudas); 
    return EXITO;
}

int main(){
    tarjeta_t* tarjeta = tarjeta_crear(LIMITE_TARJETA);
    if(!tarjeta){
        printf("Hubo un error al crear la tarjeta\n");
        return ERROR;
    }

    if(inicializar_tarjeta(tarjeta) == ERROR){
        printf("No se pudo inicializar la tarjeta\n");
        tarjeta_destruir(tarjeta);
        return ERROR;
    }

    guardar_deudas(tarjeta);
    tarjeta_destruir(tarjeta);
    return 0;
}
