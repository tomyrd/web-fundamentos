#include <stdio.h>

#define MAX_ENANITO 20
#define MAX_ENANOS

const int ULTIMO_ENANITO = -1;

typedef struct enanito {
    char nombre[MAX_ENANITO];
    int proximo_enanito;
    int fuerza;
} enanito_t;


int posicion_menos_fuerte_rec(enanito_t enanitos[MAX_ENANOS], int pos_enanito_actual, int pos_menos_fuerte, int menor_fuerza){
    // condicion de corte
    if(pos_enanito_actual == ULTIMO_ENANITO){
        return pos_menos_fuerte;
    }

    printf("Soy el enanito %s y tire con %i de fuerza\n", enanitos[pos_enanito_actual].nombre, enanitos[pos_enanito_actual].fuerza);

    // procesamiento
    if(enanitos[pos_enanito_actual].fuerza < menor_fuerza){
        menor_fuerza = enanitos[pos_enanito_actual].fuerza;
        pos_menos_fuerte = pos_enanito_actual;
    }

    // llamado recursivo con parametros cambiados
    return posicion_menos_fuerte_rec(enanitos, enanitos[pos_enanito_actual].proximo_enanito, pos_menos_fuerte, menor_fuerza);

}


int posicion_menos_fuerte(enanito_t enanitos[MAX_ENANOS]){
    return posicion_menos_fuerte_rec(enanitos, 0, 0, enanitos[0].fuerza);
}



int main(){
    enanito_t enanitos[MAX_ENANOS] = {
        {"Gruñon", 3, 29},
        {"Feliz", 0, 10},
        {"Dormilon", -1, 19},
        {"Sabio", 2, 33}
    };

    int posicion = posicion_menos_fuerte(enanitos);

    printf("El enanito menos fuerte es %s en la posicion %i\n", enanitos[posicion].nombre, posicion);
    return 0;
}