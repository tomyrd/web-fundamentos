// pre: -'archivo1' debe apuntar a un archivo ordenado ascendentemente abierto con fopen en modo lectura.
// -'archivo2' debe apuntar a un archivo ordenado ascendentemente abierto con fopen en modo lectura.
// -'resultado' debe apuntar a un archivo abierto con fopen en modo escritura.
// post: devuelve por referencia de 'resultado' la diferencia simétrica.
void realizar_dif_simetrica_archivos(FILE* archivo1, FILE* archivo2, FILE* resultado) {
    // leo el primer elemento de archivo1
    int elemento1;
    int leidos1 = fscanf(archivo1, "%i\n", &elemento1);

    // leo el primer elemento de archivo2
    int elemento2;
    int leidos2 = fscanf(archivo2, "%i\n", &elemento2);

    // esto hasta que uno termine
    while(leidos1 != EOF && leidos2 != EOF) {
        if (elemento1 < elemento2) {
            // imprimimos elemento1 en resultado y avanzamos archivo1
            fprintf(resultado, "%i\n", elemento1);
            leidos1 = fscanf(archivo1, "%i\n", &elemento1);
        } else if (elemento1 > elemento2) {
            // imprimimos elemento2 en resultado y avanzamos archivo2
            fprintf(resultado, "%i\n", elemento2);
            leidos2 = fscanf(archivo2, "%i\n", &elemento2);
        } else {
            // avanzamos ambos archivos ignorando elemento1 y elemento2
            leidos1 = fscanf(archivo1, "%i\n", &elemento1);
            leidos2 = fscanf(archivo2, "%i\n", &elemento2);
        }
    }

    // meto todo lo del que no termino adentro
    while(leidos1 != EOF) {
        // imprimimos elemento1 en resultado y avanzamos archivo1
        fprintf(resultado, "%i\n", elemento1);
        leidos1 = fscanf(archivo1, "%i\n", &elemento1);
    }

    while(leidos2 != EOF) {
        // imprimimos elemento2 en resultado y avanzamos archivo2
        fprintf(resultado, "%i\n", elemento2);
        leidos2 = fscanf(archivo2, "%i\n", &elemento2);
    }

}
