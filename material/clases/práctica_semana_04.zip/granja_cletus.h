#ifndef GRANJA_CLETUS_H
#define GRANJA_CLETUS_H

#include <stdbool.h>

#define TAMAÑO_GRANJA 5
#define MAX_FAMILIARES 15

typedef struct familiar {
    char nombre[20];
    int edad;
    int fuerza;        // 1-10 (para cultivos pesados como papas)
    int experiencia;   // 1-10 (conocimiento de la granja)
    bool puede_trabajar;
    char especialidad; // (M) Maíz, (A) Alfalfa, (P) Papas, (T) Todo
} familiar_t;

// Prototipos de funciones

/*
 * PRE: -
 * POST: La matriz granja queda inicializada con valores válidos:
 *       'M' (Maíz), 'A' (Alfalfa), 'P' (Papas), 'N' (Nada/Vacío)
 */
void inicializar_granja(char granja[TAMAÑO_GRANJA][TAMAÑO_GRANJA]);

/*
 * PRE: -
 * POST: El vector familia_cletus queda inicializado con familiares válidos
 *       *total_familiares contiene la cantidad real de familiares inicializados
 *       Cada familiar tiene:
 *       - nombre: cadena válida no vacía
 *       - edad: valor entre 8 y 32
 *       - fuerza: valor entre 1 y 10
 *       - experiencia: valor entre 1 y 10
 *       - puede_trabajar: true si edad >= 12, false si edad < 12
 *       - especialidad: 'M', 'A', 'P', 'T', o 'N'
 */
void inicializar_familiares(familiar_t familia_cletus[MAX_FAMILIARES], int *total_familiares);

#endif
