#include "tesoros.h"
#include <stdbool.h>
#include <stdio.h>


// Pre: La posición del tesoro tiene que estar en los rangos del terreno
// Post: Si en la posición hay un pozo, guarda el tesoro en esa posición
void guardar_tesoro(char terreno[MAX_TERRENO][MAX_TERRENO], posicion_t pos_tesoro){
    if ( terreno[pos_tesoro.fila][pos_tesoro.columna] == POZO ) {
        terreno[pos_tesoro.fila][pos_tesoro.columna] = TESORO;
    }
}

/*  Pre condiciones: -
    Post condiciones: Devuelve la posición del primer pozo. Si no encuentra ninguno devuelve la posición {-1, -1}.
*/
posicion_t buscar_primer_pozo(char terreno[MAX_TERRENO][MAX_TERRENO]){
    // ACA HAY UN ERROR
    bool encontrado = false;
    int i = 0, j = 0;
    posicion_t pos_pozo = {-1, -1 };

    while( i < MAX_TERRENO && !encontrado ) {
        while ( j < MAX_TERRENO && !encontrado ) {
            if(terreno[i][j] == POZO){
                pos_pozo.fila = i;
                pos_pozo.columna = j;
                encontrado = true;
            }
            j++;
        }
        j = 0;
        i++;
    }
    i = 0;

    return pos_pozo;
}

void enterrar_tesoro(char terreno[MAX_TERRENO][MAX_TERRENO]){
    posicion_t pozo = buscar_primer_pozo(terreno);
    if (pozo.fila != -1 && pozo.columna != -1){
        guardar_tesoro(terreno, pozo);
    }
}
