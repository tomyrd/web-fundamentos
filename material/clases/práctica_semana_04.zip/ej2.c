#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_FIL 10
#define MAX_COL 10
#define MAX_CASAS_VISITAR 20

const int MIN_VALOR_CASA = 100000;

typedef struct coordenada {
	int fil;
	int col;
} coordenada_t;

typedef struct casa{
	bool quiere_donar;
	int valor_casa;	
	int cantidad_familiares;
} casa_t;

// pre: -
// post: devuelve true si la casa quiere donar y su valor es mayor a MIN_VALOR_CASA, false en caso contrario
bool es_casa_que_dona(casa_t casa){
    return (casa.quiere_donar && casa.valor_casa > MIN_VALOR_CASA);
}

// pre: la matriz barrio debe estar llena, tope_casas_a_visitar tiene que tener un valor entre 0 y MAX_CASAS_VISITAR
// post: devuelve la cantidad de casas que efectivamente quieren donar
int cant_casas_que_donan(casa_t barrio[MAX_FIL][MAX_COL], coordenada_t casas_a_visitar[MAX_CASAS_VISITAR], int tope_casas_a_visitar){
    int cant_donaciones = 0;
    for(int i = 0; i < tope_casas_a_visitar; i++){
        if(es_casa_que_dona(barrio[casas_a_visitar[i].fil][casas_a_visitar[i].col])){
            cant_donaciones++;
        }
    }

    return cant_donaciones;
}