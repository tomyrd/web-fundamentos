#include "granja_cletus.h"
#include <string.h>

void inicializar_granja(char granja[TAMAÑO_GRANJA][TAMAÑO_GRANJA]) {

    char granja_inicial[TAMAÑO_GRANJA][TAMAÑO_GRANJA] = {
        {'M', 'M', 'A', 'P', 'N'},
        {'M', 'A', 'A', 'P', 'P'},
        {'N', 'A', 'M', 'P', 'N'},
        {'M', 'M', 'N', 'A', 'A'},
        {'P', 'N', 'M', 'A', 'M'}
    };
    
    for (int i = 0; i < TAMAÑO_GRANJA; i++) {
        for (int j = 0; j < TAMAÑO_GRANJA; j++) {
            granja[i][j] = granja_inicial[i][j];
        }
    }
}

void inicializar_familiares(familiar_t familia_cletus[MAX_FAMILIARES], int *total_familiares) {
    
    strcpy(familia_cletus[0].nombre, "Brandine");
    familia_cletus[0].edad = 32;
    familia_cletus[0].fuerza = 6;
    familia_cletus[0].experiencia = 8;
    familia_cletus[0].puede_trabajar = true;
    familia_cletus[0].especialidad = 'T';
    
    strcpy(familia_cletus[1].nombre, "Dubya");
    familia_cletus[1].edad = 16;
    familia_cletus[1].fuerza = 8;
    familia_cletus[1].experiencia = 5;
    familia_cletus[1].puede_trabajar = true;
    familia_cletus[1].especialidad = 'P';
    
    strcpy(familia_cletus[2].nombre, "Incest");
    familia_cletus[2].edad = 14;
    familia_cletus[2].fuerza = 4;
    familia_cletus[2].experiencia = 6;
    familia_cletus[2].puede_trabajar = true;
    familia_cletus[2].especialidad = 'M';
    
    strcpy(familia_cletus[3].nombre, "Crystal Meth");
    familia_cletus[3].edad = 12;
    familia_cletus[3].fuerza = 3;
    familia_cletus[3].experiencia = 4;
    familia_cletus[3].puede_trabajar = true;
    familia_cletus[3].especialidad = 'A';

    strcpy(familia_cletus[4].nombre, "Gitmo");
    familia_cletus[4].edad = 8;
    familia_cletus[4].fuerza = 2;
    familia_cletus[4].experiencia = 2;
    familia_cletus[4].puede_trabajar = false;
    familia_cletus[4].especialidad = 'N';
    
    strcpy(familia_cletus[5].nombre, "Stabya");
    familia_cletus[5].edad = 18;
    familia_cletus[5].fuerza = 7;
    familia_cletus[5].experiencia = 7;
    familia_cletus[5].puede_trabajar = true;
    familia_cletus[5].especialidad = 'A';
    
    strcpy(familia_cletus[6].nombre, "Dermot");
    familia_cletus[6].edad = 15;
    familia_cletus[6].fuerza = 5;
    familia_cletus[6].experiencia = 3;
    familia_cletus[6].puede_trabajar = true;
    familia_cletus[6].especialidad = 'M';
    
    strcpy(familia_cletus[7].nombre, "Birthday");
    familia_cletus[7].edad = 10;
    familia_cletus[7].fuerza = 3;
    familia_cletus[7].experiencia = 1;
    familia_cletus[7].puede_trabajar = false;
    familia_cletus[7].especialidad = 'N';
    
    strcpy(familia_cletus[8].nombre, "Chloe");
    familia_cletus[8].edad = 17;
    familia_cletus[8].fuerza = 6;
    familia_cletus[8].experiencia = 8;
    familia_cletus[8].puede_trabajar = true;
    familia_cletus[8].especialidad = 'T';
    
    strcpy(familia_cletus[9].nombre, "Tiffany");
    familia_cletus[9].edad = 13;
    familia_cletus[9].fuerza = 4;
    familia_cletus[9].experiencia = 5;
    familia_cletus[9].puede_trabajar = true;
    familia_cletus[9].especialidad = 'P';
    
    *total_familiares = 10;
}
