#include "fundamendezRecMath.h"
#include <stdio.h>

int multiplicacion_rec(int num1, int num2){
    if(num1 == 0 || num2 == 0){
        return 0;
    }
    return num1 + multiplicacion_rec(num1, num2-1);
}


bool es_primo_rec_aux(int numero, int divisor){
    if(divisor == 1){
        return true;
    }
    if(numero%divisor == 0){
        return false;
    }
    return es_primo_rec_aux(numero, divisor -1);
}


bool es_primo_rec(int numero){
    return es_primo_rec_aux(numero, numero-1);
}


int factorial_rec(int numero){
    return 1;
}


void imprimir_fibonacci_rec(int numero){
    return;
}


int valor_maximo_rec(int vector[], int tope){
    return 1;
}



int valor_minimo_rec(int vector[], int tope){
    return 1;
}
