// Header guard
#ifndef __TESOROS_H__
#define __TESOROS_H__

#define MAX_TERRENO 5

#define POZO  'P'
#define CESPED 'C'
#define TESORO_FALSO 'F'
#define TESORO 'T'

typedef struct posicion {
    int fila;
    int columna;
} posicion_t;

// Pre: -
// Post: Guarda el tesoro en la posición del primer pozo
void enterrar_tesoro(char terreno[MAX_TERRENO][MAX_TERRENO]);

#endif
