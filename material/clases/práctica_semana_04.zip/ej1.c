#include "tesoros.h"
#include <stdio.h>

/*  Pre condiciones: -
    Post condiciones: Muestra por pantalla el terreno.
*/
void mostrar_terreno(char terreno[MAX_TERRENO][MAX_TERRENO]) {
    printf("\n");
    for(int i = 0; i < MAX_TERRENO; i++) {
        printf("\t");
        for(int j = 0; j < MAX_TERRENO; j++) {
            printf("| %c ", terreno[i][j]);
        }
        printf("|\n");
    }
    printf("\n");
}

int main() {
    char terrenito[MAX_TERRENO][MAX_TERRENO] = {
        {CESPED, TESORO_FALSO, CESPED, CESPED, CESPED},
        {CESPED, TESORO_FALSO, CESPED, TESORO_FALSO, CESPED},
        {TESORO_FALSO, CESPED, CESPED, POZO, CESPED},
        {CESPED, TESORO_FALSO, POZO, CESPED, CESPED},
        {POZO, TESORO_FALSO, TESORO_FALSO, CESPED, CESPED}
    };

    mostrar_terreno(terrenito);

    enterrar_tesoro(terrenito);

    mostrar_terreno(terrenito);
    return 0;
}
