#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_TITULO 100
#define MAX_GENERO 100
#define MAX_NOMBRE 100
#define MAX_CANCIONES 50
#define MAX_PARTICIPANTES 50

#define GENERO_BUSCADO "balada"
#define NOMBRE_PARTICIPANTE_BUSCADO "Homero"

const int MAXIMA_TOLERANCIA_VECINOS = 120;
const int MAX_BALADAS_PERMITIDAS = 2;
const int NO_ENCONTRADO = -1;

typedef struct cancion {
    char titulo[MAX_TITULO];     // Ej: "Spider Pig", "Mr. Plow"
    char genero[MAX_GENERO];     // Ej: "rock", "pop", "balada"
    int  duracion;               // en minutos
} cancion_t;

typedef struct participante {
    char nombre[MAX_NOMBRE]; // Ej: "Homero", "Barney", "Lenny"
    bool afinado;
    cancion_t canciones[MAX_CANCIONES];
    int tope_canciones;
} participante_t;

typedef struct karaoke {
    participante_t participantes[MAX_PARTICIPANTES]; 
    int tope_participantes;
    bool en_vivo;
} karaoke_t;

// pre: nombre y nombre_buscado debe ser un string (terminar en '\0')
// post: devuelve true si el nombre es igual a nombre_buscado, false caso contrario
bool es_nombre_buscado(char nombre[MAX_NOMBRE], char nombre_buscado[MAX_NOMBRE]){
    return strcmp(nombre, nombre_buscado) == 0;
}

/* 
    pre: 
        * nombre_participante_buscado debe ser un string (terminar en '\0')
        * el campo tope_participantes debe tener un valor entre 0 y MAX_PARTICIPANTES. 
        * los campos 'nombre' de los participante_t deben ser string (terminar en '\0')
    post: devuelve el índice en el que se encuentra el participante con nombre igual a nombre_participante_buscado, NO_ENCONTRADO en caso de que no se encuentre en el vector.
*/
int posicion_participante_buscado(karaoke_t karaoke, char nombre_participante_buscado[MAX_NOMBRE]){
    int i = 0;
    while(!es_nombre_buscado(karaoke.participantes[i].nombre, nombre_participante_buscado) && i < karaoke.tope_participantes){
        i++;
    }

    if(i == karaoke.tope_participantes){
        return NO_ENCONTRADO;
    }

    return i;
}

// pre: el campo 'tope_canciones' del participante_t debe tener un valor mayor o igual a 0 y menor a MAX_CANCIONES.
// post: devuelve la suma de las duraciones de todas las canciones que canta el participante
int duracion_canciones(participante_t participante){
    int suma_duraciones = 0;
    for(int i = 0; i < participante.tope_canciones; i++){
        suma_duraciones += participante.canciones[i].duracion;
    }

    return suma_duraciones;
}

/* 
    pre: 
        * El campo 'tope_participantes' debe tener un valor mayor o igual a 0 y menor a MAX_PARTICIPANTES.
        * Los campos 'nombre' de los participante_t deben ser un string (terminar en '\0').
        * Los campos 'tope_canciones' de los participante_t deben tener un valor mayor o igual a 0 y menor a MAX_CANCIONES.
        * Los campos 'titulo' y 'genero' de los cancion_t deben ser un string (terminar en '\0').
    post: devuelve la suma de las duraciones de todas las canciones que cantan todos los participantes del karaoke.
*/
int duracion_total_karaoke(karaoke_t karaoke){
    int duracion_total_karaoke = 0;
    for(int i = 0; i < karaoke.tope_participantes; i++){
        duracion_total_karaoke += duracion_canciones(karaoke.participantes[i]); // REUTILIZAMOS la función del ejercicio 1 (guiño guiño)
    }

    return duracion_total_karaoke;
}

// pre: -
// post: devuelve true si la duración total del karaoke es mayor a MAXIMA_TOLERANCIA_VECINOS (en minutos), false caso contrario
bool se_quejan_vecinos(karaoke_t karaoke){
    int duracion_total = duracion_total_karaoke(karaoke);
    return duracion_total > MAXIMA_TOLERANCIA_VECINOS;
}

// pre: el campos 'genero' de la canción deben ser un string (terminar en '\0').
// post: devuelve true si el género de la canción es igual a GENERO_BUSCADO, false en caso contrario
bool es_balada(cancion_t cancion){
    return strcmp(cancion.genero, GENERO_BUSCADO) == 0;
}

// pre: El campo 'tope_canciones' del participante debe tener un valor mayor o igual a 0 y menor a MAX_CANCIONES.
// post: devuelve true si el participante tiene 2 o más canciones cuyo género es balada
bool tiene_exceso_baladas(participante_t participante){
    int cant_baladas = 0;
    for(int i = 0; i < participante.tope_canciones; i++){
        if(es_balada(participante.canciones[i])){
            cant_baladas ++;
        }
    }

    return cant_baladas >= MAX_BALADAS_PERMITIDAS;
}

// pre: 'tope_participantes' debe tener un valor mayor o igual a 0 y menor a MAX_PARTICIPANTES.
// post: elimina del vector participantes los participantes que tengan 2 o más canciones cuyo género es balada
void eliminar_participantes_exceso_baladas(participante_t participantes[MAX_PARTICIPANTES], int* tope_participantes){
    for(int i = 0; i < (*tope_participantes); i++){
        if(tiene_exceso_baladas(participantes[i])){
            participantes[i] = participantes[(*tope_participantes)-1];
            (*tope_participantes)--;
            i--;
        }
    }
}

int main(){
    karaoke_t karaoke; // Habría que inicializar todo el struct

    // a.
    int pos_homero = posicion_participante_buscado(karaoke, NOMBRE_PARTICIPANTE_BUSCADO);

    int duracion = duracion_canciones(karaoke.participantes[pos_homero]);

    printf("Homero canta por %i minutos\n", duracion);

    // b.
    if(se_quejan_vecinos(karaoke)){
        printf("Se van a re quejar!!\n");
    }else{
        printf("Todo legallll\n");
    }

    // c.
    eliminar_participantes_exceso_baladas(karaoke.participantes, &(karaoke.tope_participantes));
    // acá se podría imprimir el vector de participantes, o lo que se necesite 
    return 0;
}