#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_MATERIAL 50
#define MAX_NOMBRE 50
#define MAX_GRAFITIS 20
#define MAX_PUPITRES 5
#define MAX_ALUMNOS 20

const int CANT_GRAFFITIS_MIN = 2;
const int CANT_PATAS_ROTAS_NECESARIAS = 4;
#define MATERIAL_BUSCADO "liquid paper"

typedef struct graffiti {
    char material_usado[MAX_MATERIAL]; // pintura, lapicera, liquid paper
    int tamanio;
} graffiti_t;

typedef struct pupitre {
    char alumno[MAX_NOMBRE];
    graffiti_t graffitis[MAX_GRAFITIS];
    int cantidad_graffitis;
    int cant_patas_rotas;
} pupitre_t;

void inicializar_pupitres(pupitre_t pupitres[MAX_PUPITRES][MAX_PUPITRES]) {
    // --- Fila 0 ---
    strcpy(pupitres[0][0].alumno, "Bart");
    pupitres[0][0].cant_patas_rotas = 4;
    strcpy(pupitres[0][0].graffitis[0].material_usado, "lapicera");
    pupitres[0][0].graffitis[0].tamanio = 15;
    strcpy(pupitres[0][0].graffitis[1].material_usado, "pintura");
    pupitres[0][0].graffitis[1].tamanio = 20;
    pupitres[0][0].cantidad_graffitis = 2;

    strcpy(pupitres[0][1].alumno, "Lisa");
    pupitres[0][1].cant_patas_rotas = 0;
    strcpy(pupitres[0][1].graffitis[0].material_usado, "liquid paper");
    pupitres[0][1].graffitis[0].tamanio = 10;
    pupitres[0][1].cantidad_graffitis = 1;

    strcpy(pupitres[0][2].alumno, "Maggie");
    pupitres[0][2].cant_patas_rotas = 1;
    strcpy(pupitres[0][2].graffitis[0].material_usado, "pintura");
    pupitres[0][2].graffitis[0].tamanio = 12;
    pupitres[0][2].cantidad_graffitis = 1;

    strcpy(pupitres[0][3].alumno, "Marge");
    pupitres[0][3].cant_patas_rotas = 2;
    strcpy(pupitres[0][3].graffitis[0].material_usado, "lapicera");
    pupitres[0][3].graffitis[0].tamanio = 8;
    pupitres[0][3].cantidad_graffitis = 1;

    strcpy(pupitres[0][4].alumno, "Homero");
    pupitres[0][4].cant_patas_rotas = 3;
    strcpy(pupitres[0][4].graffitis[0].material_usado, "pintura");
    pupitres[0][4].graffitis[0].tamanio = 25;
    pupitres[0][4].cantidad_graffitis = 1;

    // --- Fila 1 ---
    strcpy(pupitres[1][0].alumno, "Milhouse");
    pupitres[1][0].cant_patas_rotas = 1;
    strcpy(pupitres[1][0].graffitis[0].material_usado, "lapicera");
    pupitres[1][0].graffitis[0].tamanio = 10;
    pupitres[1][0].cantidad_graffitis = 1;

    strcpy(pupitres[1][1].alumno, "Nelson");
    pupitres[1][1].cant_patas_rotas = 4;
    strcpy(pupitres[1][1].graffitis[0].material_usado, "pintura");
    pupitres[1][1].graffitis[0].tamanio = 30;
    pupitres[1][1].cantidad_graffitis = 1;

    strcpy(pupitres[1][2].alumno, "Ralph");
    pupitres[1][2].cant_patas_rotas = 0;
    strcpy(pupitres[1][2].graffitis[0].material_usado, "liquid paper");
    pupitres[1][2].graffitis[0].tamanio = 5;
    pupitres[1][2].cantidad_graffitis = 1;

    strcpy(pupitres[1][3].alumno, "Skinner");
    pupitres[1][3].cant_patas_rotas = 2;
    strcpy(pupitres[1][3].graffitis[0].material_usado, "lapicera");
    pupitres[1][3].graffitis[0].tamanio = 18;
    pupitres[1][3].cantidad_graffitis = 1;

    strcpy(pupitres[1][4].alumno, "Moe");
    pupitres[1][4].cant_patas_rotas = 3;
    strcpy(pupitres[1][4].graffitis[0].material_usado, "pintura");
    pupitres[1][4].graffitis[0].tamanio = 22;
    pupitres[1][4].cantidad_graffitis = 1;

    // --- Fila 2 ---
    strcpy(pupitres[2][0].alumno, "Apu");
    pupitres[2][0].cant_patas_rotas = 2;
    strcpy(pupitres[2][0].graffitis[0].material_usado, "lapicera");
    pupitres[2][0].graffitis[0].tamanio = 7;
    pupitres[2][0].cantidad_graffitis = 1;

    strcpy(pupitres[2][1].alumno, "Krusty");
    pupitres[2][1].cant_patas_rotas = 1;
    strcpy(pupitres[2][1].graffitis[0].material_usado, "pintura");
    pupitres[2][1].graffitis[0].tamanio = 14;
    pupitres[2][1].cantidad_graffitis = 1;

    strcpy(pupitres[2][2].alumno, "Burns");
    pupitres[2][2].cant_patas_rotas = 4;
    strcpy(pupitres[2][2].graffitis[0].material_usado, "liquid paper");
    pupitres[2][2].graffitis[0].tamanio = 11;
    pupitres[2][2].cantidad_graffitis = 1;

    strcpy(pupitres[2][3].alumno, "Smithers");
    pupitres[2][3].cant_patas_rotas = 3;
    strcpy(pupitres[2][3].graffitis[0].material_usado, "pintura");
    pupitres[2][3].graffitis[0].tamanio = 9;
    pupitres[2][3].cantidad_graffitis = 1;

    strcpy(pupitres[2][4].alumno, "Lenny");
    pupitres[2][4].cant_patas_rotas = 0;
    strcpy(pupitres[2][4].graffitis[0].material_usado, "lapicera");
    pupitres[2][4].graffitis[0].tamanio = 13;
    pupitres[2][4].cantidad_graffitis = 1;

    // --- Fila 3 ---
    strcpy(pupitres[3][0].alumno, "Carl");
    pupitres[3][0].cant_patas_rotas = 2;
    strcpy(pupitres[3][0].graffitis[0].material_usado, "pintura");
    pupitres[3][0].graffitis[0].tamanio = 16;
    pupitres[3][0].cantidad_graffitis = 1;

    strcpy(pupitres[3][1].alumno, "Flanders");
    pupitres[3][1].cant_patas_rotas = 1;
    strcpy(pupitres[3][1].graffitis[0].material_usado, "liquid paper");
    pupitres[3][1].graffitis[0].tamanio = 6;
    pupitres[3][1].cantidad_graffitis = 1;

    strcpy(pupitres[3][2].alumno, "Patty");
    pupitres[3][2].cant_patas_rotas = 4;
    strcpy(pupitres[3][2].graffitis[0].material_usado, "lapicera");
    pupitres[3][2].graffitis[0].tamanio = 19;
    pupitres[3][2].cantidad_graffitis = 1;

    strcpy(pupitres[3][3].alumno, "Selma");
    pupitres[3][3].cant_patas_rotas = 3;
    strcpy(pupitres[3][3].graffitis[0].material_usado, "pintura");
    pupitres[3][3].graffitis[0].tamanio = 24;
    pupitres[3][3].cantidad_graffitis = 1;

    strcpy(pupitres[3][4].alumno, "Otto");
    pupitres[3][4].cant_patas_rotas = 0;
    strcpy(pupitres[3][4].graffitis[0].material_usado, "lapicera");
    pupitres[3][4].graffitis[0].tamanio = 12;
    pupitres[3][4].cantidad_graffitis = 1;

    // --- Fila 4 ---
    strcpy(pupitres[4][0].alumno, "Martin");
    pupitres[4][0].cant_patas_rotas = 1;
    strcpy(pupitres[4][0].graffitis[0].material_usado, "pintura");
    pupitres[4][0].graffitis[0].tamanio = 14;
    pupitres[4][0].cantidad_graffitis = 1;

    strcpy(pupitres[4][1].alumno, "Edna");
    pupitres[4][1].cant_patas_rotas = 2;
    strcpy(pupitres[4][1].graffitis[0].material_usado, "liquid paper");
    pupitres[4][1].graffitis[0].tamanio = 9;
    pupitres[4][1].cantidad_graffitis = 1;

    strcpy(pupitres[4][2].alumno, "Willie");
    pupitres[4][2].cant_patas_rotas = 4;
    strcpy(pupitres[4][2].graffitis[0].material_usado, "lapicera");
    pupitres[4][2].graffitis[0].tamanio = 18;
    pupitres[4][2].cantidad_graffitis = 1;

    strcpy(pupitres[4][3].alumno, "Jimbo");
    pupitres[4][3].cant_patas_rotas = 3;
    strcpy(pupitres[4][3].graffitis[0].material_usado, "pintura");
    pupitres[4][3].graffitis[0].tamanio = 20;
    pupitres[4][3].cantidad_graffitis = 1;

    strcpy(pupitres[4][4].alumno, "Barney");
    pupitres[4][4].cant_patas_rotas = 0;
    strcpy(pupitres[4][4].graffitis[0].material_usado, "liquid paper");
    pupitres[4][4].graffitis[0].tamanio = 11;
    pupitres[4][4].cantidad_graffitis = 1;
}

void mostrar_pupitres(pupitre_t pupitres[MAX_PUPITRES][MAX_PUPITRES]) {
    for (int i = 0; i < MAX_PUPITRES; i++) {
        for (int j = 0; j < MAX_PUPITRES; j++) {
            printf("Pupitre[%d][%d]\n", i, j);
            printf("  Alumno: %s\n", pupitres[i][j].alumno);
            printf("  Patas rotas: %d\n", pupitres[i][j].cant_patas_rotas);
            printf("  Cantidad de graffitis: %d\n", pupitres[i][j].cantidad_graffitis);
            
            for (int k = 0; k < pupitres[i][j].cantidad_graffitis; k++) {
                printf("    Graffiti %d -> material: %s, tamaño: %d\n",
                       k + 1,
                       pupitres[i][j].graffitis[k].material_usado,
                       pupitres[i][j].graffitis[k].tamanio);
            }
            printf("\n");
        }
    }
}

// Los que están en peores condiciones son aquellos que:
// ● Tengan por lo menos una pata rota y dos graffitis.
// ● o tenga las cuatro patas rotas
// ● o tengan un graffiti hecho con liquid paper.


bool hay_graffiti_liquid(graffiti_t graffitis[MAX_GRAFITIS], int cantidad_graffitis){
    int i = 0;
    bool encontrado = false;
    while(i < cantidad_graffitis && !encontrado){
        if(strcmp(graffitis[i].material_usado, MATERIAL_BUSCADO) == 0){
            encontrado = true;
        }
        i++;
    }

    return encontrado;
}

bool es_pupitre_arruinado(pupitre_t pupitre){
    return ((pupitre.cant_patas_rotas > 0 && pupitre.cantidad_graffitis >= CANT_GRAFFITIS_MIN) || 
    pupitre.cant_patas_rotas == CANT_PATAS_ROTAS_NECESARIAS || hay_graffiti_liquid(pupitre.graffitis, pupitre.cantidad_graffitis));
}

void filtrar_pupitres(pupitre_t pupitres[MAX_PUPITRES][MAX_PUPITRES], char nombres_alumnos[MAX_NOMBRE][MAX_ALUMNOS], int fila, int columna, int* tope_nombres_alumnos){
    if(fila >= MAX_PUPITRES){
        return; 
    }

    if(es_pupitre_arruinado(pupitres[fila][columna])){
        strcpy(nombres_alumnos[(*tope_nombres_alumnos)], pupitres[fila][columna].alumno);
        (*tope_nombres_alumnos)++;
    }

    if(columna == MAX_PUPITRES - 1){
        filtrar_pupitres(pupitres, nombres_alumnos, fila+1, 0, tope_nombres_alumnos);
    }else{
        filtrar_pupitres(pupitres, nombres_alumnos, fila, columna+1, tope_nombres_alumnos);
    }
}

int main(){
    pupitre_t pupitres[MAX_PUPITRES][MAX_PUPITRES];
    char nombres_alumnos[MAX_NOMBRE][MAX_ALUMNOS];
    int tope_alumnos = 0;

    inicializar_pupitres(pupitres);
    filtrar_pupitres(pupitres, nombres_alumnos, 0, 0, &tope_alumnos);

    for(int i = 0; i < tope_alumnos; i++){
        printf("%s \n", nombres_alumnos[i]);
    }
    // mostrar_pupitres(pupitres);
    return 0;
}