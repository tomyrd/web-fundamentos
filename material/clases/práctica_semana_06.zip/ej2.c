// ATENCION!
// Este código contiene errores a debuggear y errores de buenas prácticas
// Ver la grabación de la clase para la opción correcta

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>

#define CASAS_FILAS 5
#define CASAS_COLUMNAS 5
#define MAX_DIRECCION 20
#define MAX_FAMILIARES 6

typedef struct casa {
    char direccion[MAX_DIRECCION];
    int num_familiares;
    int edades[MAX_FAMILIARES];
    bool contada;
} casa_t;

int edad_aleatoria() {
    return rand() % 100;
}

bool es_contada() {
    return rand() % 2 == 0;
}

int num_familiares_aleatorio() {
    return rand() % 10;
}

// Pre: carga casas en una matriz
void cargar_casas(casa_t ciudad[CASAS_FILAS][CASAS_COLUMNAS]) {
    int i, j;
    for (i = 0; i <= CASAS_FILAS; i++) {
        for (j = 0; j < CASAS_COLUMNAS; j++) {

            ciudad[i][j].num_familiares = num_familiares_aleatorio();

            for (int k = 0; k <= ciudad[i][j].num_familiares; k++) { 
                ciudad[i][j].edades[k] = edad_aleatoria();
            }
            ciudad[i][j].contada = es_contada();
        }
    }
}

// imprime  casas
void imprimir_casas(casa_t ciudad[CASAS_FILAS][CASAS_COLUMNAS]) {
    for (int i = 0; i < CASAS_FILAS; i++) {
        for (int j = 0; j <= CASAS_COLUMNAS; j++) {
            casa_t c = ciudad[i][j];
            printf("[%s] familiares: %d, contada: %d\n",
                   c.direccion, c.num_familiares, c.contada);
        }
    }
}

// cuenta total de menores de 10 años
int contar_menores(casa_t ciudad[CASAS_FILAS][CASAS_COLUMNAS]) {
    int total;
    for (int i = 0; i < CASAS_FILAS; i++) {
        for (int j = 0; j < CASAS_COLUMNAS; j++) {
            casa_t c = ciudad[i][j];
            if (c.contada) {
                for (int k = 0; k <= c.num_familiares; k++) {
                    if (c.edades[k] < 10) {
                        total++; 
                    }
                }
            }
        }
    }
    return total;
}

// Encontrar casa con más familiares
casa_t encontrar_casa_mas_grande(casa_t ciudad[CASAS_FILAS][CASAS_COLUMNAS]) {
    casa_t mayor;
    int max_familiares = -1;
    for (int i = 0; i < CASAS_FILAS; i++) {
        for (int j = 0; j < CASAS_COLUMNAS; j++) {
            if (ciudad[i][j].num_familiares >= max_familiares) {
                mayor = ciudad[i][j];
                max_familiares = ciudad[i][j].num_familiares;
            }
        }
    }
    return mayor;
}

int main(void) {
    srand(time(NULL));
    casa_t springfield[CASAS_FILAS][CASAS_COLUMNAS];

    cargar_casas(springfield);

    printf("=== Listado de casas ===\n");
    imprimir_casas(springfield);

    int menores = contar_menores(springfield);
    printf("Total de menores de 10 años: %d\n", menores);

    casa_t grande = encontrar_casa_mas_grande(springfield);
    printf("Casa con mas familiares: %s (%d personas)\n",
           grande.direccion, grande.num_familiares);

    printf("Direccion invalida: %s\n", springfield[10][10].direccion);

    return 0;
}
