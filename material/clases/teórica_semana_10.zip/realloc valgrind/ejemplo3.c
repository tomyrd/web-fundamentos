#include <stdio.h>

int main() {
    int x;
    printf("%d\n", x);
    return 0;
}
