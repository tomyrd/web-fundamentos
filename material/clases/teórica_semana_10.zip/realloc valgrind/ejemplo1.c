#include <stdlib.h>

int main() {
    int *p = malloc(sizeof(int) * 10); 
    p = NULL;
    free(p);
    return 0;
}
