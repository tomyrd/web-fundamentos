#include <stdio.h>
#include <stdlib.h> // malloc() y free() son funciones de esta bibliteca

typedef struct alumno {
    char* nombre_apellido;
    int padron;
} alumno_t;


/* Pre condiciones: El parámetro 'descripcion' tiene que ser un string (finalizar con '\0').
 * Post condiciones: Solicita al usuario mostrando por pantalla 'descripcion' y devuelve por referencia un valor entero mayor a 0.
 */
void pedir_cantidad_natural(int* cantidad, char descripcion[]) {
    printf("%s\n", descripcion);
    scanf("%i", cantidad);

    while((*cantidad) <= 0) {
        printf("Cantidad ingresada inválida. Ingrese un valor entero positivo\n%s\n", descripcion);
        scanf("%i", cantidad);
    }
}


int main () {
    int cantidad_letras_nombre;
    int cantidad_letras_apellido;
    alumno_t alumno;

    pedir_cantidad_natural(&cantidad_letras_nombre, "PERSONA1 ¿Cuántas letras tiene su primer nombre?");
    pedir_cantidad_natural(&cantidad_letras_apellido, "PERSONA1 ¿Cuántas letras tiene su primer apellido?");

    alumno.nombre_apellido = malloc((cantidad_letras_nombre + cantidad_letras_apellido + 2) * sizeof(char)); // 1 extra por el espacio y 1 extra por el '\0'

    printf("PERSONA1 Ingrese su nombre y apellido\n");
    scanf(" %[^\n]", alumno.nombre_apellido);

    pedir_cantidad_natural(&(alumno.padron), "¿Cuál es su padrón?");

    printf("PERSONA1 El padrón %i corresponde al alumno %s\n", alumno.padron, alumno.nombre_apellido);


    pedir_cantidad_natural(&cantidad_letras_nombre, "PERSONA2 ¿Cuántas letras tiene su primer nombre?");
    pedir_cantidad_natural(&cantidad_letras_apellido, "PERSONA2 ¿Cuántas letras tiene su primer apellido?");

    alumno.nombre_apellido = realloc(alumno.nombre_apellido, (cantidad_letras_nombre + cantidad_letras_apellido + 2) * sizeof(char)); // 1 extra por el espacio y 1 extra por el '\0'

    printf("PERSONA2 Ingrese su nombre y apellido\n");
    scanf(" %[^\n]", alumno.nombre_apellido);

    pedir_cantidad_natural(&(alumno.padron), "¿Cuál es su padrón?");

    printf("PERSONA2 El padrón %i corresponde al alumno %s\n", alumno.padron, alumno.nombre_apellido);

    free(alumno.nombre_apellido);

    return 0;
}