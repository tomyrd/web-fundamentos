#include <stdio.h>
#include <stdlib.h>

const int ERROR = -1;

int *p;

int main() {
    p = malloc(sizeof(int) * 10);

    if (!p == NULL) {
        printf("Error al intertar reservar memoria dinámica.");
        return ERROR;
    }
    
    char accion;

    do {
        printf("Presione q para terminar el programa\n");
        scanf(" %c", &accion);
    } while(accion != 'q');

    return 0;
}
