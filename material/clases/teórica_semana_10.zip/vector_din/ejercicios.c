#include <stdio.h>
#include "vector_din.h"

// crear una funcion que dado un tda vector dinamico obtengamos el maximo valor del vector dinamico

const int NO_HAY_MAXIMO = -1;

// Pre: `vec` fue creado usando vec_crear().
// Post: devuelve el maximo valor del vector dinamico o -1 en caso de no haber.
int obtener_maximo(vector_din_t* vec) {
    int maximo_actual = NO_HAY_MAXIMO;

    size_t largo = vec_largo(vec);
    for (int i = 0; i < largo; i++) {
        int* elemento = vec_obtener(vec, i);
        if(elemento != NULL && *elemento > maximo_actual) {
            maximo_actual = *elemento;
        }
    }
    
    return maximo_actual;
}

// crear una funcion que devuelva el promedio de los valores del vector
// Pre: `vec` fue creado usando vec_crear().
// Post: devuelve por retorno de la función el promedio de valores del vector dinamico.
float obtener_promedio(vector_din_t* vec) {
    int sumatoria = 0;
    size_t largo = vec_largo(vec);
    for (int i = 0; i < largo; i++) {
        int* elemento = vec_obtener(vec, i);
        if(elemento != NULL) {
            sumatoria += *elemento;
        }
    }
    
    return sumatoria / largo;
}

// crear una función que dado un vector dinamico sume 1 a todos sus valores pares
// Pre: `vec` fue creado usando vec_crear().
// Post: aumenta en 1 el valor de todos los elementos pares
void modificar_pares(vector_din_t* vec) {
    size_t largo = vec_largo(vec);
    for (int i = 0; i < largo; i++) {
        int* elemento = vec_obtener(vec, i);
        if(elemento != NULL && ((*elemento) % 2) == 0) {
            (*elemento)++;
        }
    }
}


//crear una funcion que dado un vector dinamico devuelva uno nuevo sin los elementos pares
// Pre: `vec` fue creado usando vec_crear().
// Post: Devuelve un punter a un vector dinámico con los valores de 'vec' menos los pares.
//       Devuelve NULL si no se puede quitar los pares.
vector_din_t* quitar_pares(vector_din_t* vec){
    vector_din_t* aux = vec_crear();

    if (aux == NULL) {
        printf("Error al crear un vector dinamico auxiliar.");
        return NULL;
    }

    size_t largo = vec_largo(vec);
    for (int i = 0; i < largo; i++) {
        int* elemento = vec_obtener(vec, i);
        if(elemento != NULL && ((*elemento) % 2) != 0) {
            vec_guardar(aux, *elemento);
        }
    }

    return aux;
}


//crear una funcion que dado un vector dinamico le quite los elementos pares.
// Pre: `vec` fue creado usando vec_crear().
// Post: modifica 'vec' quitando los valores impares.
void quitar_pares_reemplazando(vector_din_t* *vec){
    vector_din_t* aux = vec_crear();

    if (aux == NULL) {
        printf("Error al crear un vector dinamico auxiliar.");
        return;
    }

    size_t largo = vec_largo(*vec);
    for (int i = 0; i < largo; i++) {
        int* elemento = vec_obtener(*vec, i);
        if(elemento != NULL && ((*elemento) % 2) != 0) {
            vec_guardar(aux, *elemento);
        }
    }

    vec_destruir(*vec);

    *vec = aux;
}
