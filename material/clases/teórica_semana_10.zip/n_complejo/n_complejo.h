#ifndef N_COMPLEJO_H
#define N_COMPLEJO_H

typedef struct n_complejo n_complejo_t;

// Crea un número complejo con parte real e imaginaria
n_complejo_t* ncomp_crear(double real, double imag);

// Destruye un número complejo liberando la memoria
void ncomp_destruir(n_complejo_t* num);

// Suma dos números complejos
n_complejo_t* ncomp_sumar(const n_complejo_t* a, const n_complejo_t* b);

// Resta dos números complejos
n_complejo_t* ncomp_restar(const n_complejo_t* a, const n_complejo_t* b);

// Multiplica dos números complejos
n_complejo_t* ncomp_multiplicar(const n_complejo_t* a, const n_complejo_t* b);

// Divide dos números complejos
n_complejo_t* ncomp_dividir(const n_complejo_t* a, const n_complejo_t* b);

// Devuelve el conjugado de un número complejo
n_complejo_t* ncomp_conjugado(const n_complejo_t* a);

// Imprime el número complejo en formato a + bi
void ncomp_imprimir(const n_complejo_t* a);

#endif // N_COMPLEJO_H
