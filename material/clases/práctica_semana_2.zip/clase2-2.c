#include <stdio.h>
#include <stdbool.h>

const int SIN_NOTA = -1;
const int NO_MAS_NOTAS = 0;
const int NOTA_MINIMA = 0;
const int NOTA_MAXIMA = 10;

// post: devuelve verdadero si la nota es invalida (no está entre 0 y 10)
//       caso contrario devuelve falso.
bool es_nota_invalida(int nota){
    return nota < NOTA_MINIMA || nota > NOTA_MAXIMA;
}

// pre: completar!
// post: completar!
void pedir_nota(int* nota){
    printf("Por favor ingresar nota\nPara terminar ingresar 0\n");
    scanf("%i", nota);
    while(es_nota_invalida(*nota)) {
        printf("Nota ingresada inválida. Reingrese un valor entre 1 y 10\nPara terminar ingresar 0\n");
        scanf("%i", nota); // ¿por qué piensan que no es necesario el & acá?
    }
}

// pre: completar!
// post: completar!
void preguntar_notas(int* cantidad_notas, int* suma_notas) {
    int nota = SIN_NOTA;

    while(nota != NO_MAS_NOTAS) {
        pedir_nota(&nota);

        if(nota != NO_MAS_NOTAS) {
            (*cantidad_notas)++;
            (*suma_notas) += nota;
        }
    }
}

int main(){
    int cantidad_notas = 0;
    int suma_notas = 0;

    preguntar_notas(&cantidad_notas, &suma_notas);

    int promedio = suma_notas / cantidad_notas;
    printf("El promedio de notas es %i\n", promedio);

    return 0;
}