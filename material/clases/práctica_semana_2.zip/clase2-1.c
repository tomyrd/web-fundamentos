#include <stdio.h>
/*precondiciones: condiciones sobre los
parámetros de entrada. (en este caso 
cantidad_alumnos)
postcondiciones: qué hace la función y las 
condiciones sobre los parámetros de salida,
siempre y cuando se cumplan las precondiciones
*/

/*
pre: cantidad_alumnos tiene un valor mayor a 0.
post: imprime unas disculpas para cada alumno
*/
void pedir_disculpas(int cantidad_alumnos){
    for(int i=0; i<cantidad_alumnos; i++){
        printf("Disculpe las molestias ocasionadas!! No volverá a suceder (probablemente sí)\n");
    }
}

int main(){
    int cant_alumnos = 4;
    pedir_disculpas(cant_alumnos);

    return 0;
}




