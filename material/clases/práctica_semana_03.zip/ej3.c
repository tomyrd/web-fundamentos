#include<stdio.h>
#include <stdbool.h>

typedef struct dona {
	bool tiene_cobertura;
	char sabor; // Chocolate, Vainilla, etc
	int peso;
} dona_t;

#define MAX_ANCHO_CAJA 4
#define MAX_LARGO_CAJA 4
#define MAX_DESCARTADAS 30

const char SABOR_CHOCOLATE = 'C'; 

//Lenny llevó una caja de donas al trabajo y Homero quiere sacar todas las que no piensa comer, o sea las que no son su favorita.
//Crear una función que, dada una matriz de donas (que representa la caja de donas que llevó Lenny), 
//y un vector de donas, cargue el vector con las donas que NO sean la favorita de Homero.



/*
    *Pre: -
    *Post: Devuelve true si es sabor chocolate y tiene cobertura. False en caso contrario.
*/
bool es_dona_favorita(dona_t dona){
    return dona.sabor == SABOR_CHOCOLATE && dona.tiene_cobertura;
} 


/*
    *Pre: La matriz caja_donas debe estar llena, el tope de descartadas debe ser <= MAX_DESCARTADAS.
    *Post: Carga el vector descartadas con las donas no favoritas de Homero.
*/
void descartar_donas(dona_t caja_donas[MAX_ANCHO_CAJA][MAX_LARGO_CAJA], dona_t descartadas[MAX_DESCARTADAS], int* tope_descartadas){
    for(int i = 0; i < MAX_ANCHO_CAJA; i++){
        for(int j = 0; j < MAX_LARGO_CAJA; j++){
            if(!es_dona_favorita(caja_donas[i][j])){
                descartadas[*tope_descartadas] = caja_donas[i][j];
                (*tope_descartadas)++;
            }  
        }
    }
}


void inicializar_caja_donas(dona_t caja_donas[MAX_ANCHO_CAJA][MAX_LARGO_CAJA]){
    
    caja_donas[0][0] = (dona_t){true, 'C', 50};
    caja_donas[0][1] = (dona_t){false, 'V', 45};
    caja_donas[0][2] = (dona_t){true, 'F', 60};
    caja_donas[0][3] = (dona_t){false, 'C', 40};

    caja_donas[1][0] = (dona_t){true, 'C', 55};
    caja_donas[1][1] = (dona_t){true, 'V', 42};
    caja_donas[1][2] = (dona_t){false, 'C', 48};
    caja_donas[1][3] = (dona_t){true, 'F', 38};

    caja_donas[2][0] = (dona_t){false, 'V', 52};
    caja_donas[2][1] = (dona_t){true, 'C', 47};
    caja_donas[2][2] = (dona_t){false, 'F', 44};
    caja_donas[2][3] = (dona_t){true, 'V', 46};

    caja_donas[3][0] = (dona_t){true, 'C', 53};
    caja_donas[3][1] = (dona_t){false, 'V', 49};
    caja_donas[3][2] = (dona_t){true, 'F', 51};
    caja_donas[3][3] = (dona_t){false, 'C', 37};
}

int main()
{
    dona_t caja_donas[MAX_ANCHO_CAJA][MAX_LARGO_CAJA];


    dona_t descartadas[MAX_DESCARTADAS];
    int tope = 0;
    descartar_donas(caja_donas, descartadas, &tope);
    for(int i = 0; i < tope; i++){
        printf("El sabor es: %c\n", descartadas[i].sabor);
    }


}