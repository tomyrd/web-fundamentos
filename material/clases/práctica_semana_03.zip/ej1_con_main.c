#include <stdio.h>

#define MAX_MEDIDAS 10

const int MAX_NINIOS = 10;
const int POSICION_MEDIDA_ELIMINAR = 4;

// PRE:  -
// POST: pregunta al usuario la cantidad de niños y 
//       lo guarda en la variable que recibe por referencia.
//       El valor va a estar entre MAX_NINIOS y 0.
void preguntar_ninios(int* cant_ninios){
    printf("¿Cuántos nenes hay? Ingresá máximo %i: \n", MAX_NINIOS);
    scanf("%i", cant_ninios);
    while((*cant_ninios) > MAX_NINIOS || (*cant_ninios) < 0){
        printf("¿Cuántos nenes hay? INGRESÁ MÁXIMO %i TE DIJE Y OBVIO MÁS QUE 0: \n", MAX_NINIOS);
        scanf("%i", cant_ninios); 
    }
}

//PRE: El tope tiene que valer 0 y el vector vacío.  
//      cant_ninios debe ser un número positivo.
//POST: Va a guardar las medidas de los cuellitos de los niños 
//      perdidos, cuya cantidad es cant_ninios.
void guardar_medidas(int medidas[MAX_MEDIDAS], int* tope_medidas, int cant_ninios){
    for(int i=0; i < cant_ninios; i++){
        printf("¿Cuánto te mide el cuellito? \n");
        scanf("%i", &medidas[(*tope_medidas)]);

        // scanf("%i", &medidas[i]); en este caso i y tope son lo mismo
        (*tope_medidas)++;
    }
}

// PRE: la posición a eliminar tiene que ser entre 0 y MAX_MEDIDAS y posicion_eliminar debe contener un valor entre 0 y tope_medidas -1.
// POST: Elimina del vector el elemnto en la posición indicada por parametro.
void eliminar_medida(int medidas[MAX_MEDIDAS], int* tope_medidas, int posicion_eliminar){
    medidas[posicion_eliminar] = medidas[(*tope_medidas) -1];
    (*tope_medidas)--;
}

// PRE: tope_medidas debe contener un valor entre 0 y MAX_MEDIDAS.
// POST: Muestra por pantalla la información de las medidas de los niños.
void mostrar_medidas(int medidas[MAX_MEDIDAS], int tope_medidas){
    for(int i = 0; i < tope_medidas; i++){
        printf("Medida ninio %i: %i\n", i, medidas[i]);
    }
    printf("\n");
}

int main() {
    int cantidad_ninios;
    preguntar_ninios(&cantidad_ninios);

    int medidas[MAX_MEDIDAS];
    int tope = 0;
    guardar_medidas(medidas, &tope, cantidad_ninios);
    printf("\nEl vector quedó así:\n");
    mostrar_medidas(medidas, tope);

    if(POSICION_MEDIDA_ELIMINAR < tope){
        eliminar_medida(medidas, &tope, POSICION_MEDIDA_ELIMINAR);
        printf("Luego de eliminar el elemento de la posición %i, el vector quedó así:\n", POSICION_MEDIDA_ELIMINAR);
        mostrar_medidas(medidas, tope);
    }

    return 0;
}
