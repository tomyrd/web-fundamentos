#include <stdio.h>
#include <stdbool.h>

#define MAX_FILAS 5
#define MAX_COLUMNAS 5
const char POZO = 'P';
const char CESPED = 'C';
const char TESORO_FALSO = 'F';
const char TESORO = 'T';

/*  Pre condiciones: -
    Post condiciones: Busca el primer pozo en el terreno y guarda su fila y columna en las variables pasadas por referencia.
*/
void buscar_primer_pozo(char terreno[MAX_FILAS][MAX_COLUMNAS], int* fila, int* columna){
    bool encontrado = false;
    for(int i = 0; i < MAX_FILAS; i++){
        for(int j = 0; j < MAX_COLUMNAS; j++){
            if(terreno[i][j] == POZO && !encontrado){
                (*fila) = i;
                (*columna) = j;
                encontrado = true;
            }
        }
    }
}

/*  Pre condiciones: -
    Post condiciones: Muestra por pantalla el terreno.
*/
void mostrar_terreno(char terreno[MAX_FILAS][MAX_COLUMNAS]) {
    printf("\n");
    for(int i = 0; i < MAX_FILAS; i++) {
        printf("\t");
        for(int j = 0; j < MAX_COLUMNAS; j++) {
            printf("| %c ", terreno[i][j]);
        }
        printf("|\n");
    }
    printf("\n");
}

int main() {
    char terrenito[MAX_FILAS][MAX_COLUMNAS] = {
        {CESPED, TESORO_FALSO, CESPED, CESPED, CESPED},
        {CESPED, TESORO_FALSO, CESPED, TESORO_FALSO, CESPED},
        {TESORO_FALSO, CESPED, CESPED, POZO, CESPED},
        {CESPED, TESORO_FALSO, POZO, CESPED, CESPED},
        {POZO, TESORO_FALSO, TESORO_FALSO, CESPED, CESPED}
    };

    mostrar_terreno(terrenito);

    int fila;
    int columna;
    buscar_primer_pozo(terrenito, &fila, &columna);

    printf("El primer pozo se encuentra en la fila %d y columna %d\n", fila, columna);

    return 0;
}
