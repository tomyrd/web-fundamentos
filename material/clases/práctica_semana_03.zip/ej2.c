#include <stdio.h>
#include <stdbool.h>

#define MAX_SNACKS 10
#define MAX_BEBIDAS 10

const int DESCUENTO = 2;

const float AUMENTO = 1.5f;

const char BEBIDA_GRANDE = 'G';

typedef struct snack {
    float precio;
    int cantidad_stock;
    bool esta_vencido;
    char tipo; // (D) Dona, (F) Fritas, (P) Pancho
} snack_t;

typedef struct bebida {
    float precio;
    char tamaño; // (C) Chica, (M) Mediana, (G) Grande
} bebida_t;

typedef struct tienda {
    snack_t snacks[MAX_SNACKS];
    int tope_snacks;
    bebida_t bebidas[MAX_BEBIDAS]; 
    int tope_bebidas;
    bool abierta_24h;
} tienda_t;


void inicializar_tienda(tienda_t* tienda) {
    tienda->tope_snacks = 3;
    tienda->snacks[0] = (snack_t){100, 10, false, 'D'};
    tienda->snacks[1] = (snack_t){80, 5, true, 'F'};
    tienda->snacks[2] = (snack_t){120, 7, false, 'P'};

    tienda->tope_bebidas = 3;
    tienda->bebidas[0] = (bebida_t){50, 'C'};
    tienda->bebidas[1] = (bebida_t){70, 'M'};
    tienda->bebidas[2] = (bebida_t){100, 'G'};

    tienda->abierta_24h = true;
}

void imprimir_tienda(tienda_t tienda) {
    printf("\n=== Estado de la tienda ===\n");
    printf("Abierta 24h: %s\n", tienda.abierta_24h ? "Sí" : "No");

    printf("\nSnacks:\n");
    for (int i = 0; i < tienda.tope_snacks; i++) {
        printf(" - Tipo %c | Precio: %f | Stock: %d | %s\n",
               tienda.snacks[i].tipo,
               tienda.snacks[i].precio,
               tienda.snacks[i].cantidad_stock,
               tienda.snacks[i].esta_vencido ? "Vencido" : "OK");
    }

    printf("\nBebidas:\n");
    for (int i = 0; i < tienda.tope_bebidas; i++) {
        printf(" - Tamaño %c | Precio: %f\n",
               tienda.bebidas[i].tamaño,
               tienda.bebidas[i].precio);
    }
}


/*
    * Pre: El struct tienda debe estar inicializado, con valores válidos.
    * Post: Calcula el valor total del inventario según las condiciones de Apu.
*/
int calculo_valor_inventario(tienda_t tienda){
    float valor_inventario = 0;
    for(int i = 0; i < tienda.tope_snacks; i++){
        if(tienda.snacks[i].esta_vencido){
            valor_inventario += tienda.snacks[i].precio / DESCUENTO;
        }else{
            valor_inventario += tienda.snacks[i].precio;
        }
    }

    for(int i = 0; i < tienda.tope_bebidas; i++){
        if(tienda.bebidas[i].tamaño == BEBIDA_GRANDE){
            valor_inventario += tienda.bebidas[i].precio * AUMENTO; 
        }else{
            valor_inventario += tienda.bebidas[i].precio;
        }
    }

    return (int)valor_inventario;
}


/*
    * Pre: Tienda debe estar inicializado con valores válidos, cantidad_deseada debe ser > 0. 
    * Post: Si hay stock suficiente, resta la cantidad deseada del stock de snacks si tipo_snack se encuentra dentro 
    * de la tienda (D, F, P). 
*/
void comprar_snack(tienda_t* tienda, char tipo_snack, int cantidad_deseada){
    int i = 0;
    bool snack_encontrado = false;
    while(i < tienda->tope_snacks && !snack_encontrado){
        if(tienda->snacks[i].tipo == tipo_snack){
            snack_encontrado = true;
            if(tienda->snacks[i].cantidad_stock >= cantidad_deseada){
                tienda->snacks[i].cantidad_stock -= cantidad_deseada;
            }else{
                printf("No rey, no me queda\n");
            }
        }
        i++;
    }
}


int main() {
    tienda_t tienda;
    inicializar_tienda(&tienda);
    imprimir_tienda(tienda);
    int valor_inventario = calculo_valor_inventario(tienda);
    printf("El valor total del inventario es: %i\n", valor_inventario);
    comprar_snack(&tienda, 'D', 3);
    comprar_snack(&tienda, 'X', 283);
    comprar_snack(&tienda, 'P', 15);
    comprar_snack(&tienda, 'P', 1);
    imprimir_tienda(tienda);
    valor_inventario = calculo_valor_inventario(tienda);
    printf("El valor total del inventario es: %i\n", valor_inventario);
    return 0;
}
