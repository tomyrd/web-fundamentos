#include <stdio.h>

// Lisa está haciendo un análisis de sus notas en el colegio
// para ver en qué materias debería mejorar su rendimiento.

// Dada una matriz de notas, donde en cada fila tiene las notas
// de una materia distinta, crear una función que devuelve el 
// índice de la fila con el promedio más bajo.

#define MAX_FIL 9
#define MAX_COL 5

const float PROMEDIO_INVALIDO = 11.0f;

const int INDICE_FILA_INVALIDO = -1;


void inicializar_notas(int notas[MAX_FIL][MAX_COL]) {
    notas [0][0] = 7; notas [0][1] = 8; notas [0][2] = 6; notas [0][3] = 9; notas [0][4] = 5;
    notas [1][0] = 4; notas [1][1] = 6; notas [1][2] = 5; notas [1][3] = 7; notas [1][4] = 6;
    notas [2][0] = 9; notas [2][1] = 8; notas [2][2] = 8; notas [2][3] = 9; notas [2][4] = 8;
    notas [3][0] = 6; notas [3][1] = 5; notas [3][2] = 7; notas [3][3] = 6; notas [3][4] = 5;
    notas [4][0] = 8; notas [4][1] = 9; notas [4][2] = 7; notas [4][3] = 8; notas [4][4] = 9;
    notas [5][0] = 5; notas [5][1] = 6; notas [5][2] = 4; notas [5][3] = 5; notas [5][4] = 6;
    notas [6][0] = 7; notas [6][1] = 8; notas [6][2] = 9; notas [6][3] = 7; notas [6][4] = 8;
    notas [7][0] = 6; notas [7][1] = 5; notas [7][2] = 6; notas [7][3] = 7; notas [7][4] = 5;
    notas [8][0] = 9; notas [8][1] = 9; notas [8][2] = 9; notas [8][3] = 8; notas [8][4] = 9;
}

void imprimir_notas(int notas[MAX_FIL][MAX_COL]) {
    for (int i = 0; i < MAX_FIL; i++) {
        printf("M%d: ", i);
        printf("[ ");
        for (int j = 0; j < MAX_COL; j++) {
            if (j > 0) {
                printf(", ");
            }
            printf("%d", notas[i][j]);
        }
        printf(" ]");
        printf("\n");
    }
}

/*
 * pre: la matriz debe estar llena
 * post: devuelve el indice de la fila con el promedio mas bajo
*/
int promedio_mas_bajo(int notas[MAX_FIL][MAX_COL]){
    float promedio_minimo = PROMEDIO_INVALIDO;
    int fila_promedio_minimo = INDICE_FILA_INVALIDO;
    for(int i = 0; i < MAX_FIL; i++){
        float suma_fila = 0;
        for(int j = 0; j < MAX_COL; j++){
            suma_fila += notas[i][j];    
        }
        float promedio_actual = suma_fila / MAX_COL;
        if(promedio_actual < promedio_minimo){
            promedio_minimo = promedio_actual;
            fila_promedio_minimo = i;
        }
    }
    return fila_promedio_minimo;
}

int main(){
    int notas[MAX_FIL][MAX_COL];
    inicializar_notas(notas);
    imprimir_notas(notas);

    printf("La materia con menor promedio es: %i\n", promedio_mas_bajo(notas));

    return 0;
}