#include <string.h>
#include <stdio.h>

const int MAX_NOMBRE_PERRO = 21;

const int MAX_INGRESADO = 100;

int main(){
    char valor_ingresado[MAX_INGRESADO];
    char nombre[MAX_NOMBRE_PERRO]; //????

    printf("Ingrese un nombre (de menos de 20 letras):");

    scanf("%s", valor_ingresado);

    
    if(strlen(valor_ingresado) > MAX_NOMBRE_PERRO-1){
        printf("Ingrese menos letras\n");
    } else {
        strcpy(nombre, valor_ingresado);
        printf("%s\n", nombre);
    }

    return 0;
}
