#include <stdio.h>

#define MAX_JUGADAS 9
#define MAX_FILAS 3
#define MAX_COL 3
#define VACIO ' '

typedef struct coordenada{
   int fila;
   int columna;
} coordenada_t;


typedef struct jugada {
   char marca; // 'X', 'O' y ' '
   coordenada_t casillero;
} jugada_t;


typedef struct tateti {
   jugada_t jugadas[MAX_JUGADAS];
   int tope_jugadas;
} tateti_t;

void inicializar_tablero_vacio(char tablero[MAX_FILAS][MAX_COL]){
    for(int i = 0; i < MAX_FILAS; i++){
        for(int j = 0; j < MAX_COL; j++){
            tablero[i][j] = VACIO;
        }
    }
}

void inicializar_tablero_con_jugadas(tateti_t tateti, char tablero[MAX_FILAS][MAX_COL]){
    for(int i = 0; i < tateti.tope_jugadas; i++){
        jugada_t jugada = tateti.jugadas[i]; 
        coordenada_t casillero = jugada.casillero; 
        int fila = casillero.fila;
        int col = casillero.columna;
        tablero[fila][col] = jugada.marca;
    }
}

void imprimir_tablero(char tablero[MAX_FILAS][MAX_COL]){
    printf("Estado del tateti:\n");
    printf("------------\n");
    for(int i = 0; i < MAX_FILAS; i++){
        for(int j = 0; j < MAX_COL; j++){
            printf("| %c ", tablero[i][j]);
        }
        printf("|\n");
        printf("------------\n");
    }
}

void imprimir_tres_en_raya(tateti_t tateti){
    char tablero[MAX_FILAS][MAX_COL];
    inicializar_tablero_vacio(tablero);
    inicializar_tablero_con_jugadas(tateti, tablero);
    imprimir_tablero(tablero);
}


void inicializar_tateti(tateti_t *tateti) {
    tateti->tope_jugadas = 3;
    tateti->jugadas[0].marca = 'X';
    tateti->jugadas[0].casillero.fila = 0;
    tateti->jugadas[0].casillero.columna = 0;

    tateti->jugadas[1].marca = 'O';
    tateti->jugadas[1].casillero.fila = 1;
    tateti->jugadas[1].casillero.columna = 1;

    tateti->jugadas[2].marca = 'X';
    tateti->jugadas[2].casillero.fila = 2;
    tateti->jugadas[2].casillero.columna = 1;
}

int main(){
    tateti_t mi_tateti;
    inicializar_tateti(&mi_tateti);
    imprimir_tres_en_raya(mi_tateti);
    return 0;
}