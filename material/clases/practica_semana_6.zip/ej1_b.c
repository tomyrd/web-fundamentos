#include <string.h>
#include <stdio.h>

const int MAX_NOMBRE_PERRO = 21;

const int MAX_INGRESADO = 100;

int main(){
    char nombre_ingresado[MAX_INGRESADO];
    char apellido_ingresado[MAX_INGRESADO];
    char nombre_perro[MAX_NOMBRE_PERRO]; 

    printf("Ingrese un nombre:");
    scanf(" %s", nombre_ingresado);

    printf("Ingrese un apellido:");
    scanf(" %[^\n]", apellido_ingresado);

    
    if(strlen(nombre_ingresado) + strlen(apellido_ingresado) > MAX_NOMBRE_PERRO-1){
        printf("Ingrese menos letras\n");
    } else {
        strcpy(nombre_perro, nombre_ingresado);
        strcat(nombre_perro, " ");
        strcat(nombre_perro, apellido_ingresado);
        printf("%s\n", nombre_perro);
    }

    return 0;
}
