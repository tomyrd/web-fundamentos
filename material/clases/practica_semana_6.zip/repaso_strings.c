#include <string.h>
#include <stdio.h>

const int MAX_NOMBRE = 100;

int main(){
    char nombre[MAX_NOMBRE];

    strcpy(nombre, "Berni"); //nombre = "Tomy"

    printf("%s\n", nombre);

    int tope = strlen(nombre); //Cantidad de letras en string (tope)
    printf("tope = %i\n", tope);

    strcat(nombre, " RD"); //String concatenate (concatenar) 
    printf("%s\n", nombre);

    printf("strcmp = %i\n", strcmp(nombre, "Tomy")); // string1 == string2

    if (strcmp(nombre, "Tomy RD") == 0){
        printf("Hola :)\n");
    }


    return 0;
}