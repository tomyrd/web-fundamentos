#include <stdlib.h>

const int MAX_CARTAS = 3;


typedef struct carta {
   int palo; // 0:B, 1:E, 2:C y 3:O
   unsigned int numero;
} carta_t;


typedef struct truco {
   carta_t mano_j1[MAX_CARTAS];
   int tope_j1;
   carta_t mano_j2[MAX_CARTAS];
   int tope_j2;
} truco_t;

carta_t carta_aleatoria(){
    carta_t carta;
    carta.numero = (rand() % 12) + 1;
    carta.palo = (rand() % 3) + 0;

    return carta;
}

bool carta_existe(carta_t carta, truco_t partida){
    bool existe = false;

    for(int i = 0; i < partida.tope_j1; i++){
        if(carta.palo == partida.mano_j1[i].palo && carta.numero == partida.mano_j1[i].numero){
            existe = true;
        }
    }

    for(int i = 0; i < partida.tope_j2; i++){
        if(carta.palo == partida.mano_j2[i].palo && carta.numero == partida.mano_j2[i].numero){
            existe = true;
        }
    }

    return existe;
}


void inicializar_cartas(truco_t *partida){
    srand(/*...*/);


    partida->mano_j1[0] = carta_aleatoria();

    
    partida->mano_j1[1] = carta_aleatoria();
    while (carta_existe(partida->mano_j1[1], partida)){
        partida->mano_j1[1] = carta_aleatoria();
    }

    partida->mano_j1[2] = carta_aleatoria();
    while (carta_existe(partida->mano_j1[1], partida)){
        partida->mano_j1[2] = carta_aleatoria();
    }
    //...

}
