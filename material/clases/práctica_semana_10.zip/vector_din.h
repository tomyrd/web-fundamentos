#ifndef VECTOR_DIN_H
#define VECTOR_DIN_H

#include <stdbool.h>
#include <stddef.h>

#define MAX_DESCRIPCION 100

typedef struct tarea {
    char descripcion[MAX_DESCRIPCION];
    int nivel_peligro;      
    int sector;             
    bool requiere_titulacion;
} tarea_t;

typedef struct vector_din vector_din_t;

// --- Funciones del TDA base ---

// Post: Crea un vector dinámico vacío. Devuelve un puntero al vector o NULL si falla.
vector_din_t* vec_crear();

// Pre: vec fue creado con vec_crear().
// Post: Destruye el vector y libera su memoria.
void vec_destruir(vector_din_t* vec);

// Pre: vec fue creado con vec_crear().
// Post: Agrega la tarea al final del vector. Devuelve true si tuvo éxito.
bool vec_guardar(vector_din_t* vec, tarea_t tarea);

// Pre: vec fue creado con vec_crear().
// Post: Devuelve un puntero a la tarea en la posición pos o NULL si es inválida.
tarea_t* vec_obtener(vector_din_t* vec, size_t pos);

// Pre: vec fue creado con vec_crear().
// Post: Elimina la tarea en la posición pos. Devuelve true si se eliminó.
// bool vec_eliminar(vector_din_t* vec, size_t pos);

// Pre: vec fue creado con vec_crear().
// Post: Devuelve la cantidad de tareas en el vector.
size_t vec_largo(vector_din_t* vec);

// Pre: vec fue creado con vec_crear().
// Post: Imprime las tareas almacenadas.
void vec_imprimir(vector_din_t* vec);

#endif