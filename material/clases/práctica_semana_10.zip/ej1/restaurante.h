#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>


#define MAX_NOMBRE 100

typedef struct plato {
    char nombre[MAX_NOMBRE];
    bool caliente;
} plato_t;

typedef struct cliente {
    char nombre[MAX_NOMBRE];
    plato_t* platos;
    int cantidad_platos;
} cliente_t;



void pedir_nombre_cliente(char* nombre_cliente);

void pedir_plato(plato_t* plato);

void pedir_cantidad_platos(int* cantidad_platos);

void mostrar_cliente(cliente_t cliente);
