#include "restaurante.h"

const char SI = 'S';
const char NO = 'N';

void mostrar_cliente(cliente_t cliente) {
    printf("Nombre del cliente: %s\n", cliente.nombre);
    for (int i = 0; i < cliente.cantidad_platos; i++) {
        printf("Plato %d: %s, %s\n", i + 1, cliente.platos[i].nombre, cliente.platos[i].caliente ? "Caliente" : "Frio");
    }
}


void pedir_nombre_cliente(char* nombre_cliente) {
    printf("Por favor, ingrese su nombre: ");
    scanf("%s", nombre_cliente);
}

void pedir_plato(plato_t* plato) {
    char rta_caliente;
    printf("Ingrese el nombre del plato: ");
    scanf("%s", plato->nombre);
    printf("El plato es caliente? (S para si, N para no): ");
    scanf(" %c", &rta_caliente);

    while(rta_caliente != SI && rta_caliente != NO) {
        printf("Respuesta invalida. Ingrese S para si o N para no: ");
        scanf(" %c", &rta_caliente);
    }

    plato->caliente = (rta_caliente == SI);
}

void pedir_cantidad_platos(int* cantidad_platos) {
    *cantidad_platos = 0;
    printf("Cuantos platos desea pedir? ");
    scanf("%d", cantidad_platos);
    while(*cantidad_platos <= 0) {
        printf("La cantidad de platos debe ser mayor a 0. Intente nuevamente: ");
        scanf("%d", cantidad_platos);
    }
}
