#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "restaurante.h"

// punto a
// void inicializar_cliente(cliente_t** cliente){
//     cliente_t* aux;
//     aux = (cliente_t*) malloc(sizeof(cliente_t));
//     if(aux == NULL){
//         printf("Error reservando memoria");
//         return;
//     }
//     pedir_nombre_cliente(aux->nombre);
//     pedir_cantidad_platos(&aux->cantidad_platos);

//     plato_t* platos = (plato_t*) malloc(sizeof(plato_t)*aux->cantidad_platos);
//     if(platos == NULL){
//         printf("Error reservando memoria para los platos");
//         free(aux);
//         return;
//     }
//     aux->platos = platos;
//     for(int i = 0; i < aux->cantidad_platos; i++){
//         pedir_plato(&aux->platos[i]);
//     }
//     (*cliente) = aux;
// }

void inicializar_cliente(cliente_t* cliente){
    pedir_nombre_cliente(cliente->nombre);
    pedir_cantidad_platos(&cliente->cantidad_platos);

    plato_t* platos = (plato_t*) malloc(sizeof(plato_t)*cliente->cantidad_platos);
    if(platos == NULL){
        printf("Error reservando memoria para los platos");
        free(cliente);
        return;
    }
    cliente->platos = platos;
    for(int i = 0; i < cliente->cantidad_platos; i++){
        pedir_plato(&cliente->platos[i]);
    }
}

cliente_t* mesa_nueva(int cant_clientes){
    cliente_t* clientes = (cliente_t*) malloc(sizeof(cliente_t)*cant_clientes);
    if(clientes == NULL){
        printf("Error al reservar memoria para clientes");
        return NULL;
    }

    for(int i = 0; i < cant_clientes; i++){
        inicializar_cliente(&clientes[i]);
    }

    return clientes;
}

void liberar_clientes(cliente_t* mesa, int cant_clientes){
    for(int i = 0; i < cant_clientes; i++){
        free(mesa[i].platos);
    }
    free(mesa);
}

void agregar_plato(cliente_t* cliente, int platos_extra){
    plato_t* platos_aux = (plato_t*) realloc(cliente->platos, sizeof(plato_t)*(platos_extra + cliente->cantidad_platos));
    if(platos_aux == NULL){
        printf("Error al reservar mas platos");
        return;
    }

    for(int i = cliente->cantidad_platos; i < cliente->cantidad_platos + platos_extra; i++){
        pedir_plato(&platos_aux[i]);
    }

    cliente->platos = platos_aux;
    cliente->cantidad_platos += platos_extra;
}

int main() {
    // ej a
    // cliente_t* cliente;

    // inicializar_cliente(&cliente);

    // mostrar_cliente(*cliente);

    // free(cliente->platos);
    // free(cliente);


    cliente_t* mesa;
    int cant_clientes = 2; // CONSTANTE
    mesa = mesa_nueva(cant_clientes);
    agregar_plato(&mesa[0], 1);

    liberar_clientes(mesa, cant_clientes);

    return 0;
}