typedef struct enanito {
    char nombre[MAX_ENANITO];
    int proximo_enanito;
    int fuerza;
} enanito_t;

const int FIN_PASES = -1;
const int MAX_ENANITOS = 100;
/*
Pre: 
    - pos_actual es mayor a 0 y es menor al maximo
    - pos_mas_debil_actual es mayor a 0 y es menor al maximo
    - enanitos tiene que tener al menos un elemento
    - en la primera llamada, pos_actual debe ser 0
    - en la primera llamada, pos_mas_debil_actual debe ser 0
    - debería haber al menos un elemento de enanitos que su proximo enanito sea -1
Post: 
    - Devuelve la posicion del enano mas debil en la cadena de pases
*/

int posicion_enano_debil(enanito_t enanitos[MAX_ENANITOS], int pos_actual, int pos_mas_debil_actual){    
    int fuerza_actual = enanitos[pos_actual].fuerza;
    int fuerza_mas_debil = enanitos[pos_mas_debil_actual].fuerza;
    
    if(fuerza_actual < fuerza_mas_debil){
        pos_mas_debil_actual = pos_actual;
    }
    
    if (enanitos[pos_actual].proximo_enanito == FIN_PASES){
        return pos_mas_debil_actual;
    }
    
    return posicion_enano_debil(enanitos, enanitos[pos_actual].proximo_enanito, pos_mas_debil_actual);
}
