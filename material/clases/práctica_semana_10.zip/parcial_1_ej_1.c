#include <stdio.h>
#include <stdbool.h>

#define MAX_COLOR 50
#define MAX_FILAS 50
#define MAX_COLUMNAS 50
#define NO_HAY_MAXIMO -1

typedef struct puerta {
    bool luz_prendida;
    char color[MAX_COLOR];
    int grito_acumulado;
} puerta_t;

#define ROJO "rojo"

// DIJO BOCACCIO: Feliz Cumpleaños => Filas Columnas => puertas[F][C]

/* Pre condiciones: - 'tope_fil' debe ser mayor o igual a cero y menor o igual a MAX_FILAS.
                    - 'tope_col' debe ser mayor o igual a cero y menor o igual a MAX_COLUMNAS.
                    - Todos los campos 'grito_acumulado' de cada puerta_t de la matriz debe ser mayor o igual a cero.
 * Post condicional: Devuelve la columna que tiene mayor sumatoria de gritos de puertas rojas con su luz encendida. Si no hay ninguna que cumpla, devuelve NO_HAY_MAXIMO.
 */
int columna_mayores_gritos(puerta_t puertas[MAX_FILAS][MAX_COLUMNAS], int tope_fil, int tope_col) {
    int columna_mayor = NO_HAY_MAXIMO;
    int gritos_mayor = 0;

    for( int j = 0; j < tope_col; j++ ) {
        int gritos_totales_actual = 0;
        
        for( int i = 0; i < tope_fil; i++ ) {
            if( puertas[i][j].luz_prendida && strcmp(puertas[i][j].color, ROJO) == 0 ) {
                gritos_totales_actual += puertas[i][j].grito_acumulado;
            }
        }

        if(gritos_totales_actual > gritos_mayor) {
            gritos_mayor = gritos_totales_actual;
            columna_mayor = j;
        }
    }

    return columna_mayor;
}