
#include <stdio.h>
#include "vector_din.h"

const int ERROR = -1;
const int CAPACIDAD_PELIGRO_H = 3;

//Pre: tareas debe estar inicializado con vec_crear().
//Post: devuelve la cantidad de tareas que Homero es capaz de realizar siempre que todas las tareas del vector de tareas sean válidas, si no devuelve -1.
int cant_tareas_homero(vector_din_t* tareas){

    int contador_tareas = 0;
    bool es_tarea_valida = true;
    size_t i = 0;
    while(i< vec_largo(tareas) && es_tarea_valida){
        tarea_t* tarea_actual = vec_obtener(tareas, i);
        if(!tarea_actual){
            es_tarea_valida = false;
            contador_tareas = ERROR;
        }else if(!tarea_actual->requiere_titulacion && tarea_actual->nivel_peligro <= CAPACIDAD_PELIGRO_H){
            contador_tareas++;
        }
        i++;
    }
    return contador_tareas;
}

bool escoger_tareas(vector_din_t* tareas, int sector_escogido){
    vector_din_t* aux = vec_crear();
    if(!aux){
        return false;
    }
    bool es_tarea_valida = true;
    size_t i = 0;
    while(i< vec_largo(tareas) && es_tarea_valida){
        tarea_t* tarea_actual = vec_obtener(tareas, i);
        if(!tarea_actual){
            es_tarea_valida = false;
        }else{
            if(!vec_guardar(aux, *tarea_actual)){
                es_tarea_valida = false;
            }
        }
        i++;
    }
    return es_tarea_valida;
}


int main() {
    vector_din_t* tareas = vec_crear();
    if(!tareas){ //tareas == NULL
        return ERROR;
    }

    tarea_t t1 = {"Revisar reactor", 9, 2, true};
    tarea_t t2 = {"Limpiar sala de descanso", 2, 5, false};
    tarea_t t3 = {"Cambiar focos", 3, 5, false};
    tarea_t t4 = {"Controlar válvulas", 8, 2, true};
    tarea_t t5 = {"Pintar paredes", 4, 5, false};

    vec_guardar(tareas, t1);
    vec_guardar(tareas, t2);
    vec_guardar(tareas, t3);
    vec_guardar(tareas, t4);
    vec_guardar(tareas, t5);

    printf("=== Tareas originales ===\n");
    vec_imprimir(tareas);

    //printf("\nHomero puede hacer %zu tareas.\n", tareas_homero(tareas));

    //printf("\n¿Todas las peligrosas requieren título? %s\n",
           //tareas_peligrosas_requieren_titulo(tareas) ? "Sí" : "No");

    printf("\nFiltrando por sector 5...\n");
    //filtrar_por_sector(tareas, 5);
    vec_imprimir(tareas);

    vector_din_t* otras = vec_crear();
    tarea_t t6 = {"Revisar ventilación", 6, 3, false};
    tarea_t t7 = {"Supervisar generadores", 10, 3, true};
    vec_guardar(otras, t6);
    vec_guardar(otras, t7);

    //vector_din_t* combinado = combinar_vectores(tareas, otras);
    //printf("\n=== Vector combinado ===\n");
    //vec_imprimir(combinado);

    vec_destruir(tareas);
    //vec_destruir(otras);
    //vec_destruir(combinado);
    return 0;
}