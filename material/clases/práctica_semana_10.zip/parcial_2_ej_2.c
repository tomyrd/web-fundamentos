// Hacer una función reciba una matriz de enteros (el mapa) y la vida actual de Kuzco y devuelva true si puede pasar por alguna de las columnas sin morir o false si no puede pasar por ninguna.

#include <stdbool.h>

#define MAX_FILAS 50
#define MAX_COLUMNAS 50

/* Pre condiciones: - 'tope_fil' debe ser mayor o igual a cero y menor o igual a MAX_FILAS.
                    - 'tope_col' debe ser mayor o igual a cero y menor o igual a MAX_COLUMNAS.
                    - 'vida_kuzco' debe ser mayor a cero.
 * Post condicional: Devuelve true si encuentra una columna con danio total menor a la vida de Kuzco, sino false en caso contrario.
 */
bool kuzco_puede_sobrevivir(int mapa_guarida[MAX_FILAS][MAX_COLUMNAS], int tope_fil, int tope_col, int vida_kuzco) {
    bool hay_camino_posible = false;

    int j = 0;
    // '!hay_camino_posible' es lo mismo que 'hay_camino_posible == false'
    while(j < tope_col && !hay_camino_posible) { 
        int danio_total = 0;
        
        int i = 0;
        while(i < tope_fil && danio_total < vida_kuzco) {
            danio_total += mapa_guarida[i][j];
            i++;
        }

        if(danio_total < vida_kuzco) {
            hay_camino_posible = true;
        }

        j++;
    }

    return hay_camino_posible;
}