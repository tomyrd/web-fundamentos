#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#define MAX_NOMBRE 30
const int CANTIDAD_INICIAL_CUENTAS = 10;

typedef struct bebida {
    char nombre[MAX_NOMBRE];
    int graduacion_alcoholica;  // 0-100
    bool importada;
} bebida_t;

typedef struct cuenta {
    char nombre_cliente[MAX_NOMBRE];
    bebida_t* bebidas;
    int cantidad_bebidas;
    bool tiene_credito;  // Si puede seguir pidiendo sin pagar
} cuenta_t;

//Pre: nombre es un string
//Post: Crea una cuenta nueva sin bebidas y con bebidas en null.
cuenta_t crear_cuenta(char nombre[MAX_NOMBRE], bool tiene_credito){
    cuenta_t cuenta;
    strcpy(cuenta.nombre_cliente, nombre);
    cuenta.tiene_credito = tiene_credito;
    cuenta.bebidas = NULL;
    cuenta.cantidad_bebidas = 0;
    return cuenta;
}
//Pre: Cuenta y bebida tienen que estar correctamente inicializados.
//Post: Agranda el vector bebidas, agrega una nueva bebida y devuelve true si tiene exito, false en caso contrario
bool agrega_bebida(cuenta_t* cuenta, bebida_t bebida){
    bebida_t* aux = realloc(cuenta->bebidas,sizeof(bebida_t)*(cuenta->cantidad_bebidas+1));
    if(aux == NULL){
        return false;
    }
    cuenta->bebidas = aux;
    cuenta->bebidas[cuenta->cantidad_bebidas] = bebida;
    cuenta->cantidad_bebidas++;
    return true;
}
//Pre: -
//Post: Devuelve un puntero a un vector de 10 cuentas en el heap. Es responsabilidad del que llama a esta función liberarla. Las cuentas arrancan todas vacias. Devuelve null si falla el malloc.
cuenta_t* crear_cuentas(){
    cuenta_t* cuentas = malloc(sizeof(cuenta_t)*CANTIDAD_INICIAL_CUENTAS);
    if(cuentas == NULL) 
        return NULL;
    //inicializar el vector de cuentas.
    return cuentas;
}
//Pre: 
//Post: 
void destruir_cuentas(cuenta_t* cuentas, int cant_cuentas){
    for (int i = 0; i < cant_cuentas; i++){
        if (cuentas[i].bebidas != NULL){
            //cuentas es vector, cuentas[i] es una cuenta_t
            free(cuentas[i].bebidas);
        }
    }
    
    free(cuentas);
}
//Pre: cuentas creado en el heap. La posicion de homero y la posicion de barney tienen que ser posiciones validas.
//Post: Intercambia las bebidas y las cantidades entre barney y homero.
void intercambiar_bebidas(cuenta_t* cuentas, int posicion_homero, int posicion_barney){
    //cambio las bebidas.
    bebida_t* bebidas_aux = cuentas[posicion_homero].bebidas;
    cuentas[posicion_homero].bebidas = cuentas[posicion_barney].bebidas;
    cuentas[posicion_barney].bebidas = bebidas_aux;

    //cambio las cantidades.
    int cantidad_bebidas_homero = 0;
    cuentas[posicion_homero].cantidad_bebidas = cantidad_bebidas_homero;
    cuentas[posicion_homero].cantidad_bebidas = cuentas[posicion_barney].cantidad_bebidas;
    cuentas[posicion_barney].cantidad_bebidas = cantidad_bebidas_homero;
}

int main(){
        
}    
