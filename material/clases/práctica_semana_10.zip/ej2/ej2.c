#include "vector_din.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void mostrar_pedidos(vector_din_t* pedidos){
    for(int i = 0; i < (int)vec_largo(pedidos); i++){
        pedido_t* pedido = vec_obtener(pedidos, i);
        printf("Nombre: %s\n", pedido->nombre);
    }
}

int tiempo_total(vector_din_t* pedidos){
    int tiempo_total = 0;
    for(int i = 0; i < (int)vec_largo(pedidos); i++){
        pedido_t* pedido = vec_obtener(pedidos, i);
        tiempo_total += pedido->tiempo_preparacion;
    }
    return tiempo_total;
}

int main(){
    pedido_t pedido;
    strcpy(pedido.nombre, "milanesa");
    pedido.caliente = true;
    pedido.tiempo_preparacion = 10;

    pedido_t pedido2;
    strcpy(pedido.nombre, "fideo");
    pedido.caliente = true;
    pedido.tiempo_preparacion = 20;
    
    vector_din_t* pedidos;
    pedidos = vec_crear();
    if(pedidos == NULL){
        return -1;
    }

    if(vec_guardar(pedidos, pedido)){
        printf("El pedido se agrego correctamente");
    }else{
        printf("El pedido no se agrego correctamente");
    }

    if(vec_guardar(pedidos, pedido2)){
        printf("El pedido se agrego correctamente");
    }else{
        printf("El pedido no se agrego correctamente");
    }

    mostrar_pedidos(pedidos);

    vec_destruir(pedidos);

    return 0;
}