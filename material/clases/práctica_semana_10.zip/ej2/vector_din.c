#include "vector_din.h"
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>

struct vector_din{
    size_t tope; // size_t == unsigned_int
    pedido_t *pedidos; // Va a apuntar a nuestro vector en el heap
};


vector_din_t* vec_crear(){
    vector_din_t* vector = malloc(sizeof(vector_din_t));
    if (vector == NULL){
        return NULL;
    }

    vector->tope = 0;
    vector->pedidos = NULL;

    return vector;
}

bool vec_guardar(vector_din_t* vec, pedido_t pedido){
    if(vec->pedidos == NULL) {
        vec->pedidos = malloc(sizeof(pedido_t));
        if (vec->pedidos == NULL){
            return false;
        }

        vec->pedidos[0] = pedido;
        vec->tope++;
    } else {
        vec->pedidos = realloc(vec->pedidos, sizeof(pedido_t)*((vec->tope) + 1));
        vec->pedidos[vec->tope] = pedido;
        vec->tope++;
    }

    return true;
}

void vec_destruir(vector_din_t* vec){
    free(vec->pedidos);
    free(vec);
}

size_t vec_largo(vector_din_t* vec){
    return vec->tope;
}

pedido_t* vec_obtener(vector_din_t* vec, size_t pos){
    if (pos > vec->tope){
        return NULL;
    }

    return &vec->pedidos[pos];
}
