#include <stdbool.h>
#include <stddef.h>

#define MAX_NOMBRE 100

typedef struct pedido {
    char nombre[MAX_NOMBRE];
    int tiempo_preparacion;
    bool caliente;
} pedido_t;

typedef struct vector_din vector_din_t;


// Post: Crea un vector dinámico de pedidos. Devuelve un puntero a un vector vacío.
//   	Al terminar de usarlo este vector debe ser destruido con vec_destruir().
//   	Devuelve NULL si no se pudo crear el vector.
vector_din_t* vec_crear();


// Pre: `vec` fue creado usando vec_crear().
// Post: Destruye el vector.
void vec_destruir(vector_din_t* vec);

// Pre: `vec` fue creado usando vec_crear().
// Post: Agrega un pedido al final del vector.
//   	Devuelve true si se pudo agregar, false en caso contrario.
bool vec_guardar(vector_din_t* vec, pedido_t pedido);

// Pre: `vec` fue creado usando vec_crear().
// Post: Devuelve un puntero al elemento en la posición `pos` del vector.
//   	Si `pos` es inválida, devuelve NULL.
//   	Una posición es inválida si es mayor o igual al largo del vector.
pedido_t* vec_obtener(vector_din_t* vec, size_t pos);

// Pre: `vec` fue creado usando vec_crear().
// Post: Devuelve la cantidad de elementos en el vector.
size_t vec_largo(vector_din_t* vec);

// Pre: `vec` fue creado usando vec_crear().
// Post: Imprime los elementos del vector en orden.
void vec_imprimir(vector_din_t* vec);
