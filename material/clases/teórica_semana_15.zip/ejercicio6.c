#include <stdbool.h>
#include <string.h>

#define MAX_PIEL 100
#define MAX_DIENTES 100

typedef struct dientes {
    int cantidad_dientes;
    bool dientes_filosos[MAX_DIENTES];
} dientes_t;
typedef struct animal {
    char alimentacion; // 'C' (carnivoro), 'H' (hervivoro) u 'O' (omnivoro)
    char piel[MAX_PIEL]; // "pelaje", "escamas" o "plumaje"
    dientes_t dientes;
    bool venenoso;
} animal_t;

const int TAM_SUB_MATRIZ = 3;
const int MAX = 10;
const char HERVIVORO = 'H';
const char ESCAMA[10] = "escamas";
const int CANT_DIENTES_FILOSOS = 3;

// Pre: -
// Post: Devuelve true si la coordenada está dentro de los límites de la matriz
bool es_pos_valida(int fil, int col) {
    return fil >= 0 && fil < MAX && col >= 0 && col < MAX;
}

// Pre: -
// Post: Devuelve true si el animal es peligroso
bool es_animal_peligroso(animal_t animal){
    if (animal.alimentacion == HERVIVORO){
        return false;
    }

    if (strcmp(animal.piel, ESCAMA) == 0 && animal.venenoso){
        return true;
    }

    int contador = 0;

    for (int i = 0; i < animal.dientes.cantidad_dientes; i++){
        if(animal.dientes.dientes_filosos[i]){
            contador++;
        }
    }

    return contador >= CANT_DIENTES_FILOSOS;
}

// Pre: La matriz está completamente inicializada
//      La posición de Jane debe ser válida
//
// Post: Devuelve la cantidad de animales peligrosos alrededor de Jane.
int cant_animales_peligrosos(animal_t selva[MAX][MAX], int fil_jane, int col_jane){
    int contador = 0;

    for (int i = fil_jane-1; i <= fil_jane+1; i++) {
        for (int j = col_jane-1; j <= col_jane+1; j++) {
            if (es_pos_valida(i,j) && i != fil_jane && j != col_jane) {
                if (es_animal_peligroso(selva[i][j])){
                    contador ++;
                }
            }
        }
    }

    return contador;
}
