#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_DIRECCION 20
#define MAX_FILAS 30
#define MAX_COLUMNAS 30

#define OBJETO_VICTORIA "Lampara"
#define OBJETO_FRACASO "Trampa"
#define DIR_ARRIBA "Arriba"
#define DIR_ABAJO "Abajo"
#define DIR_DERECHA "Derecha"
#define DIR_IZQUIERDA "Izquierda"

typedef struct indicacion {
    char direccion[MAX_DIRECCION];
    int cantidad_pasos;
} indicacion_t;

// Pre : Mapa debe estar inicializada por completo hasta sus maximos y todos los campos direccion de los indicacion_t deben contener ubn STRING.
// Pos : La funcion retorna TRUE si encuentra la lampara y FALSE si cae en una trampa o no encuentra ningun objeto.
bool aladdin_encontro_lampara(indicacion_t mapa[MAX_FILAS][MAX_COLUMNAS]){
    int fil = 0;
    int col = 0;
    bool encuentra_lampara = false;
    bool encuentra_trampa = false;

    while(!encuentra_lampara && !encuentra_trampa){
        indicacion_t aladdin = mapa[fil][col];

        if(strcmp(aladdin.direccion, OBJETO_VICTORIA) == 0){
            encuentra_lampara = true;
        }

        if(strcmp(aladdin.direccion, OBJETO_FRACASO) == 0){
            encuentra_trampa = true;
        }

        if(strcmp(aladdin.direccion, DIR_ARRIBA) == 0){
            fil -= aladdin.cantidad_pasos;
            if(fil < 0){
                fil = 0;
            }
        }

        if(strcmp(aladdin.direccion, DIR_ABAJO) == 0){
            fil += aladdin.cantidad_pasos;
            if(fil >= MAX_FILAS){
                fil = MAX_FILAS -1;
            }
        }

        if(strcmp(aladdin.direccion, DIR_DERECHA) == 0){
            col += aladdin.cantidad_pasos;
            if(col >= MAX_COLUMNAS){
                col = MAX_COLUMNAS -1;
            }
        }

        if(strcmp(aladdin.direccion, DIR_IZQUIERDA) == 0){
            col -= aladdin.cantidad_pasos;
            if(col < 0){
                col = 0;
            }
        }

    }

    if(encuentra_lampara){
        return true;
    } else {
        return false;
    }
}
