#include <stdio.h>
#include <stdbool.h>

#define MAX_MEDICIONES 20
const int MIN_CANT_OXIGENO_HABITABLE = 100;


typedef struct medicion {
    int id;
    bool es_estable;
    int nivel_oxigeno;
} medicion_t;


/* Pre condiciones: 'cantidad_mediciones' tiene que tener un valor mayor o igual a 0 y menor a MAX_MEDICIONES.
                    'medicion_actual' en su primer llamado tiene que ser 0.
 * Post condiciones: Devuelve true si todas las mediciones estables tienen un nivel de oxigeno mayor a MIN_CANT_OXIGENO_HABITABLE. Devuelve false en caso contrario.
 */
bool planeta_habitable(medicion_t mediciones[MAX_MEDICIONES], int cantidad_mediciones, int medicion_actual) {
    if (medicion_actual >= cantidad_mediciones) {
        return true;
    }

    if (mediciones[medicion_actual].es_estable && mediciones[medicion_actual].nivel_oxigeno <= MIN_CANT_OXIGENO_HABITABLE) {
        return false;
    }
    
    return planeta_habitable(mediciones, cantidad_mediciones, medicion_actual + 1);
} 
