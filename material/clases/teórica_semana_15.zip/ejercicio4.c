#include <stdio.h>
#include <stdlib.h>

const char MODO_LECTURA[2] = "r";
const char MODO_ESCRITURA[2] = "w";
const int MINUTOS_POR_HORA = 60;
const int MAX_HORA = 23;
const int MIN_HORA = 0;
const char ANTIHORARIO = 'A';

/* Pre condiciones:
 * Post condiciones: Devuelve los minutos totales de la hora y minutos recibidos por parámetros.
 */
int horas_a_minutos(int hora, int minutos) {
    return (hora * MINUTOS_POR_HORA) + minutos;
}

/* Pre condiciones:
 * Post condiciones: Devuelve por referencias recibidas por parámetros la cantidad de horas y minutos obtenidas por minutos_totales.
 */
int minutos_a_horas(int* hora, int* minutos, int minutos_totales) {
    *hora = minutos_totales / MINUTOS_POR_HORA;
    
    while (*hora > MAX_HORA) {
        *hora -= (MAX_HORA + 1); 
    }

    while (*hora < MIN_HORA) {
        *hora += (MAX_HORA + 1); 
    }

    // *minutos = minutos_totales - (*hora * MINUTOS_POR_HORA);
    if (minutos_totales < 0) {
        minutos_totales *= -1;
    }
    *minutos = minutos_totales % MINUTOS_POR_HORA;
}

/* Pre condiciones: 'ruta_entrada' y 'ruta_salida' deben ser strings.
 * Post condiciones: Crea un archivo 'ruta_salida' con la hora final luego de los movimientos de Stitch.
 */
void jugar_con_reloj(char* ruta_entrada, char* ruta_salida) {
    FILE* archivo_entrada = fopen(ruta_entrada, MODO_LECTURA);

    if(archivo_entrada == NULL) {
        printf("Error al abrir el archivo %s\n", ruta_entrada);
        return;
    }

    int horas, minutos;
    int leidos = fscanf(archivo_entrada, "%dh%dm\n", &horas, &minutos);

    if(leidos != EOF) {
        minutos = horas_a_minutos(horas, minutos);
        char sentido;
        int nuevos_minutos;
        leidos = fscanf(archivo_entrada, "%c:%d\n", &sentido, &nuevos_minutos);
        while(leidos != EOF) {
            if (sentido == ANTIHORARIO) {
                minutos -= nuevos_minutos;
            } else {
                minutos += nuevos_minutos;
            }

            leidos = fscanf(archivo_entrada, "%c:%d\n", &sentido, &nuevos_minutos);
        }
        
        minutos_a_horas(&horas, &minutos, minutos);

        FILE* archivo_salida = fopen(ruta_salida, MODO_ESCRITURA);
        if(archivo_salida == NULL) {
            printf("Error al abrir el archivo %s\n", ruta_salida);
            fclose(archivo_entrada);
            return;
        }

        fprintf(archivo_salida, "%dh%dm\n", horas, minutos);
        fclose(archivo_salida);
    }

    fclose(archivo_entrada);
}
