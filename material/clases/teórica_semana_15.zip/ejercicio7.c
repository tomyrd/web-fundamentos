#include <stdio.h>
#include <stdbool.h>
#include <string.h>

const int MAX = 100;
const char FORMATO[MAX] = "%c;%i;%[^;];%[^;];%[^;]\n";
const int CANT_TEMAS = 3;
const char INICIO = 'I';
const char FIN = 'F';
const char PRINCIPE[MAX] = "principe";
const int MIN_EN_HORA = 60;

// Pre: tipo es válido
//      en_rango es true si estoy entre el suenio de inicio y fin
//      temas no es una simple matriz de caracteres sino que cada fila es un string con un tema
//      temas siempre contiene 3 strings
// Post: Devuelve true si la bella durmiente descansa durante este suenio.
bool es_suenio_descansador(char tipo, char temas[CANT_TEMAS][MAX], bool en_rango){
    if (tipo == INICIO || tipo == FIN){
        return true;
    }

    if (en_rango) {
        bool hay_principe = false;

        for (int i = 0; i < CANT_TEMAS; i++) {
            if(strcmp(temas[i], PRINCIPE) == 0){
                hay_principe = true;
            }
        }

        return hay_principe;
    } else {
        return false;
    }
}

// Pre: -
// Post: Crea un archivo en `nombre_salida` con las horas y minutos descansados por Bella. Devuevle true si pudo realizar la acción con éxito.
bool horas_y_minutos_descansados(char nombre_archivo[MAX], char nombre_salida[MAX]){
    FILE* archivo_entrada = fopen(nombre_archivo, "r");

    if (archivo_entrada == NULL) {
        return false;
    }

    char tipo;
    int minutos_leidos;
    char temas[CANT_TEMAS][MAX];

    int leidos = fscanf(archivo_entrada, FORMATO, &tipo, &minutos_leidos, temas[0], temas[1], temas[2]);

    bool en_rango = false;

    int contador_minutos = 0;

    while(leidos != EOF){

        if (tipo == INICIO){
            en_rango = true;
        }

        if (tipo == FIN){
            en_rango = false;
        }

        if(es_suenio_descansador(tipo, temas, en_rango)){
            contador_minutos += minutos_leidos;
        }

        leidos = fscanf(archivo_entrada, FORMATO, &tipo, &minutos_leidos, temas[0], temas[1], temas[2]);
    }
   // Termine de leer

    fclose(archivo_entrada);

    FILE* archivo_salida = fopen(nombre_salida, "w");

    if(archivo_salida == NULL){
        return false;
    }

    fprintf(archivo_salida, "%ih%im", minutos_leidos/MIN_EN_HORA, minutos_leidos % MIN_EN_HORA);

    fclose(archivo_salida);

    return true;
}
