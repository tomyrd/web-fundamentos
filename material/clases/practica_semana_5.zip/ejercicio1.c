#include <stdio.h>
#include <stdbool.h>
#include "favoritos.h"


int main(){
    char iniciales[MAX_INICIALES];

    iniciales[0] = '*';
    iniciales[1] = 'A';
    iniciales[2] = 'V'; 
    iniciales[3] = 'D';
    iniciales[4] = 'L';

    int cant_iniciales = 5;

    for(int i = 0; i < cant_iniciales; i++){
        printf("Inicial %i: %c\n", i, iniciales[i]);
    }

    int posicion = buscar_elemento(iniciales, cant_iniciales, '*');

    eliminar(iniciales, &cant_iniciales, posicion);
    printf("----\n");
    for(int i = 0; i < cant_iniciales; i++){
        printf("Inicial %i: %c\n", i, iniciales[i]);
    }

    agregar_nueva_inicial(iniciales, &cant_iniciales, 'C');
    printf("----\n");
    for(int i = 0; i < cant_iniciales; i++){
        printf("Inicial %i: %c\n", i, iniciales[i]);
    }
    return 0;
}
