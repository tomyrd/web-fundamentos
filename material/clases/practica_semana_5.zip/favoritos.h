//Header guards
#ifndef __FAVORITOS_H__
#define __FAVORITOS_H__

#define MAX_INICIALES 3000
#define NO_EXISTE -1

//Pre: cant_iniciales debe ser mayor a 0. cant_iniciales debe ser menor a MAX_INICIALES.
// El vector de iniciales contendrá como mucho un elemento.
//Post: Devuelve la posicion del elemento en el vector de iniciales
// o -1 en caso de que no se encuentre.
int buscar_elemento(char iniciales[MAX_INICIALES], int cant_iniciales, char elemento);

void eliminar(char iniciales[MAX_INICIALES], int *cant_iniciales, int posicion);

void agregar_nueva_inicial(char iniciales[MAX_INICIALES], int* cant_iniciales, char nueva_letra);
#endif
