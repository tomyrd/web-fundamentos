#include <stdbool.h>
#include "favoritos.h"

//Pre: cant_iniciales debe ser mayor a 0. cant_iniciales debe ser menor a MAX_INICIALES.
// El vector de iniciales contendrá como mucho un elemento.
//Post: Devuelve la posicion del elemento en el vector de iniciales
// o -1 en caso de que no se encuentre.
int buscar_elemento(char iniciales[MAX_INICIALES], int cant_iniciales, char elemento){
    int posicion = 0;
    int i = 0;

    bool encontrado = false;

    while(i < cant_iniciales && !encontrado){
        if(iniciales[i] == elemento){
            posicion = i;
            encontrado = true;
        }

        i++;
    }

    if(encontrado){
        return posicion;
    } else {
        return NO_EXISTE;
    }
}

void eliminar(char iniciales[MAX_INICIALES], int *cant_iniciales, int posicion){
    char auxiliar = iniciales[posicion];
    iniciales[posicion] = iniciales[*cant_iniciales - 1];
    iniciales[*cant_iniciales - 1] = auxiliar;
    (*cant_iniciales)--;
}


void agregar_nueva_inicial(char iniciales[MAX_INICIALES], int* cant_iniciales, char nueva_letra){
    iniciales[*cant_iniciales] = nueva_letra;
    *cant_iniciales+=1;
}
