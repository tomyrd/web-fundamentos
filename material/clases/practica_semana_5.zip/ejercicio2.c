#include <stdbool.h>

const char PERRO = 'P';

typedef struct mascota{
    char animal; // P perro/ G gato/...
    char inicial_nombre;
    int edad;
} mascota_t;

typedef struct colab{
    char inicial;
    int edad;
    int ignoraciones;
    bool invitado_asado;
    int notas[MAX_NOTAS];
    int cant_notas;
    mascota_t mascota;
} colab_t;

void agregar_nuevo_colab(colab_t colaboradores[MAX_COLABS], int* cant_colabs, colab_t nuevo_colab){
    colaboradores[*cant_colabs] = nuevo_colab;
    (*cant_colabs)++;
}

void imprimir_preferidos(colab_t colaboradores[MAX_COLABS], int cant_colabs){
    for(int i = 0; i < cant_colabs; i++){
        bool es_muy_ignorado = colaboradores[i].ignoraciones >= 2;
        bool vino_a_asado = colaboradores[i].invitado_asado;
        bool tiene_perro = colaboradores[i].mascota.animal == PERRO;

        if(tiene_perro && !es_muy_ignorado && vino_a_asado){
            printf("Inicial preferido: %c", colaboradores[i].inicial);
        }
    }
}




