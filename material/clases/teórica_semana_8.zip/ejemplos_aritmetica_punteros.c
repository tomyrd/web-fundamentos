#include <stdio.h>

const int MAX = 100;

int main () {  
    // -- INTRO --
    int entero = 123;
    int* puntero = &entero;

    printf("Valor del entero: %i\n", entero); //123
    printf("Valor del puntero (decimal): %lu\n", (unsigned long) puntero);//9
    printf("Valor del puntero (hexadecimal): %p\n", puntero);//0x000009
    printf("Tamaño del entero: %lu\n", sizeof(entero));//4
    printf("Tamaño del puntero: %lu\n", sizeof(puntero));//8



    // -- PUNTERO NULL Y SUMA--
    // int* puntero = NULL;
    // printf("Valor del puntero: %lu\n", (unsigned long) puntero);//0
    // // printf("Puntero desreferenciado: %i\n", *puntero);
    // puntero++;
    // printf("Valor del puntero: %lu\n", (unsigned long) puntero);



    // // -- DIFERENTES TAMAÑOS --
    // int* puntero_entero = NULL;
    // char* puntero_char = NULL;
    // long* puntero_long = NULL;

    // printf("Tamaño del entero: %lu\n", sizeof(int));//4
    // printf("Tamaño del char: %lu\n", sizeof(char));//1
    // printf("Tamaño del long: %lu\n", sizeof(long));//8

    // puntero_entero++;
    // puntero_char++;
    // puntero_long++;

    // printf("Valor del puntero_entero+1: %lu\n", (unsigned long) puntero_entero);//4
    // printf("Valor del puntero_char+1: %lu\n", (unsigned long) puntero_char);//1
    // printf("Valor del puntero_long+1: %lu\n", (unsigned long) puntero_long);//8



    // // -- SUMAS DISTINTAS Y RESTAS --
    // int* puntero = NULL;

    // printf("Valor del puntero: %lu\n", (unsigned long) puntero);
    // puntero += 1;
    // printf("Valor del puntero: %lu\n", (unsigned long) puntero); // 4
    // puntero += 4; //4*sizeof(int) = 4*4 = 16
    // printf("Valor del puntero: %lu\n", (unsigned long) puntero);//20
    // puntero -= 2; //2*sizeof(int) = 2*4= 8
    // printf("Valor del puntero: %lu\n", (unsigned long) puntero);//12



    // // -- EQUIVALENCIA CON VECTORES --
    // int nombre_vector[MAX]; // nombre_vector es un puntero a la primera posicion del vector de enteros
    // nombre_vector[0] = 123;
    // nombre_vector[1] = 456;
    // nombre_vector[4] = 789;

    // printf("Valor de nombre_vector (que es un puntero a la primera posicion): %lu\n", (unsigned long) nombre_vector);//una direccion grande
    // printf("Primer elemento de nombre_vector: %i\n", nombre_vector[0]);//123
    // printf("Desreferencio nombre_vector: %i\n", *nombre_vector);//123
    // printf("Segundo elemento de nombre_vector: %i\n", nombre_vector[1]);//456
    // printf("Desreferenciando nombre_vector+1: %i\n", *(nombre_vector+1));//456
    // printf("Quinto elemento de nombre_vector: %i\n", nombre_vector[4]);//789
    // printf("Desreferenciando nombre_vector+4: %i\n", *(nombre_vector+4));//789

    // // vector[x] === *(vector + x)
 
    return 0;
}