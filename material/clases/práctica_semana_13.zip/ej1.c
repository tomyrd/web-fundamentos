#include <stdio.h>
#include <stdbool.h>
#include <string.h>

// Tiene dos archivos con los invitados, uno con los del casamiento pasado y otros con los que anotó para este, ordenados alfabéticamente por nombre. Como no se quiere olvidar de nadie, quiere que hagamos un programa que cree un nuevo archivo con todos los invitados sin repetir, mayores de 10 años y que además no sean problemáticos.

#define MAX_NOMBRE 50

typedef struct invitado {
    char nombre[MAX_NOMBRE];
    int edad;
    char problematico;
} invitado_t;

#define INVITADOS_ARCH "invitados.csv"
#define INVITADOS_PASADOS_ARCH "invitados_pasados.csv"
#define INVITADOS_FINALES_ARCH "invitados_finales.csv"
#define FORMATO_INVITADO "%[^;];%i;%c\n"
#define FORMATO_INVITADO_ESCRITURA "%s;%i;%c\n"

#define MODO_LECTURA "r"
#define MODO_ESCRITURA "w"

const int EDAD_LIMITE = 10;
const char FALSO = 'F';

// POST: devuelve true si la edad del invitado es mayor a EDAD_LIMITE y si no es problemático.
bool invitado_es_valido(invitado_t invitado) {
    return (invitado.edad > EDAD_LIMITE && invitado.problematico == FALSO);
}


// PRE: invitados_finales_f fue abierto con fopen en modo escritura y es un puntero válido. invitado está incializado correctamente. 
// POST: carga en invitados_finales_f la info del invitado si este es válido.
void guardar_invitado_valido(FILE* invitados_finales_f, invitado_t invitado) {
    if(invitado_es_valido(invitado)){
        fprintf(invitados_finales_f, FORMATO_INVITADO_ESCRITURA, invitado.nombre, invitado.edad, invitado.problematico);
    }
}

// PRE: Recibe punteros válidos a archivos abiertos con fopen. 
//      Los archivos invitados_pasados_f e invitados_f están ordenados alfabeticamente por nombre del invitado. y abiertos en modo lectura. 
//      El archivo invitados_finales_f está abierto en modo escritura.
// POST: Carga los invitados válidos en invitados_finales_f manteniendo el orden y sin repetidos.
void unir_invitados(FILE* invitados_f, FILE* invitados_pasados_f, FILE* invitados_finales_f) {
    invitado_t invitado, invitado_pasado;
    int leido_invitado = fscanf(invitados_f, FORMATO_INVITADO, invitado.nombre, &invitado.edad, &invitado.problematico);
    int leido_invitado_pasado = fscanf(invitados_pasados_f, FORMATO_INVITADO, invitado_pasado.nombre, &invitado_pasado.edad, &invitado_pasado.problematico);
    
    while(leido_invitado != EOF && leido_invitado_pasado != EOF) {
        int comparacion = strcmp(invitado.nombre, invitado_pasado.nombre);

        // si son iguales
        if(comparacion == 0) {
            guardar_invitado_valido(invitados_finales_f, invitado);
            leido_invitado = fscanf(invitados_f, FORMATO_INVITADO, invitado.nombre, &invitado.edad, &invitado.problematico);
            leido_invitado_pasado = fscanf(invitados_pasados_f, FORMATO_INVITADO, invitado_pasado.nombre, &invitado_pasado.edad, &invitado_pasado.problematico);
        }
        // si invitado va antes que invitado pasado
        else if(comparacion < 0) {
            guardar_invitado_valido(invitados_finales_f, invitado);
            leido_invitado = fscanf(invitados_f, FORMATO_INVITADO, invitado.nombre, &invitado.edad, &invitado.problematico);
        }
        // si invitado pasado va antes que invitado
        else {
            guardar_invitado_valido(invitados_finales_f, invitado_pasado);
            leido_invitado_pasado = fscanf(invitados_pasados_f, FORMATO_INVITADO, invitado_pasado.nombre, &invitado_pasado.edad, &invitado_pasado.problematico);
        }
    }

    while(leido_invitado != EOF) {
        guardar_invitado_valido(invitados_finales_f, invitado);
        leido_invitado = fscanf(invitados_f, FORMATO_INVITADO, invitado.nombre, &invitado.edad, &invitado.problematico);
    }

    while(leido_invitado_pasado != EOF) {
        guardar_invitado_valido(invitados_finales_f, invitado_pasado);
        leido_invitado_pasado = fscanf(invitados_f, FORMATO_INVITADO, invitado_pasado.nombre, &invitado_pasado.edad, &invitado_pasado.problematico);
    }
}

int main() {

    FILE* invitados_f = fopen(INVITADOS_ARCH, MODO_LECTURA);
    if(!invitados_f) {
        printf("Error abriendo el archivo de invitados\n");
        return 1;
    }

    FILE* invitados_pasados_f = fopen(INVITADOS_PASADOS_ARCH, MODO_LECTURA);
    if(!invitados_pasados_f) {
        fclose(invitados_f);
        printf("Error abriendo el archivo de invitados pasados\n");
        return 1;
    }


    FILE* invitados_finales_f = fopen(INVITADOS_FINALES_ARCH, MODO_ESCRITURA);
    if(!invitados_finales_f) {
        fclose(invitados_f);
        fclose(invitados_pasados_f);
        printf("Error abriendo el archivo de invitados finales\n");
        return 1;
    }

    unir_invitados(invitados_f, invitados_pasados_f, invitados_finales_f);

    fclose(invitados_f);
    fclose(invitados_pasados_f);
    fclose(invitados_finales_f);

    return 0;
}