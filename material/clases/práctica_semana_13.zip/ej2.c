#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_NOMBRE 50
#define NOMBRE_ARCH_LISTA "lista.csv"
#define NOMBRE_ARCH_TICKET "ticket.csv"
#define NOMBRE_ARCH_FALTANTES "faltantes.csv"
#define FORMATO_LECTURA "%[^;];%i\n"
#define FORMATO_ESCRITURA "%s;%i\n"

typedef struct producto{
    char nombre[MAX_NOMBRE];
    int cantidad;
} producto_t;

void buscar_faltantes(FILE* arch_lista, FILE* arch_ticket, FILE* arch_faltantes){
    producto_t prod_lista;
    producto_t prod_ticket;

    int leido_lista = fscanf(arch_lista, FORMATO_LECTURA, prod_lista.nombre, &prod_lista.cantidad);
    int leido_ticket = fscanf(arch_ticket, FORMATO_LECTURA, prod_ticket.nombre, &prod_ticket.cantidad);

    while(leido_lista != EOF && leido_ticket != EOF){
        int comparacion = strcmp(prod_lista.nombre, prod_ticket.nombre);
        if(comparacion == 0){
            if(prod_lista.cantidad > prod_ticket.cantidad){
                int cantidad = prod_lista.cantidad - prod_ticket.cantidad;
                fprintf(arch_faltantes, FORMATO_ESCRITURA, prod_lista.nombre, cantidad);
            }
            leido_lista = fscanf(arch_lista, FORMATO_LECTURA, prod_lista.nombre, &prod_lista.cantidad);
            leido_ticket = fscanf(arch_ticket, FORMATO_LECTURA, prod_ticket.nombre, &prod_ticket.cantidad);
        }else if(comparacion > 0){
            leido_ticket = fscanf(arch_ticket, FORMATO_LECTURA, prod_ticket.nombre, &prod_ticket.cantidad);
        }else{
            fprintf(arch_faltantes, FORMATO_ESCRITURA, prod_lista.nombre, prod_lista.cantidad);
            leido_lista = fscanf(arch_lista, FORMATO_LECTURA, prod_lista.nombre, &prod_lista.cantidad);
        }
    }

    while(leido_lista != EOF){
        fprintf(arch_faltantes, FORMATO_ESCRITURA, prod_lista.nombre, prod_lista.cantidad);
        leido_lista = fscanf(arch_lista, FORMATO_LECTURA, prod_lista.nombre, &prod_lista.cantidad);
    }
}

int main(){
    FILE* arch_lista = fopen(NOMBRE_ARCH_LISTA, "r");
    if(!arch_lista){
        printf("Error al abrir el archivo lista");
        return 1;
    }

    FILE* arch_ticket = fopen(NOMBRE_ARCH_TICKET, "r");
    if(!arch_ticket){
        fclose(arch_lista);
        printf("Error al abrir el archivo lista");
        return 1;
    }

    FILE* arch_faltantes = fopen(NOMBRE_ARCH_FALTANTES, "w");
     if(!arch_faltantes){
        fclose(arch_ticket);
        fclose(arch_lista);
        printf("Error al abrir el archivo lista");
        return 1;
    }

    buscar_faltantes(arch_lista, arch_ticket, arch_faltantes);

    fclose(arch_lista);
    fclose(arch_ticket);
    fclose(arch_faltantes);

    return 0;
}