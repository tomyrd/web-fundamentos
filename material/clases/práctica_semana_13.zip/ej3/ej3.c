#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_NOMBRE 50
#define MAX_TIPO 50
#define MAX_COLOR 50

const char* NOMBRE_ARCH_CRIATURAS = "criaturas_marinas.csv";
const char* NOMBRE_ARCH_REPORTE = "reporte_frying_dutchman.txt";
const int ERROR = -1;
const int EXITO = 0;
const char* FORMATO_LECTURA = "%[^;];%[^;];%[^;];%c;%c\n";
const char* TIPO_COMESTIBLE = "PESCADO";
const char ES_COMESTIBLE = 'S';
const char ES_VENENOSO = 'S';
const char* FORMATO_ESCRITURA = "total criaturas: %i \ntotal pescados comestibles: %i\n";

bool es_pescado_comestible(char tipo[MAX_TIPO], char venenosa, char comestible){
    return strcmp(tipo, TIPO_COMESTIBLE) == 0 && comestible == ES_COMESTIBLE && venenosa != ES_VENENOSO;
}

int generar_reporte_criaturas(FILE* criaturas){
    FILE* reporte = fopen(NOMBRE_ARCH_REPORTE, "w");
    if(!reporte){
        printf("Hubo un error al abrir el reporte\n");
        return ERROR;
    }

    char nombre[MAX_NOMBRE];
    char tipo[MAX_TIPO];
    char color[MAX_COLOR];
    char venenosa;
    char comestible;

    int cant_criaturas = 0;
    int cant_comestibles = 0;

    int leido_criaturas = fscanf(criaturas, FORMATO_LECTURA, nombre, tipo, color, &venenosa, &comestible);
    while(leido_criaturas != EOF){
        cant_criaturas++;
        if(es_pescado_comestible(tipo, venenosa, comestible)){
            cant_comestibles++;
        }
        leido_criaturas = fscanf(criaturas, FORMATO_LECTURA, nombre, tipo, color, &venenosa, &comestible);
    }

    fprintf(reporte, FORMATO_ESCRITURA, cant_criaturas, cant_comestibles);

    fclose(reporte);
    
    return EXITO;
}


int main(){
    FILE* criaturas = fopen(NOMBRE_ARCH_CRIATURAS, "r");
    if(!criaturas){
        printf("Hubo un error al abrir el archivo de criaturas \n");
        return ERROR;
    }

    generar_reporte_criaturas(criaturas);

    fclose(criaturas);
    return 0;
}