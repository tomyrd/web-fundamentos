#include <stdio.h>
#include <string.h>
#include <stdbool.h>

const char* FORMATO_LECTURA = "%[^;];%i\n";
const char* FORMATO_ESCRITURA = "%s;%i\n";
const char* LISTA_COMPLETA = "lista_regalos.csv";
const char* ESCRITURA = "w";
const char* LECTURA = "r";
#define MAX_NOMBRE_REGALO 100
const int ARCHIVO_LISA = 2;
const int ARCHIVO_BART = 1;
const int CANTIDAD_ARGUMENTOS_VALIDOS = 3;



//pre: regalos_bart y regalos_lisa estan abiertos en modod lectura y ordenados alfabeticamente.
//post: Crea un archivo con la union de los archivos enviados y actualiza la cantidad de elementos de los regalos repetidos.
void unificar_lista_regalos(FILE* regalos_bart, FILE* regalos_lisa){
    FILE* lista_regalos = fopen(LISTA_COMPLETA,ESCRITURA);
    if(!lista_regalos){
        printf("No se pudo crear el archivo para la lista, se suspende la navidad\n");
        return;
    }

    char regalo_bart[MAX_NOMBRE_REGALO];
    int cantidad_regalos_bart = -1;
    int leido_bart = fscanf(regalos_bart, FORMATO_LECTURA, regalo_bart, &cantidad_regalos_bart);

    char regalo_lisa[MAX_NOMBRE_REGALO];
    int cantidad_regalos_lisa = -1;
    int leido_lisa = fscanf(regalos_lisa, FORMATO_LECTURA, regalo_lisa, &cantidad_regalos_lisa);

    while(leido_bart != EOF && leido_lisa != EOF){
        if(strcmp(regalo_bart, regalo_lisa) < 0){
            fprintf(lista_regalos, FORMATO_ESCRITURA, regalo_bart, cantidad_regalos_bart);
            leido_bart = fscanf(regalos_bart, FORMATO_LECTURA, regalo_bart, &cantidad_regalos_bart);
        }
        else if(strcmp(regalo_bart, regalo_lisa) > 0){
            fprintf(lista_regalos, FORMATO_ESCRITURA, regalo_lisa, cantidad_regalos_lisa);
            leido_lisa = fscanf(regalos_lisa, FORMATO_LECTURA, regalo_lisa, &cantidad_regalos_lisa);            
        }
        else{
            fprintf(lista_regalos, FORMATO_ESCRITURA,regalo_bart, (cantidad_regalos_bart+cantidad_regalos_lisa));
            leido_bart = fscanf(regalos_bart, FORMATO_LECTURA, regalo_bart, &cantidad_regalos_bart);
            leido_lisa = fscanf(regalos_lisa, FORMATO_LECTURA, regalo_lisa, &cantidad_regalos_lisa);
        }
    }

    while (leido_bart != EOF){
        fprintf(lista_regalos, FORMATO_ESCRITURA, regalo_bart, cantidad_regalos_bart);
        leido_bart = fscanf(regalos_bart, FORMATO_LECTURA, regalo_bart, &cantidad_regalos_bart);
    }

    while (leido_lisa != EOF){
        fprintf(lista_regalos, FORMATO_ESCRITURA, regalo_lisa, cantidad_regalos_lisa);
        leido_lisa = fscanf(regalos_lisa, FORMATO_LECTURA, regalo_lisa, &cantidad_regalos_lisa);
    }
    fclose(lista_regalos);
}



int main(int argc, char* argv[]){
    if(argc != CANTIDAD_ARGUMENTOS_VALIDOS){
        printf("Cantidad insuficiente de archivos\n");
        return -1;
    }
    FILE* lista_bart = fopen(argv[ARCHIVO_BART],LECTURA);
    if(!lista_bart){
        printf("No se pudo abrir el archivo de bart\n");
        return -1;
    }

    FILE* lista_lisa = fopen(argv[ARCHIVO_LISA],LECTURA);
    if(!lista_lisa){
        printf("No se pudo abrir el archivo de lisa\n");
        fclose(lista_bart);
        return -1;
    }

    unificar_lista_regalos(lista_bart, lista_lisa);

    fclose(lista_bart);
    fclose(lista_lisa);
    return 0;
}
