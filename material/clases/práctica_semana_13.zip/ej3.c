#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define NOMBRE_ARCH_SANDWICHES "sandwiches.csv"
#define NOMBRE_ARCH_CANTIDADES_SAND "cantidades_sandwiches.txt"
#define MAX_INGREDIENTES 5
#define MAX_NOMBRE 50
#define FORMATO_LECTURA "%[^;];%[^;];%[^;];%[^;];%[^\n]\n"

#define INGREDIENTE_PPAL_SANGUCHE "PAN"
#define INGREDIENTE_JAMON "JAMON"
#define INGREDIENTE_POLLO "POLLO"
#define INGREDIENTE_ATUN "ATUN"

const int POS_INICIAL_RELLENO = 1;
const int POS_FINAL_RELLENO = 3;

const int POS_INGREDIENTE_INICIAL = 0;
const int POS_INGREDIENTE_FINAL = 4;

bool es_sandwich(char ingrediente_inicial[MAX_NOMBRE], char ingrediente_final[MAX_NOMBRE]){
    return strcmp(ingrediente_inicial, INGREDIENTE_PPAL_SANGUCHE) == 0 && strcmp(ingrediente_final, INGREDIENTE_PPAL_SANGUCHE) == 0;
}

bool es_vegetariano(char receta[MAX_INGREDIENTES][MAX_NOMBRE]){
    bool es_vegetariano = true;
    int i = POS_INICIAL_RELLENO;
    while(i <= POS_FINAL_RELLENO && es_vegetariano){
        if(strcmp(receta[i], INGREDIENTE_ATUN) == 0 || strcmp(receta[i], INGREDIENTE_JAMON) == 0 || strcmp(receta[i], INGREDIENTE_POLLO) == 0){
            es_vegetariano = false;
        }
        i++;
    }
    return es_vegetariano;
}

void contar_sandwiches(FILE* arch_sandwiches, int* total_sand, int* total_vegie){
    char receta[MAX_INGREDIENTES][MAX_NOMBRE];
    //char* receta[MAX_INGREDIENTES];
    int leido = fscanf(arch_sandwiches, FORMATO_LECTURA, receta[0], receta[1], receta[2], receta[3], receta[4]);
    
    while(leido != EOF){
        if(es_sandwich(receta[POS_INGREDIENTE_INICIAL], receta[POS_INGREDIENTE_FINAL])){
            (*total_sand)++;
            if(es_vegetariano(receta)){
                (*total_vegie)++;
            }
        }
        leido = fscanf(arch_sandwiches, FORMATO_LECTURA, receta[0], receta[1], receta[2], receta[3], receta[4]);
    }
}

void guardar_cantidades(FILE* arch_cant_sandwiches, int cant_sand, int cant_vegie){
    fprintf("%i\n", cant_sand);
    fprintf("%i\n", cant_vegie);
}

int main(){

    FILE* arch_sandwiches = fopen(NOMBRE_ARCH_SANDWICHES, "r");
    if(!arch_sandwiches){
        printf("Hubo un error al abrir el archivo");
        return 1;
    }

    FILE* arch_cant_sandwiches = fopen(NOMBRE_ARCH_CANTIDADES_SAND, "w");
    if(!arch_cant_sandwiches){
        fclose(arch_sandwiches);
        printf("Hubo un error al abrir el archivo");
        return 1;
    }

    int cant_sand = 0;
    int cant_vegie = 0;
    contar_sandwiches(arch_sandwiches, &cant_sand, &cant_vegie);

    guardar_cantidades(arch_cant_sandwiches, cant_sand, cant_vegie);

    fclose(arch_sandwiches);
    fclose(arch_cant_sandwiches);

    return 0;
}