#include <stdio.h>
#include <stdlib.h>

const char* ARCHIVO_HABITACIONES_VACIAS = "habitaciones_vacio.csv";
const char* ESCRITURA = "w";

const char* FORMATO_HABITACION = "%i;%c\n";

const int ERROR = -1;
const int EXITO = 0;

int escribir_habitaciones_vacias(FILE* habitaciones, FILE* llaves_faltantes) {
    FILE* habitaciones_vacias = fopen(ARCHIVO_HABITACIONES_VACIAS, ESCRITURA);
    if(!habitaciones_vacias) {
        printf("No se pudo abrir el archivo de las habitaciones vacias");
        return ERROR;
    }

    int piso, piso_llave;
    char habitacion, habitacion_llave;

    int leido_habitaciones = fscanf(habitaciones, FORMATO_HABITACION, &piso, &habitacion);

    int leido_llaves = fscanf(llaves_faltantes, FORMATO_HABITACION, &piso_llave, &habitacion_llave);

    while(leido_llaves != EOF && leido_habitaciones != EOF) {
        if(piso != piso_llave || habitacion != habitacion_llave){
            fprintf(habitaciones_vacias, FORMATO_HABITACION, piso, habitacion);
        } else if(piso == piso_llave && habitacion == habitacion_llave) {
            leido_llaves = fscanf(llaves_faltantes, FORMATO_HABITACION, &piso_llave, &habitacion_llave);
        }

        leido_habitaciones = fscanf(habitaciones, FORMATO_HABITACION, &piso, &habitacion);
    }

    while(leido_habitaciones != EOF) {
        fprintf(habitaciones_vacias, FORMATO_HABITACION, piso, habitacion);
        leido_habitaciones = fscanf(habitaciones, FORMATO_HABITACION, &piso, &habitacion);
    }

    fclose(habitaciones_vacias);
    return EXITO;
}



int main() {
    FILE* habitaciones = fopen("habitaciones.csv", "r");
    if(!habitaciones) {
        printf("No se pudo abrir el archivo de las habitaciones\n");
        return ERROR;
    }

    FILE* llaves = fopen("llaves_faltantes.csv", "r");
    if(!llaves) {
        printf("No se pudo abrir el archivo de las llaves\n");
        fclose(habitaciones);
        return ERROR;
    }

    if (escribir_habitaciones_vacias(habitaciones, llaves) == EXITO) {
        printf("Se escribió bien\n");
    }
        
    fclose(habitaciones);
    fclose(llaves);
    
    return 0;
}
