#include <stdio.h>
#include <stdbool.h>

#define MAX 7

void ordenar_por_burbujeo_mejorado (int vector[MAX], int tope){
    int i = 0, j, aux;
    bool esta_ordenado = false;

    while((i < tope) && (!esta_ordenado)){
        esta_ordenado = true ;
        for (j = 0; j < tope - 1; j++) {
            if(vector[j] > vector[j+1]) {
                aux = vector[j];
                vector[j] = vector[j + 1];
                vector[j + 1] = aux ;
                esta_ordenado = false ;
            }
        }
        i++;
    }
}


int main() {

    int vector[MAX] = {10, 1, 2, 4, 5, 7, 9};
    int tope = 7;

    ordenar_por_burbujeo_mejorado(vector, tope);

    for(int i = 0; i < tope; i++) {
        if(i == 0) {
            printf("[");
        }
        
        printf(" %i", vector[i]);

        if(i == (tope - 1)) {
            printf( " ]\n");
        }
    }

    return 0;
}