#include <stdio.h>

#define MAX_FILAS 6
#define MAX_COLUMNAS 5
#define FILA_FINAL 5
#define COL_FINAL 4

typedef struct habitacion {
    int fil_sig_habitacion;
    int col_sig_habitacion;
    int cantidad_muebles;
} habitacion_t;


int contar_habitaciones_rec(habitacion_t cuartel[MAX_FILAS][MAX_COLUMNAS], int habitaciones_recorridas, int fila_actual, int columna_actual){
    // condicion de corte
    if(fila_actual == FILA_FINAL && columna_actual == COL_FINAL){
        return habitaciones_recorridas+1;
    }

    // procesamiento
    habitaciones_recorridas++;
    habitacion_t habitacion_actual = cuartel[fila_actual][columna_actual];

    // llamada recursiva
    return contar_habitaciones_rec(cuartel, habitaciones_recorridas, habitacion_actual.fil_sig_habitacion, habitacion_actual.col_sig_habitacion);
}

int contar_habitaciones(habitacion_t cuartel[MAX_FILAS][MAX_COLUMNAS]){
    return contar_habitaciones_rec(cuartel, 0, 0, 0);
}

/*
    Pre: 
    - Cada habitacion de `cuartel` tiene que tener una fila y columna siguiente válida
    - `fila_actual` y `columna_actual` tienen que empezar en (0, 0) en el primer llamado y ser coordenadas válidas.
    - `fila_mas_muebles` y `col_mas_muebles` tienen apuntar a variables inicializadas con 0 en el primer llamado y ser coordenadas válidas.

    Post: Devuelve por referencia la fila y columna de la habitación con más muebles en `fila_mas_muebles` y `col_mas_muebles`
*/ 
void habitacion_con_mas_muebles_rec(habitacion_t cuartel[MAX_FILAS][MAX_COLUMNAS], int fila_actual, int columna_actual, int *fila_mas_muebles , int *col_mas_muebles ){
    // procesamiento
    if(cuartel[*fila_mas_muebles][*col_mas_muebles].cantidad_muebles < cuartel[fila_actual][columna_actual].cantidad_muebles){
        *fila_mas_muebles = fila_actual;
        *col_mas_muebles = columna_actual; 
    }

    // condicion de corte
    if(fila_actual == FILA_FINAL && columna_actual == COL_FINAL){
        return;
    }


    // llamada recursiva
    habitacion_t habitacion_actual = cuartel[fila_actual][columna_actual];
    habitacion_con_mas_muebles_rec(cuartel, habitacion_actual.fil_sig_habitacion, habitacion_actual.col_sig_habitacion, fila_mas_muebles, col_mas_muebles);
}

/*
    Pre: 
    - Cada habitacion de `cuartel` tiene que tener una fila y columna siguiente válida.

    Post: Devuelve por referencia la fila y columna de la habitación con más muebles en `fila_mas_muebles` y `col_mas_muebles`
*/
void habitacion_con_mas_muebles(habitacion_t cuartel[MAX_FILAS][MAX_COLUMNAS], int *fila_mas_muebles , int *col_mas_muebles){
    *fila_mas_muebles = 0;
    *col_mas_muebles = 0;
    habitacion_con_mas_muebles_rec(cuartel,0,0,fila_mas_muebles,col_mas_muebles);
}













int main() {
    int tope_fil = 6;
    int tope_col = 5;

    habitacion_t guarida_sindrome[MAX_FILAS][MAX_COLUMNAS] = {
        {{1, 1, 5}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {2, 3, 6}},
        {{0, 0, 0}, {0, 4, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}},
        {{4, 0, 1}, {0, 0, 0}, {2, 0, 1}, {2, 2, 4}, {0, 0, 0}},
        {{0, 0, 0}, {3, 3, 3}, {4, 2, 0}, {3, 2, 3}, {0, 0, 0}},
        {{3, 1, 2}, {0, 0, 0}, {5, 4,18}, {0, 0, 0}, {0, 0, 0}},
        {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 6}}
    };

    printf("Se recorrieron %i habitaciones\n", contar_habitaciones(guarida_sindrome));

    int fila;
    int columna;
    habitacion_con_mas_muebles(guarida_sindrome, &fila, &columna);

    printf("La mayor cantidad de muebles rotos en una habitacion fue en (%i,%i)\n", fila, columna);
    return 0;
}