#include <stdio.h>
#include <stdlib.h>

// ejercicio 2.a
// int main() {
//     int cantidad_letras;

//     printf("¿Cuántas letras tiene tu frase xeneize?\n");
//     scanf("%i", &cantidad_letras);

//     // malloc( CUANTO_OCUPA_UNO_DE_MIS_ELEMENTOS * CANTIDAD_DE_ELEMENTOS)
    
//     char* frase = malloc(sizeof(char) * (cantidad_letras + 1)); // +1 por el '\0' del string

//     printf("Ingrese la frase:\n");
//     // scanf("%s", frase); // lee hasta un ' ' o '\n'
//     scanf(" %[^\n]", frase); // lee hasta un \n

//     printf("La frase ingresada es: %s\n", frase);

//     free(frase);

//     return 0;
// }


void pedir_cantidad_letras(int *cantidad_letras) {
    printf("¿Cuántas letras tiene tu frase xeneize?\n");
    scanf("%i", cantidad_letras);
}

void pedir_frase(char* frase) {
    printf("Ingrese la frase:\n");
    // scanf("%s", frase); // lee hasta un ' ' o '\n'
    scanf(" %[^\n]", frase); // lee hasta un \n
}

// ejercicio 2.b
int main() {
    int cantidad_letras;

    pedir_cantidad_letras(&cantidad_letras);

    // malloc( CUANTO_OCUPA_UNO_DE_MIS_ELEMENTOS * CANTIDAD_DE_ELEMENTOS)
    
    char* frase = malloc(sizeof(char) * (cantidad_letras + 1)); // +1 por el '\0' del string

    pedir_frase(frase);

    printf("La primera frase ingresada es: %s\n", frase);

    // Luego repetir, para la segunda frase redimensionando la memoria reservada en caso de ser necesario.

    pedir_cantidad_letras(&cantidad_letras);

    // redimensionar
    frase = realloc(frase, sizeof(char) * (cantidad_letras + 1));

    pedir_frase(frase);

    printf("La segunda frase ingresada es: %s\n", frase);

    // free(frase);

    return 0;
}
