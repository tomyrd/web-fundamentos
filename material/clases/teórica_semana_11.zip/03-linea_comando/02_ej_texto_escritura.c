#include <stdio.h>
#include <string.h>

#define MAX_LINEA 100

const int ERROR_CANT_ARGUMENTOS = 4;
const int ERROR_APERTURA = 3;
const int EXITO = 0;

const int CANT_MIN_ARGUMENTOS = 2;
const int POS_ARG_NUEVA_LINEA = 1;


int main (int argc, char* argv[]) {
    if (argc < CANT_MIN_ARGUMENTOS) {
        printf("Cantidad de argumentos inválidos\n");
        return ERROR_CANT_ARGUMENTOS;
    }

    FILE* los_simpsons = fopen("los_simpson.txt", "a");

    if (!los_simpsons) {
        printf("Error al abrir el archivo\n");
        return ERROR_APERTURA;
    }

    char linea[MAX_LINEA];
    strcpy(linea, argv[POS_ARG_NUEVA_LINEA]);

    int escrito = fprintf(los_simpsons, "%s\n", linea);

    printf("Se escribio %i elementos\n", escrito);

    fclose(los_simpsons);

    return EXITO;
}