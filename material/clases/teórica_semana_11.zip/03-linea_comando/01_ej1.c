#include <stdio.h>

const int EXITO = 0;

int main (int argc, char* argv[]) {
    printf("Se recibieron %i argumentos\n\n", argc);
    for(int i = 0; i < argc; i++) {
        printf("Argumento %i: %s\n", i, argv[i]);
    }

    return EXITO;
}