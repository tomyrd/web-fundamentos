#include <stdio.h>

const int ERROR = -1;

#define MAX_LINEA 1000

int main () {

    FILE* los_simpsons = fopen("los_simpsons.txt", "a");

    if (!los_simpsons) {
        printf("Error al abrir el archivo\n");
        return ERROR;
    }

    char linea[MAX_LINEA] = "\nEsta es una línea agregada por nosotros los alumnos el martes 28 de octubre de 2025.\0";

    int escrito = fprintf(los_simpsons, "%s\n", linea);

    printf("Se escribio %i elementos\n", escrito);

    fclose(los_simpsons);

    return 0;
}