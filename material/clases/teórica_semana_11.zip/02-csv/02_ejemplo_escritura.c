#include <stdio.h>
#include <string.h>

#define MAX_NOMBRE_ALUMNO 100
#define MAX_CORRECTOR 50

const int ERROR = -1;

const char* CORRECTOR_RENUNCIO = "Berni";
const char* CORRECTOR_NUEVO = "Mario";

int main () {

    FILE* alumnos = fopen("alumnos.csv", "r");
    if (!alumnos) {
        printf("Error al abrir el archivo\n");
        return ERROR;
    }

    FILE* auxiliar = fopen("temporal.csv", "w");
    if (!auxiliar) {
        printf("Error al abrir el archivo\n");
        fclose(alumnos);
        return ERROR;
    }

    int id_alumno;
    char nombre_alumno[MAX_NOMBRE_ALUMNO];
    char corrector[MAX_CORRECTOR];
    int nro_alumno = 0;

    int leido = fscanf(alumnos, "%i;%[^;];%[^\n]\n", &id_alumno, nombre_alumno, corrector);

    while(leido != EOF) {
        nro_alumno++;

        if (strcmp(corrector, CORRECTOR_RENUNCIO) == 0) {
            strcpy(corrector, CORRECTOR_NUEVO);
        }

        fprintf(auxiliar, "%i;%s;%s\n", id_alumno, nombre_alumno, corrector);

        leido = fscanf(alumnos, "%i;%[^;];%[^\n]\n", &id_alumno, nombre_alumno, corrector);
    }

    fclose(alumnos);
    fclose(auxiliar);

    remove("alumnos.csv");
    rename("temporal.csv", "alumnos.csv");

    return 0;
}