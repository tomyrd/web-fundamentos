#include <stdio.h>

const int ERROR = -1;

#define MAX_NOMBRE_ALUMNO 100
#define MAX_CORRECTOR 50

int main () {

    FILE* alumnos = fopen("alumnos.csv", "r");

    if (!alumnos) {
        printf("Error al abrir el archivo\n");
        return ERROR;
    }

    int id_alumno;
    char nombre_alumno[MAX_NOMBRE_ALUMNO];
    char corrector[MAX_CORRECTOR];
    int nro_alumno = 0;

    int leido = fscanf(alumnos, "%i;%[^;];%[^\n]\n", &id_alumno, nombre_alumno, corrector);

    while(leido != EOF) {
        nro_alumno++;
        printf("Alumno %i:\nid:%i\nnombre: %s\ncorrector: %s\n\n", nro_alumno, id_alumno, nombre_alumno, corrector);
        leido = fscanf(alumnos, "%i;%[^;];%[^\n]\n", &id_alumno, nombre_alumno, corrector);
    }

    fclose(alumnos);

    return 0;
}