#include <stdio.h>

#define MAX_FILAS 4
#define MAX_COLUMNAS 5

const int NO_ENCONTRADO = -1;
const int VACIO = -1;

// pre:COMPLETAR!
// post: COMPLETAR!
void buscar_numero(int carton[MAX_FILAS][MAX_COLUMNAS], int numero, int* pos_fila, int* pos_col){
    (*pos_fila) = NO_ENCONTRADO;
    (*pos_col) = NO_ENCONTRADO;

    for(int i=0; i<MAX_FILAS; i++){
        for(int j=0; j<MAX_COLUMNAS; j++){
            if(carton[i][j] == numero){
                (*pos_fila) = i;
                (*pos_col) = j;
            }
        }
    }
}

// pre:COMPLETAR!
// post: COMPLETAR!
void imprimir_carton(int carton[MAX_FILAS][MAX_COLUMNAS]){
    for(int i=0; i<MAX_FILAS; i++){
        for(int j=0; j<MAX_COLUMNAS; j++){
            printf("%i\t", carton[i][j]);
        }
        printf("\n");
    } 
}

// pre:COMPLETAR!
// post: COMPLETAR!
void eliminar_numero(int carton[MAX_FILAS][MAX_COLUMNAS], int pos_fil, int pos_col){
    carton[pos_fil][pos_col] = VACIO;
}


int main(){

    int carton[MAX_FILAS][MAX_COLUMNAS] = {{9, 11, -1, 50, 8}, {-1, -1, 4, 38, 59}, {7, 21, 24, -1, 30}, {19, -1, 5, 12, -1}};
    imprimir_carton(carton);
    
    int pos_fil = 0;
    int pos_col = 0;

    buscar_numero(carton, 59, &pos_fil, &pos_col);
    printf("la posición de la fila es %i y la posición de la columna es %i\n", pos_fil, pos_col);

    eliminar_numero(carton, pos_fil, pos_col);

    imprimir_carton(carton);

    buscar_numero(carton, 59, &pos_fil, &pos_col);
    printf("la posición de la fila es %i y la posición de la columna es %i\n", pos_fil, pos_col);

    return 0;
}













