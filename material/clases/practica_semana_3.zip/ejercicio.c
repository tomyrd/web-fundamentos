#include <stdio.h>
#include <stdbool.h>

const int MAX_INICIALES = 3000;
const int NO_EXISTE = -1;


//Pre: cant_iniciales debe ser mayor a 0. cant_iniciales debe ser menor a MAX_INICIALES.
// El vector de iniciales contendrá como mucho un numeral.
//Post: Devuelve la posicion del numeral en el vector de iniciales
// o -1 en caso de que no se encuentre.
int buscar_numeral(char iniciales[MAX_INICIALES], int cant_iniciales){
    int posicion_numeral = 0;
    int i = 0;

    bool encontrado = false;

    while(i < cant_iniciales && !encontrado){
        if(iniciales[i] == '#'){
            posicion_numeral = i;
            encontrado = true;
        }

        i++;
    }

    if(encontrado){
        return posicion_numeral;
    } else {
        return NO_EXISTE;
    }
}


void agregar_nueva_inicial(char iniciales[MAX_INICIALES], int* cant_iniciales, char nueva_letra){
    iniciales[*cant_iniciales] = nueva_letra;
    *cant_iniciales+=1;
}


int main(){
    char iniciales[MAX_INICIALES];

    iniciales[0] = 'C';
    iniciales[1] = 'A';
    iniciales[2] = '#'; 
    iniciales[3] = 'D';
    iniciales[4] = 'L';

    int cant_iniciales = 5;


    printf("La posicion del numeral es: %i\n", buscar_numeral(iniciales, cant_iniciales));

    printf("Cantidad iniciales: %i\n", cant_iniciales);

    agregar_nueva_inicial(iniciales, &cant_iniciales ,'J');

    printf("Cantidad iniciales: %i\n", cant_iniciales);

    for(int i = 0; i < cant_iniciales; i++){
        printf("Inicial %i: %c\n", i, iniciales[i]);
    }

    return 0;
}
