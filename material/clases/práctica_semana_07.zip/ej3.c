#include <stdio.h>
#include <stdlib.h>
#include "cuestionario_visitante.h"

#define MAX_NOMBRE 50

typedef struct visitante{
    char nombre_visitante[MAX_NOMBRE];
    int edad;
    char dia_visita; // ‘L’, ‘M’, ‘X’, ‘J’, ‘V’, ‘S’, ‘D’
} visitante_t;

typedef struct abuelo{
    char nombre[MAX_NOMBRE];
    visitante_t* visitantes;
    int cantidad_visitantes;
} abuelo_t;

const char LUNES = 'L';
const char MARTES = 'M';
const char MIERCOLES = 'X';
const char JUEVES = 'J';
const char VIERNES = 'V';
const char SABADO = 'S';
const char DOMINGO = 'D';

const int EDAD_MINIMA = 0;
const int EDAD_MAXIMA = 100;

const int ERROR = -1;
const int EXITO = 0;

// pre: -
// post: se guarda en el abuelo el nombre del abuelo ingresado por el usuario.
void preguntar_nombre_abuelo(abuelo_t *abuelo) {
    printf("Ingrese el nombre del abuelo: ");
    scanf("%s", abuelo->nombre);
}

void preguntar_cant_visitantes(abuelo_t* abuelo){
    printf("Ingrese la cantidad de visitantes del abuelo: ");
    scanf("%i", abuelo->cantidad_visitantes);
}

visitante_t* crear_visitantes(int cant_visitantes){
    visitante_t* visitantes = malloc(sizeof(visitante_t)*cant_visitantes);
    if(!visitantes){
        printf("no se pudo reservar la memoria para los visitantes\n");
        return NULL; 
    }
    for(int i = 0; i < cant_visitantes; i++){
        preguntar_nombre_visitante(visitantes[i].nombre_visitante);
        preguntar_edad_visitante(&(visitantes[i].edad));
        preguntar_dia_visita(&(visitantes[i].dia_visita));
    }

    return visitantes;
}

int inicializar_abuelo(abuelo_t* nuevo_abuelo){
    preguntar_nombre_abuelo(nuevo_abuelo);
    preguntar_cant_visitantes(nuevo_abuelo);
    visitante_t* visitantes = crear_visitantes(nuevo_abuelo->cantidad_visitantes);
    if(!visitantes){
        return ERROR;
    }
    nuevo_abuelo->visitantes = visitantes;
    return EXITO;
}

abuelo_t* crear_abuelo(){
    abuelo_t* nuevo_abuelo = malloc(sizeof(abuelo_t));
    if(!nuevo_abuelo){
        printf("no se pudo reservar la memoria para el abuelo\n");
        return NULL; 
    }
    int resultado = inicializar_abuelo(nuevo_abuelo);
    if(resultado == -1){
        return NULL;
    }
    return nuevo_abuelo;
}

abuelo_t* crear_hogar(int* cant_abuelos){
    printf("Ingrese la cantidad de abuelos del hogar: ");
    scanf("%i", cant_abuelos);

    abuelo_t* hogar = malloc(sizeof(abuelo_t)* (*cant_abuelos));
    if(!hogar){
        printf("no se pudo reservar la memoria para los abuelos\n");
        return NULL; 
    }
    
    int i = 0;
    int resultado = EXITO;
    while(i < (*cant_abuelos) && resultado != ERROR){
        resultado = inicializar_abuelo(hogar+i);
        if(resultado == ERROR){
            for(int j = 0; j < i; j++){
                free(hogar[j].visitantes);
            }
            free(hogar);
        }
        i++;
    }
    if(resultado == ERROR){
        return NULL;
    }
    return hogar;
}

void liberar_hogar(abuelo_t* hogar, int cant_abuelos){
    for(int i = 0; i < cant_abuelos; i++){
        free(hogar[i].visitantes);
    }
    free(hogar);
}

int main() {
    return 0;
}