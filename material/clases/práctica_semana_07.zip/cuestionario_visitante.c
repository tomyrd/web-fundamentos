#include "cuestionario_visitante.h"

const char LUNES = 'L';
const char MARTES = 'M';
const char MIERCOLES = 'X';
const char JUEVES = 'J';
const char VIERNES = 'V';
const char SABADO = 'S';
const char DOMINGO = 'D';

const int EDAD_MINIMA = 0;
const int EDAD_MAXIMA = 100;


// pre: -
// post: se guarda en el visitante el nombre del visitante ingresado por el usuario.
void preguntar_nombre_visitante(char *visitante_nombre) {
    printf("Ingrese el nombre del visitante: ");
    scanf("%s", visitante_nombre);
}

bool es_dia_valido(char dia_visita) {
    return dia_visita == LUNES || dia_visita == MARTES || dia_visita == MIERCOLES || dia_visita == JUEVES || dia_visita == VIERNES || dia_visita == SABADO || dia_visita == DOMINGO;
}


void preguntar_dia_visita(char *dia_visita) {
    printf("Ingrese el dia de la visita: ");
    scanf("%c", dia_visita);
    while(!es_dia_valido(*dia_visita)) {
        printf("El dia de la visita no es valido. Ingrese el dia de la visita nuevamente: ");
        scanf("%c", dia_visita);
    }
}

bool es_edad_valida(int edad) {
    return edad > 0 && edad <= EDAD_MAXIMA;
}

void preguntar_edad_visitante(int *edad) {
    printf("Ingrese la edad del visitante: ");
    scanf("%d", edad);
    while(*edad < EDAD_MINIMA || *edad > EDAD_MAXIMA) {
        printf("La edad no puede ser negativa. Ingrese la edad nuevamente: ");
        scanf("%d", edad);
    }
}