#ifndef __CUESTIONARIO_VISITANTE_H__
#define __CUESTIONARIO_VISITANTE_H__

#include <stdbool.h>
#include <stdio.h>

// pre: -
// post: carga el nombre de visitante con lo que ingresa el usuario
void preguntar_nombre_visitante(char *visitante_nombre);

// pre: -
// post: carga el dia visita con lo que ingresa el usuario
void preguntar_dia_visita(char *dia_visita);

// pre: -
// post: carga la edad con el valor que ingresa el usuario
void preguntar_edad_visitante(int *edad);

// pre: -
// post: devuelve true si es un día de la semana, false si no
bool es_dia_valido(char dia_visita);

// pre: -
// post: devuelve true si la edad está entre 0 y EDAD_MAXIMA, false si no
bool es_edad_valida(int edad);

#endif