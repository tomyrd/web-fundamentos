#include <stdio.h>
#include <stdlib.h>

#define MAX_NOMBRE 50

typedef struct producto{
	char nombre[MAX_NOMBRE];
    int cantidad;
} producto_t;


// pre: -
// post: se guarda en el producto el nombre ingresado por el usuario.
void pedir_nombre_producto(producto_t *producto) {
    printf("Ingrese el nombre del producto: ");
    scanf("%s", producto->nombre);
}

// pre: -
// post: se guarda en el producto la cantidad del producto ingresado por el usuario. Esta va a ser mayor a 0.
void pedir_cantidad_de_producto(producto_t *producto) {
    printf("Ingrese la cantidad del producto: ");
    scanf("%d", &producto->cantidad);
    while(producto->cantidad < 0) {
        printf("La cantidad no puede ser negativa. Ingrese la cantidad nuevamente: ");
        scanf("%d", &producto->cantidad);
    }
}

// pre: -
// post: devuelve un puntero a un arreglo de productos inicializado, o NULL cuando no se pudo reservar la memoria
producto_t* inicializar_compras(int* cant_productos){
    printf("cuantos productos queres comprar?\n");
    scanf("%i", cant_productos);
    // chequear que sea mayor a 0

    //producto_t lista_de_compras[100];

    producto_t* lista_de_compras = malloc(sizeof(producto_t) * (*cant_productos));
    if(lista_de_compras == NULL){
        printf("no se pudo reservar la memoria\n");
        return NULL;
    }

    for(int i = 0; i < (*cant_productos); i++){
        pedir_nombre_producto(lista_de_compras+i);
        pedir_cantidad_de_producto(lista_de_compras+i);
        // &(lista_de_compras[i]) = lista_de_compras+i
    }

    return lista_de_compras;
}

// pre: lista_de_compras tiene que haber sido creado con memoria dinamica. La cantidad de productos tiene que corresponder con la cantidad de elementos que tiene la lista de compras.
// post: devuelve un puntero a un vector con el nuevo producto agregado, o NULL si no pudo reservar la memoria para el nuevo vector.
producto_t* agregar_producto(producto_t* lista_de_compras, int* cant_productos, producto_t nuevo_producto){
    producto_t* nueva_lista = realloc(lista_de_compras, sizeof(producto_t)*((*cant_productos)+1));
    if(nueva_lista == NULL){
        printf("no se pudo reservar mas memoria\n");
        return NULL;
    }
    
    nueva_lista[(*cant_productos)] = nuevo_producto;
    (*cant_productos)++;

    return nueva_lista;
}

int main() {
    int cant_productos = 0;
    producto_t* lista_de_compras = inicializar_compras(&cant_productos);
    if(lista_de_compras == NULL){
        return 1;
    }

    for(int i = 0; i < cant_productos; i++){
        printf("nombre: %s\n", lista_de_compras[i].nombre);
        printf("cant: %i\n", lista_de_compras[i].cantidad);
        printf("-------\n");
    }

    producto_t producto_nuevo = {"coca", 1};
    printf("\n\n\n\n\nAGREGO:\n");
    lista_de_compras = agregar_producto(lista_de_compras, &cant_productos, producto_nuevo);
    if(lista_de_compras == NULL){
        return 1;
    }

    for(int i = 0; i < cant_productos; i++){
        printf("nombre: %s\n", lista_de_compras[i].nombre);
        printf("cant: %i\n", lista_de_compras[i].cantidad);
        printf("-------\n");
    }

    free(lista_de_compras);
    return 0;
}