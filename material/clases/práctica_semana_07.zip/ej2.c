#include <stdio.h>
#include <string.h>
#define MAX 10

int main(){
   char nombre[MAX]; // declaro un string en el stack
   strcpy(nombre, "Homero"); // copio la palabra Homero al string

   char* p = nombre + 5; // declaro un puntero a char en el stack. Le asigno nombre movido 2 bytes (cada char ocupa un byte). p apunta a 'm'. 
  
   printf("%c", p[2]); // imprimo la tercera posición de p, que es 'r'.
}
