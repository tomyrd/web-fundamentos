/*
Funciones de Strings:
- strcat -> concatena dos Strings
- strcpy -> copia un String a otro
- strcmp -> compara 2 strings (alfabeticamente)
            0 -> iguales
            > 0 -> s1 > s2
            < 0 -> s1 < s2
- strlen -> largo de string
*/

#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_PALABRA 100

#define IGUALES 5
#define DISTINTAS 10
#define TE_GANE 20
#define PERDI 0

#define VACIA "-"

#define ASCII_A 65
#define ASCII_Z 90
#define ASCII_a 97
#define ASCII_z 122

bool es_letra_mayus(int valor_ascii){
    return valor_ascii >= ASCII_A && valor_ascii <= ASCII_Z;
}

bool es_letra_minus(int valor_ascii){
    return valor_ascii >= ASCII_a && valor_ascii <= ASCII_z;
}

bool es_letra(int valor_ascii){
    return es_letra_mayus(valor_ascii) || es_letra_minus(valor_ascii);
}

bool tiene_solo_letras(char palabra[MAX_PALABRA]){
    bool son_todas_letras = true;
    for(int i = 0; i < strlen(palabra); i++){
        char letra = palabra[i];
        int valor_ascii = (int)letra;
        if(!es_letra(valor_ascii)){
            son_todas_letras = false;
        }        
    }

    return son_todas_letras;
}

bool palabra_valida(char palabra[MAX_PALABRA], char letra){
    char primer_letra = palabra[0];

    if(strcmp(palabra, VACIA) == 0){
        return true;
    }

    return primer_letra == letra && tiene_solo_letras(palabra);
}

void pedir_palabra(char palabra[MAX_PALABRA], char letra){
    printf("Ingresa una palabra no hagas trampa, es con %c: ", letra);
    scanf(" %s", palabra);
    while(!palabra_valida(palabra, letra)){
        printf("Flaca no hagas trampa es una palabra no hagas trampa, es con %c: ", letra);
        scanf(" %s", palabra);
    }

    if(strcmp(palabra, VACIA) == 0){
        strcpy(palabra, "");
    }
}

void convertir_a_mayuscula(char palabra[MAX_PALABRA]){
    for(int i = 0; i < strlen(palabra); i++){
        if(es_letra_minus((int)palabra[i])){
            int letra_mayus = (int)palabra[i] - 32; //constante!!!
            palabra[i] = (char)letra_mayus;
        }
    }
}


int puntaje(char palabra_agus[MAX_PALABRA], char palabra_valen[MAX_PALABRA]){
    if(strlen(palabra_agus) == 0){
        return PERDI;
    }
    else{
        if(strlen(palabra_valen) == 0){
            return TE_GANE;
        }
    }    
    if(strcmp(palabra_agus, palabra_valen) == 0){
        return IGUALES;
    }
    else{
        return DISTINTAS;
    }
}

int main(){
    char letra = '.';
    printf("Dame la letra: ");
    scanf(" %c", &letra);

    char palabra_agus[MAX_PALABRA];
    char palabra_valen[MAX_PALABRA];
    char palabra_tomy[MAX_PALABRA];

    pedir_palabra(palabra_agus, letra);
    pedir_palabra(palabra_valen, letra);
    pedir_palabra(palabra_tomy, letra);

    printf("\nEl puntaje de Agus es : %i\n", puntaje(palabra_agus, palabra_valen));
    convertir_a_mayuscula(palabra_tomy);
    printf("Palabra en mayuscula: %s \n", palabra_tomy);

    printf("%c\n", 'a' + 32);
    return 0;
}