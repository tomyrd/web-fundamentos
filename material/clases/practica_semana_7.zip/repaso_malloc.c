#include<stdio.h>

int main(){
    pedir_memoria("tomas");
    printf("%s", tomas); // :(

    //Funcion para pedir
    //memoria
    int* puntero_tomy = malloc(4); //reserva 4 bytes (un int). Devuelve un puntero a un int
    *puntero_tomy = 42; //le asigno un valor a la memoria reservada para tomy

    //tenemos que devolver la memoria pedida!
    free(puntero_tomy);

    return 0;
}