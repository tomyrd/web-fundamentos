#include <stdio.h>
#include <stdlib.h>

typedef struct mascota {
    char animal;
    int edad;
} mascota_t;


typedef struct hogar {
    int cant_mascotas;
    mascota_t *mascotas;
} hogar_t;

// Armar un programa que lo ayude 
// a armar un vector de hogares 
// con información sobre los 
// alumnos y calculé las 
// estadísticas necesarias.

int main() {
    int cantidad_hogares;
    printf("Cuantos hogares vas a ingresar?");
    scanf("%i", &cantidad_hogares);

    hogar_t* hogares = malloc(cantidad_hogares * sizeof(hogar_t));

    for(int j = 0; j < cantidad_hogares; j++){
        printf("Cuantas mascotas tenes?\n");
        scanf("%i", &(hogares[j].cant_mascotas));

        hogares[j].mascotas = malloc(sizeof(mascota_t) * hogares[j].cant_mascotas);

        for(int i = 0; i < hogares[j].cant_mascotas; i++) {
            printf("Que animal tenes?");
            scanf(" %c", &(hogares[j].mascotas[i].animal));

            printf("Que edad tiene tu pichicho?");
            scanf("%i", &(hogares[j].mascotas[i].edad));
        }
    }


    // "estadísticas necesarias" == promedio de mascotas por hogar y edad promedio de mascotas
    int cantidad_total_mascotas = 0;
    int suma_edades = 0;
    for(int j = 0; j < cantidad_hogares; j++){
        cantidad_total_mascotas += hogares[j].cant_mascotas;
        for(int i = 0; i < hogares[j].cant_mascotas; i++){
            suma_edades += hogares[j].mascotas[i].edad;
        }
    }    
    int promedio = suma_edades / cantidad_total_mascotas;
    printf("El promedio de edad de mascotas es: %i\n", promedio);

    // liberar memoria
    for(int j = 0; j < cantidad_hogares; j++){
        free(hogares[j].mascotas);
    }

    free(hogares);

    return 0;
}