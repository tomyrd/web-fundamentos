#include <stdio.h>
#include <stdlib.h>

int main(){
    int* numero_pedido = malloc(sizeof(int));

    printf("Ingrese un numero:");
    scanf("%i", numero_pedido);

    printf("El numero es: %i\n", *numero_pedido);

    if((*numero_pedido)%2 == 0){
        printf("Por más que me caiga en una cloaca, me levanto y huelo a rosas ¡mi amor!\n");
    } else {
        printf("El decorado se calla\n");
    }

    free(numero_pedido);
    return 0;
}
