#include<stdio.h>

typedef struct alumno{
    int padron;
    char nombre[100];
    int edad;
    int notas[50];
    int cant_notas;
} alumno_t;

int main(){
    alumno_t tomi;
    printf("%li", sizeof(alumno_t));

    return 0;
}
