#include <stdio.h>
#include <stdlib.h>

int main(){
    int cant_letras = 0;

    printf("Ingrese la cantidad de letras de su mensaje:");
    scanf(" %i", &cant_letras);

    char* saludo_cumple = malloc(sizeof(char)*(cant_letras+1));

    printf("Ingrese el saludo:");
    scanf(" %[^\n]", saludo_cumple);
    printf("Tu saludo es: %s", saludo_cumple);


    free(saludo_cumple);
    return 0;
}
