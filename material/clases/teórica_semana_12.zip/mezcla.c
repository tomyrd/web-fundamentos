#include <stdio.h>

#define FORMATO "%i\n"

// pre condiciones: 'archivo_a' y 'archivo_b' archivos abiertos en modo lectura, 'resultado' archivo abierto en modo escritura. Ambos archivos están ordenados de manera ascentente.
// post condiciones: devuelve en el contenido de 'resultado' la mezcla ordenada ascentenmente del contenido de 'archivo_a' y 'archivo_b'.
void mezclar_archivos(FILE* archivo_a, FILE* archivo_b, FILE* resultado) {
    int valor_a;
    int leido_a = fscanf(archivo_a, FORMATO, &valor_a);

    int valor_b;
    int leido_b = fscanf(archivo_b, FORMATO, &valor_b);

    while(leido_a != EOF && leido_b != EOF) {
        if(valor_a < valor_b) { //escribimos a y avanzamos en a
            fprintf(resultado, FORMATO, valor_a);
            leido_a = fscanf(archivo_a, FORMATO, &valor_a);
        } else if (valor_a > valor_b) { //escribimos b y avanzamos en b
            fprintf(resultado, FORMATO, valor_b);
            leido_b = fscanf(archivo_b, FORMATO, &valor_b);
        } else { // valor_a == valor_b
            // escribimos y avanzamos ambos
            fprintf(resultado, FORMATO, valor_a);
            fprintf(resultado, FORMATO, valor_b);
            leido_a = fscanf(archivo_a, FORMATO, &valor_a);
            leido_b = fscanf(archivo_b, FORMATO, &valor_b);
        }
    }

    while(leido_a != EOF) {
        // cuando terminó b, sigo con a
        fprintf(resultado, FORMATO, valor_a);
        leido_a = fscanf(archivo_a, FORMATO, &valor_a);
    }

    while(leido_b != EOF) {
        // cuando terminó a, sigo con b
        fprintf(resultado, FORMATO, valor_b);
        leido_b = fscanf(archivo_b, FORMATO, &valor_b);
    }
}
