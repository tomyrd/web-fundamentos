#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_FIRMAS 5
#define MAX_LETRAS 50
#define MAX_COMUNICADOS 10
#define MAX_EXCURSIONES 10
#define MAX 10
#define EXCURSION_BUSCADA "fabrica de cajas"
const int CANT_MIN_FIRMAS = 2;
const int NO_ENCONTRADA = -1;


typedef struct comunicado {
    char firmas[MAX_FIRMAS][MAX_LETRAS];
    int cant_firmas;
    char excursion[MAX_EXCURSIONES];
} comunicado_t;

typedef struct cuaderno {
    comunicado_t comunicados[MAX_COMUNICADOS];
    int cant_comunicados;
} cuaderno_t;


//pre: el campo 'excursion' de los comunicado_t del cuaderno_t tienen que ser strings.
//     el campo 'cant_comunicados' tiene que ser mayor o igual a cero y menor a MAX_COMUNICADOS.
//post: devuelve true si hay un comunicado en el cuaderno que es a EXCURSION_BUSCADA y con CANT_MIN_FIRMAS o más firmas.
bool tiene_excursion_buscada(cuaderno_t cuaderno) {
    bool tiene_excursion = false;
    for(int i=0; i<cuaderno.cant_comunicados; i++) {
        if(strcmp(cuaderno.comunicados[i].excursion, EXCURSION_BUSCADA) == 0 && cuaderno.comunicados[i].cant_firmas >= CANT_MIN_FIRMAS) {
            tiene_excursion = true;
        }
    }

    return tiene_excursion;
}


//pre: el campo 'excursion' de los comunicado_t de los cuaderno_t tienen que ser strings.
//     el campo 'cant_comunicados' tiene que ser mayor o igual a cero y menor a MAX_COMUNICADOS.
//post: devuelve el índice de la columna que tiene la menor cantidad de comunicados de EXCURSION_BUSCADA y con CANT_MIN_FIRMAS o más firmas.
int columna_menos_permiso(cuaderno_t bus[MAX][MAX], int tope_fil, int tope_col) {
    int indice_col_menos_permisos = NO_ENCONTRADA;
    int cantidad_permisos_min = 0;

    int cantidad_permisos_actual = 0;
    for(int j=0; j<tope_col; j++) {
        cantidad_permisos_actual = 0;

        for(int i=0; i<tope_fil; i++) {
            if(tiene_excursion_buscada(bus[i][j])) {
                cantidad_permisos_actual++;
            }
        }

        if (indice_col_menos_permisos == NO_ENCONTRADA || cantidad_permisos_actual < cantidad_permisos_min) {
            indice_col_menos_permisos = j;
            cantidad_permisos_min = cantidad_permisos_actual;
        }
    }

    return indice_col_menos_permisos;
}
