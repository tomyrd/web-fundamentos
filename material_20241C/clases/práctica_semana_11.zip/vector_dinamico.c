#include "vector_dinamico.h"
#include <stdio.h>
#include <stdlib.h>

const int TAM_INICIAL = 4;
const int FACTOR_CRECIMIENTO = 2;
const char INVALIDA = '\0';

struct vector_din{
    char *datos;
    size_t tope;
    size_t tamanio;
};

vector_din_t* vec_crear(){
    vector_din_t *vector = malloc(sizeof(vector_din_t));
    if(vector == NULL){
        // Fallo el malloc
        return NULL;
    }

    vector->tope = 0;
    vector->tamanio = TAM_INICIAL;
    vector->datos = malloc(sizeof(char) * TAM_INICIAL);
    if(vector->datos == NULL){
        free(vector);
        return NULL;
    }

    return vector;
}

void vec_destruir(vector_din_t* vec){
    free(vec->datos);
    free(vec);
}

char vec_obtener(vector_din_t* vec, size_t pos){
    if(pos >= vec->tope){
        return INVALIDA;
    }
    return vec->datos[pos];
}

size_t vec_largo(vector_din_t* vec){
    return vec->tope;
}

bool vec_guardar(vector_din_t* vec, char valor){
    if(vec->tope < vec->tamanio){
        vec->datos[vec->tope] = valor;
        (vec->tope)++;
    } else {
        vec->datos = realloc(vec->datos, vec->tamanio*FACTOR_CRECIMIENTO);
        //Chequear error
        vec->tamanio *= FACTOR_CRECIMIENTO;
        (vec->tope)++;
    }

    return true;
}

void vec_eliminar(vector_din_t* vec, size_t pos){
    if(pos >= vec->tope){
        return;
    }

    if(vec->tope > 1){
        for(size_t i = pos+1; i < vec->tope; i++){
            vec->datos[i-1] = vec->datos[i];
        }
    }

    (vec->tope)--;
}


void vec_imprimir(vector_din_t* vec) {
    printf("[");
    if (vec->tope > 0) {
        printf("%c", vec->datos[vec->tope - 1]);
    }
    for (size_t i = 1; i < vec->tope - 1; i++) {
        printf(";%c", vec->datos[i]);
    }
    printf("]\n");
}
