#include <stdio.h>
#include <string.h> 
#include "vector_dinamico.h"

size_t obtener_posicion(vector_din_t* atracciones, char atraccion){
    size_t tope = vec_largo(atracciones);
    bool encontrada = false;
    size_t posicion_actual = 0;
    while(!encontrada && posicion_actual < tope){
        char atraccion_actual = vec_obtener(atracciones, posicion_actual);
        if(atraccion_actual == atraccion){
            encontrada = true;
        }
        posicion_actual++;
    }
    
    if(!encontrada){
        return tope+1;
    }

    return posicion_actual-1;
}

bool atraccion_existe(vector_din_t* atracciones, char atraccion){
    return obtener_posicion(atracciones, atraccion) >= vec_largo(atracciones)-1;
}

//No sabemos lo q tiene adentro, solo podemos usar el .h
bool procesar_comando(char comando[100], vector_din_t* atracciones){
    if(strcmp(comando, "agregar") == 0){
        printf("Ingrese el caracter de la atracción a agregar: ");
        char atraccion;
        scanf(" %c", &atraccion);
        if(!atraccion_existe(atracciones, atraccion)){
            if(vec_guardar(atracciones, atraccion)){
                printf("Atracción agregada exitosamente.\n");
            }else{
                printf("Atracción no pudo agregarse.\n");
            }
        }else{
            printf("Atracción repetida\n");
        }       

    } else if(strcmp(comando, "eliminar") == 0){
        printf("Ingrese el caracter de la atracción a eliminar: ");
        char atraccion;
        scanf(" %c", &atraccion);
        size_t pos = obtener_posicion(atracciones, atraccion);
        vec_eliminar(atracciones, pos);
            
    } else if(strcmp(comando, "consultar") == 0){
        vec_imprimir(atracciones);        
    } else if(strcmp(comando, "exit") == 0){
        return false;        
    }else if(strcmp(comando, "cantidad") == 0){
        printf("La cantidad es: %lu\n", vec_largo(atracciones));
    } else {
        printf("Comando no reconocido\n");
    }

    return true;
}


void gestionar_atracciones(vector_din_t* atracciones){
    char input[100] = ""; //necesitamos memoria dinamica para esto? -> no 
    bool seguir = true;
    while(strcmp(input, "exit") != 0 || seguir){
        printf("Ingrese el comando: ");
        scanf("%s", input);
        seguir = procesar_comando(input, atracciones);
    }
    printf("Fin de la gestión.");
}

int main(){
    vector_din_t* atracciones = vec_crear();
    gestionar_atracciones(atracciones);
    vec_destruir(atracciones);

    return 0;
}