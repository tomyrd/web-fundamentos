#ifndef VEC_DIN_H
#define VEC_DIN_H

#include <stdbool.h>
#include <stddef.h>

/*
    Interfáz de un vector dinámico de caracteres.
    Las posiciones del vector se numeran desde 0.
*/

struct vector_din;
typedef struct vector_din vector_din_t;

// Post: Crea un vector dinámico de caracteres. Devuelve un puntero a un vector vacío.
//       Al finalizar este vector debe ser dedinuido con vec_dedinuir().
//       Devuelve NULL si no se pudo crear el vector, en ese caso no hay que destruirlo.
vector_din_t* vec_crear();


// Pre: `vec` fue creado usando vec_crear().
// Post: Dedinuye el vector.
void vec_destruir(vector_din_t* vec);

// Pre: `vec` fue creado usando vec_crear().
// Post: Agrega un caracter (`valor`) al final del vector.
//       Devuelve true si se pudo agregar, false en caso contrario.
bool vec_guardar(vector_din_t* vec, char valor);

// Pre: `vec` fue creado usando vec_crear().
// Post: Devuelve el elemento en la posición `pos` del vector.
//       Si `pos` es inválida, devuelve '\0'.
//       Una posicion es inválida si es mayor o igual al largo del vector.
char vec_obtener(vector_din_t* vec, size_t pos);

// Pre: `vec` fue creado usando vec_crear().
// Post: Devuelve la cantidad de elementos en el vector.
size_t vec_largo(vector_din_t* vec);

// Pre: `vec` fue creado usando vec_crear().
// Post: Elimina el elemento del vector en la posicion deseada (`pos`) reduciendo su largo.
//       Todos los elementos a la derecha de `pos` se desplazan una posición a la izquierda.
//       Si `pos` es inválida, no hace nada.
void vec_eliminar(vector_din_t* vec, size_t pos);

// Pre: `vec` fue creado usando vec_crear().
// Post: Imprime los elementos del vector en orden.
void vec_imprimir(vector_din_t* vec);

#endif // VEC_DIN_H
