#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX_NOMBRE 20

typedef struct fruto {
    char nombre[MAX_NOMBRE];
    bool con_espinas_por_fuera;
    bool es_comestible;
} fruto_t;

void mostrar_frutos(fruto_t* frutos, int tope_frutos) {
    printf("\n\nLos frutos ingresados son:\n\n");
    for(int i = 0; i < tope_frutos; i++) {
        printf("Fruto %i: %s\n", i + 1, frutos[i].nombre);
        printf("Con espinas por fuera: %s\n", frutos[i].con_espinas_por_fuera ? "Si" : "No");
        printf("Es comestible: %s\n\n", frutos[i].es_comestible ? "Si" : "No");
    }
}


void pedir_fruto_eliminar(char nombre[MAX_NOMBRE]) {
    printf("Ingrese el nombre del fruto que desea eliminar: ");
    scanf("%s", nombre);
}

void eliminar_fruto(fruto_t* *frutos, int *tope_frutos, char fruta_eliminar[MAX_NOMBRE]) {
    // creamos el vector auxiliar con uno menos
    fruto_t* auxiliar = malloc(sizeof(fruto_t) * (*tope_frutos -1));

    // copiar la información
    int j = 0;
    for(int i = 0; i < *tope_frutos; i++){
        if(strcmp((*frutos)[i].nombre, fruta_eliminar) != 0) {
            auxiliar[j] = (*frutos)[i];
            j++;
        }
    }
    
    // liberamos el que ya teniamos
    free(*frutos);

    *tope_frutos -= 1;

    // apuntamos el auxiliar al puntero del main
    *frutos = auxiliar;
}

// Crear un programa que dado un vector dinámico de fruto_t pida al usuario el 
// nombre de un fruto existente y lo elimine del vector redimensionando el mismo.
int main() {
    int tope_frutos = 5;
    fruto_t* frutos = malloc(sizeof(fruto_t) * tope_frutos);

    strcpy(frutos[0].nombre, "Opuntia");
    frutos[0].con_espinas_por_fuera = true;
    frutos[0].es_comestible = true;

    strcpy(frutos[1].nombre, "Kiwano");
    frutos[1].con_espinas_por_fuera = true;
    frutos[1].es_comestible = true;

    strcpy(frutos[2].nombre, "Aralia");
    frutos[2].con_espinas_por_fuera = true;
    frutos[2].es_comestible = false;

    strcpy(frutos[3].nombre, "Banana");
    frutos[3].con_espinas_por_fuera = false;
    frutos[3].es_comestible = false;
    
    strcpy(frutos[4].nombre, "Datura");
    frutos[4].con_espinas_por_fuera = true;
    frutos[4].es_comestible = false;

    mostrar_frutos(frutos, tope_frutos);
    char fruta_eliminar[MAX_NOMBRE];
    pedir_fruto_eliminar(fruta_eliminar);

    eliminar_fruto(&frutos, &tope_frutos, fruta_eliminar);
    mostrar_frutos(frutos, tope_frutos);

    free(frutos);

    return 0;
}