#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX_NOMBRE 20

typedef struct fruto {
    char nombre[MAX_NOMBRE];
    bool con_espinas_por_fuera;
    bool es_comestible;
} fruto_t;

void mostrar_frutos(fruto_t* frutos, int tope_frutos) {
    printf("\n\nLos frutos ingresados son:\n\n");
    for(int i = 0; i < tope_frutos; i++) {
        printf("Fruto %i: %s\n", i + 1, frutos[i].nombre);
        printf("Con espinas por fuera: %s\n", frutos[i].con_espinas_por_fuera ? "Si" : "No");
        printf("Es comestible: %s\n\n", frutos[i].es_comestible ? "Si" : "No");
    }
}


void pedir_fruto_agregar(fruto_t *nuevo) {
    printf("\nIngrese el nombre del fruto:\n");
    scanf("%s", nuevo->nombre);
    
    int rta_aux;
    printf("El fruto \"%s\" tiene espinas por fuera? (1 para si, 0 para no): ", nuevo->nombre);
    scanf("%i", &rta_aux);
    nuevo->con_espinas_por_fuera = rta_aux == 0 ? false : true;

    printf("El fruto \"%s\" es comestible? (1 para si, 0 para no): ", nuevo->nombre);
    scanf("%i", &rta_aux);
    nuevo->es_comestible = rta_aux == 0 ? false : true;
}

void agregar_fruto(fruto_t* *frutos, int *tope_frutos, fruto_t nuevo) {
    *frutos = realloc(*frutos, sizeof(fruto_t) * (*tope_frutos + 1));
    (*frutos)[*tope_frutos] = nuevo;
    *tope_frutos += 1;
}

// Crear un programa que dado un vector dinámico de fruto_t pida al usuario los datos 
// de un nuevo fruto y lo agregue al vector redimensionando el mismo.
int main() {
    int tope_frutos = 5;
    fruto_t* frutos = malloc(sizeof(fruto_t) * tope_frutos);

    strcpy(frutos[0].nombre, "Opuntia");
    frutos[0].con_espinas_por_fuera = true;
    frutos[0].es_comestible = true;

    strcpy(frutos[1].nombre, "Kiwano");
    frutos[1].con_espinas_por_fuera = true;
    frutos[1].es_comestible = true;

    strcpy(frutos[2].nombre, "Aralia");
    frutos[2].con_espinas_por_fuera = true;
    frutos[2].es_comestible = false;

    strcpy(frutos[3].nombre, "Banana");
    frutos[3].con_espinas_por_fuera = false;
    frutos[3].es_comestible = false;
    
    strcpy(frutos[4].nombre, "Datura");
    frutos[4].con_espinas_por_fuera = true;
    frutos[4].es_comestible = false;

    mostrar_frutos(frutos, tope_frutos);
    fruto_t nuevo;
    pedir_fruto_agregar(&nuevo);

    agregar_fruto(&frutos, &tope_frutos, nuevo);
    mostrar_frutos(frutos, tope_frutos);

    free(frutos);

    return 0;
}