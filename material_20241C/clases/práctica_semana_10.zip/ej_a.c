#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX_NOMBRE 20

typedef struct fruto {
    char nombre[MAX_NOMBRE];
    bool con_espinas_por_fuera;
    bool es_comestible;
} fruto_t;

void mostrar_frutos(fruto_t* frutos, int tope_frutos) {
    printf("\n\nLos frutos ingresados son:\n\n");
    for(int i = 0; i < tope_frutos; i++) {
        printf("Fruto %i: %s\n", i + 1, frutos[i].nombre);
        printf("Con espinas por fuera: %s\n", frutos[i].con_espinas_por_fuera ? "Si" : "No");
        printf("Es comestible: %s\n\n", frutos[i].es_comestible ? "Si" : "No");
    }
}

// fruto_t* frutos -> puntero del tipo fruto_t
// fruto_t *frutos -> referencia a una variable del tipo fruto_t
// fruto_t* *frutos -> referencia a un puntero del tipo fruto_t
void pedir_frutos(fruto_t* *frutos, int *cantidad_frutos) {
    printf("Ingrese la cantidad de frutos:\n");
    scanf("%i", cantidad_frutos);

    *frutos = malloc(sizeof(fruto_t) * (*cantidad_frutos));
    
    for(int i = 0; i < (*cantidad_frutos); i++){
        printf("\nIngrese el nombre del fruto %i: ", i + 1);
        scanf("%s", (*frutos)[i].nombre);
        
        int rta_aux;
        printf("El fruto \"%s\" tiene espinas por fuera? (1 para si, 0 para no): ", (*frutos)[i].nombre);
        scanf("%i", &rta_aux);
        (*frutos)[i].con_espinas_por_fuera = rta_aux == 0 ? false : true;

        printf("El fruto \"%s\" es comestible? (1 para si, 0 para no): ", (*frutos)[i].nombre);
        scanf("%i", &rta_aux);
        (*frutos)[i].es_comestible = rta_aux == 0 ? false : true;
    }
}


int main() {
    int cantidad_frutos = 0;
    fruto_t* frutos = NULL;

    pedir_frutos(&frutos, &cantidad_frutos);

    mostrar_frutos(frutos, cantidad_frutos);

    if(frutos != NULL)
        free(frutos);

    return 0;
}