#include <stdio.h>
#include <stdbool.h>

#define MAX_DESCRIPCION 100
#define MAX_MISIONES 20

typedef struct mision {
    int id;
    int prioridad;
    char descripcion[MAX_DESCRIPCION];
} mision_t;

// [1 2 4 36 59 100]
const int NO_ESTA = -2;
const int NO_ENCONTRADA = -1;

int buscar_recursivamente_mision(mision_t misiones[MAX_MISIONES], int tope, int prioridad_buscada, int inicio, int fin) {
    int centro = (inicio + fin) / 2;

    // condicion de corte -> para el final (?
    if(misiones[centro].prioridad == prioridad_buscada){
        return centro;
    }
    else if(fin < inicio) {
        return NO_ESTA;
    }

    // procesamiento
    if(misiones[centro].prioridad > prioridad_buscada) {
        fin = centro - 1;
    }
    else {
        inicio = centro + 1;
    }

    // llamado recursivo
    return buscar_recursivamente_mision(misiones, tope, prioridad_buscada, inicio, fin);
}

int buscar_mision(mision_t misiones[MAX_MISIONES], int tope, int prioridad_buscada) {
    int inicio = 0;
    int fin = tope-1;
    int centro = (inicio + fin) / 2;

    while(misiones[centro].prioridad != prioridad_buscada && fin >= inicio) {
        if(misiones[centro].prioridad > prioridad_buscada) {
            fin = centro - 1;
        }
        else {
            inicio = centro + 1;
        }

        centro = (inicio + fin) / 2;
    }

    if(misiones[centro].prioridad == prioridad_buscada)
        return centro;

    return NO_ESTA;
}


// Crear una función que reciba un vector de mision_t ordenado 
// ascendentemente por prioridad, su tope y una nueva misión y 
// la agregue al mismo manteniendo el orden.
void mover_elementos(mision_t misiones[MAX_MISIONES], int *tope, int inicio_corrimiento) {
    (*tope)++;

    for(int i = (*tope)-2; i >= inicio_corrimiento; i--) {
        misiones[i+1] = misiones[i]; 
    }
}

int posicion_a_agregar(mision_t misiones[MAX_MISIONES], int tope, int prioridad_a_agregar) {
    int i = 0;
    bool encontrado = false;
    int posicion_buscada = NO_ENCONTRADA;
    while(i< tope && !encontrado){
        if(misiones[i].prioridad > prioridad_a_agregar){
            posicion_buscada = i;
            encontrado = true;
        }
        i++;
    }

    return posicion_buscada;
}

void insertar_mision(mision_t misiones[MAX_MISIONES], int* tope, mision_t mision_nueva){
    int pos_buscada = buscar_mision(misiones, *tope, mision_nueva.prioridad);
    if(pos_buscada == NO_ESTA){
        int posicion_insertar = posicion_a_agregar(misiones, *tope, mision_nueva.prioridad);
        mover_elementos(misiones, tope, posicion_insertar);
        //agrego la mision
        misiones[posicion_insertar] = mision_nueva;
    }
}

void insercion_mision(mision_t misiones[MAX_MISIONES], int* tope, mision_t mision_nueva){
    int i = (*tope)-1;
    while(i >= 0 && misiones[i].prioridad > mision_nueva.prioridad){
        misiones[i+1] = misiones[i]; 
        i--;
    }

    misiones[i+1] = mision_nueva;
    (*tope)++;
}

void imprimir_misiones(mision_t misiones[MAX_MISIONES], int tope){
    for(int i = 0; i< tope; i++){
        printf("Mision de prioridad %i\n", misiones[i].prioridad);
    }
}


int main() {
    mision_t misiones[MAX_MISIONES] = {
        {0, 1, "Hacer el tp2 sin CHATGPT"},
        {1, 4, "Conquistar Disney porque somos CN"},
        {2, 8, "Matar a Perry"},
        {3, 20, "No usar return dentro de while"},
        {4, 41, "Conquistar Discovery Channel porque somos CN"},
        {5, 67, "Plantar un arbol"},
        {6, 69, "Conquistar Nickelodeon porque somos CN"},
        {7, 77, "Que Tomy aprenda que no somos de Disney"},
        {8, 92, "No compartir codigo"},
        {9, 100, "Traer torta en mi cumpleaños"},
    };
    int tope = 10;

    // imprimir_misiones(misiones, tope);
    // mision_t mision_nueva = {10, 80, "Nueva mision"};
    // insercion_mision(misiones, &tope, mision_nueva);
    // printf("\n\n\n");
    // imprimir_misiones(misiones, tope);

    imprimir_misiones(misiones, tope);
    int pos_buscada = buscar_recursivamente_mision(misiones, tope, 77, 0, tope-1);
    if(pos_buscada == NO_ESTA) {
        printf("ufa no esta");
    }
    else {
        printf("la mision esta en la pos %i", pos_buscada);
    }
    
    return 0;
}