#define MAX 100

// pre: la suma de ambos topes no sera mayor a 100, los vectores estan ordenados ascendentemente
// post: llena el vector resultados de forma ordenada ascendentemente con la mezcla de ambos vectores de recuerdos 
void mezclar_recuerdos(int recuerdos_1[MAX], int tope_1, int recuerdos_2[MAX], int tope_2, int resultado[MAX], int* tope_resultado){
    int i = 0;
    int j = 0;
    (*tope_resultado) = 0;

    while(i < tope_1 && j < tope_2){
        if(recuerdos_1[i] < recuerdos_2[j]){
            resultado[(*tope_resultado)] = recuerdos_1[i];
            i++;
        }else if(recuerdos_1[i] > recuerdos_2[j]){
            resultado[(*tope_resultado)] = recuerdos_2[j];
            j++;
        }else{
            resultado[(*tope_resultado)] = recuerdos_1[i];
            i++;
            (*tope_resultado)++;
            resultado[(*tope_resultado)] = recuerdos_2[j];
            j++;
        }
        (*tope_resultado)++;
    }

    while(i < tope_1){
        resultado[(*tope_resultado)] = recuerdos_1[i];
        i++;
        (*tope_resultado)++;
    }

    while(j < tope_2){
        resultado[(*tope_resultado)] = recuerdos_2[j];
        j++;
        (*tope_resultado)++;
    }
}

void unir_recuerdos(int recuerdos_1[MAX], int tope_1, int recuerdos_2[MAX], int tope_2, int resultado[MAX], int* tope_resultado){
    int i = 0;
    int j = 0;
    (*tope_resultado) = 0;

    while(i < tope_1 && j < tope_2){
        if(recuerdos_1[i] < recuerdos_2[j]){
            resultado[(*tope_resultado)] = recuerdos_1[i];
            i++;
        }else if(recuerdos_1[i] > recuerdos_2[j]){
            resultado[(*tope_resultado)] = recuerdos_2[j];
            j++;
        }else{
            resultado[(*tope_resultado)] = recuerdos_1[i];
            i++;
            j++;
        }
        (*tope_resultado)++;
    }

    while(i < tope_1){
        resultado[(*tope_resultado)] = recuerdos_1[i];
        i++;
        (*tope_resultado)++;
    }

    while(j < tope_2){
        resultado[(*tope_resultado)] = recuerdos_2[j];
        j++;
        (*tope_resultado)++;
    }
}

void intersecar_recuerdos(int recuerdos_1[MAX], int tope_1, int recuerdos_2[MAX], int tope_2, int resultado[MAX], int* tope_resultado){
    int i = 0;
    int j = 0;
    (*tope_resultado) = 0;

    while(i < tope_1 && j < tope_2){
        if(recuerdos_1[i] < recuerdos_2[j]){
            i++;
        }else if(recuerdos_1[i] > recuerdos_2[j]){
            j++;
        }else{
            resultado[(*tope_resultado)] = recuerdos_1[i];
            i++;
            j++;
            (*tope_resultado)++;
        }
    } 
}

void dif_sim_recuerdos(int recuerdos_1[MAX], int tope_1, int recuerdos_2[MAX], int tope_2, int resultado[MAX], int* tope_resultado){
    int i = 0;
    int j = 0;
    (*tope_resultado) = 0;

    while(i < tope_1 && j < tope_2){
        if(recuerdos_1[i] < recuerdos_2[j]){
            resultado[(*tope_resultado)] = recuerdos_1[i];
            i++;
            (*tope_resultado)++;
        }else if(recuerdos_1[i] > recuerdos_2[j]){
            resultado[(*tope_resultado)] = recuerdos_2[j];
            j++;
            (*tope_resultado)++;
        }else{
            i++;
            j++;
        }
    }

    while(i < tope_1){
        resultado[(*tope_resultado)] = recuerdos_1[i];
        i++;
        (*tope_resultado)++;
    }

    while(j < tope_2){
        resultado[(*tope_resultado)] = recuerdos_2[j];
        j++;
        (*tope_resultado)++;
    }
}

void dif_asim_recuerdos(int recuerdos_1[MAX], int tope_1, int recuerdos_2[MAX], int tope_2, int resultado[MAX], int* tope_resultado){
    int i = 0;
    int j = 0;
    (*tope_resultado) = 0;

    while(i < tope_1 && j < tope_2){
        if(recuerdos_1[i] < recuerdos_2[j]){
            resultado[(*tope_resultado)] = recuerdos_1[i];
            i++;
            (*tope_resultado)++;
        }else if(recuerdos_1[i] > recuerdos_2[j]){
            j++;
        }else{
            i++;
            j++;
        }
    }

    while(i < tope_1){
        resultado[(*tope_resultado)] = recuerdos_1[i];
        i++;
        (*tope_resultado)++;
    }
}