#include <stdio.h>

#define MAX_CARTAS 10

void ordenar_por_insercion(int cartas[MAX_CARTAS], int tope_cartas) {
    for(int i = 1; i < tope_cartas; i++){
        int j = i;
        while(cartas[j] < cartas[j-1] && j>0){
            int aux = cartas[j];
            cartas[j] = cartas[j - 1];
            cartas[j -1] =aux;
            j--;
        }
    }
}

void imprimir_cartas(int cartas[MAX_CARTAS], int tope_cartas) {
    for (int i = 0; i < tope_cartas; i++) {
        printf("%i  ", cartas[i]);
    }
    printf("\n");
}

int main() {
    int cartas [MAX_CARTAS] = {2, 5, 1, 7, 11, 3};
    int tope_cartas = 6;
    
    imprimir_cartas(cartas, tope_cartas);
    ordenar_por_insercion(cartas, tope_cartas);
    imprimir_cartas(cartas, tope_cartas);

    return 0;
}