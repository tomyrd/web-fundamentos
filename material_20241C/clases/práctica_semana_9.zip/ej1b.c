

#include <stdio.h>
#include <string.h>

#define MAX_ENANITOS 7
#define MAX_NOMBRE 20

typedef struct enanito {
   int id;
   char nombre[MAX_NOMBRE];
   int edad;
   int dias_desde_el_ultimo_chequeo;
} enanito_t;

void ordenar_por_dias_chequeo(enanito_t enanitos[MAX_ENANITOS], int tope_enanitos) {
    for(int i = 0; i < tope_enanitos - 1; i++) { // cantidad de veces que burbujea el minimo
        for(int j = 0; j < tope_enanitos - i - 1; j++) {
            if(enanitos[j].dias_desde_el_ultimo_chequeo < enanitos[j + 1].dias_desde_el_ultimo_chequeo) {
                enanito_t temporal;
                temporal = enanitos[j];
                enanitos[j] = enanitos[j + 1];
                enanitos[j + 1] = temporal;
            }
            else if(enanitos[j].dias_desde_el_ultimo_chequeo == enanitos[j + 1].dias_desde_el_ultimo_chequeo) {
                if(enanitos[j].edad < enanitos[j + 1].edad) {
                    enanito_t temporal;
                    temporal = enanitos[j];
                    enanitos[j] = enanitos[j + 1];
                    enanitos[j + 1] = temporal;
                }
            }
        }
    }
}


int main() {
    enanito_t enanitos[MAX_ENANITOS];
    enanitos[0].id = 1;
    strcpy(enanitos[0].nombre, "Sabio");
    enanitos[0].edad = 61;
    enanitos[0].dias_desde_el_ultimo_chequeo = 10;
    
    enanitos[1].id = 2;
    strcpy(enanitos[1].nombre, "Mocoso");
    enanitos[1].edad = 14;
    enanitos[1].dias_desde_el_ultimo_chequeo = 56;
    
    enanitos[2].id = 3;
    strcpy(enanitos[2].nombre, "Gruñón");
    enanitos[2].edad = 70;
    enanitos[2].dias_desde_el_ultimo_chequeo = 10;
    
    enanitos[3].id = 4;
    strcpy(enanitos[3].nombre, "Feliz");
    enanitos[3].edad = 26;
    enanitos[3].dias_desde_el_ultimo_chequeo = 30;
    
    enanitos[4].id = 5;
    strcpy(enanitos[4].nombre, "Tímido");
    enanitos[4].edad = 34;
    enanitos[4].dias_desde_el_ultimo_chequeo = 14;
    
    enanitos[0].id = 6;
    strcpy(enanitos[5].nombre, "Dormilón");
    enanitos[5].edad = 61;
    enanitos[5].dias_desde_el_ultimo_chequeo = 56;

    enanitos[6].id = 7;
    strcpy(enanitos[6].nombre, "Mudito");
    enanitos[6].edad = 61;
    enanitos[6].dias_desde_el_ultimo_chequeo = 32;

    int tope_enanitos = MAX_ENANITOS; 

    for (int i = 0; i < tope_enanitos; i++) {
        printf("%s tiene %i años y se chequó hace %i días\n", enanitos[i].nombre, enanitos[i].edad, enanitos[i].dias_desde_el_ultimo_chequeo);
    }

    ordenar_por_dias_chequeo(enanitos, tope_enanitos);

    printf("\n\n");
    for (int i = 0; i < tope_enanitos; i++) {
        printf("%s tiene %i años y se chequó hace %i días\n", enanitos[i].nombre, enanitos[i].edad, enanitos[i].dias_desde_el_ultimo_chequeo);
    }
    return 0;
}