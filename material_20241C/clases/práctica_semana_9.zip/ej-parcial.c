#include <stdio.h>

#define FILAS 10
#define COLUMNAS 7

/*
PRE:

POST:

*/
void actualizar_maximo(int puntos_enanito, int i, int* puntaje_max, int* enanito_ganador){
    if(puntos_enanito > *puntaje_max){
        *puntaje_max = puntos_enanito;
        *enanito_ganador = i+1;
    }
}


/*
PRE:
Recibe una matriz de puntajes de tamaño 10x7 que representa en las filas
partidas y en las columnas enanitos.
Los topes están correctamente cargados para recorrer la matriz.

POST:
- Si la matriz está vacía, devuelve 0 como ganador, significando que no ganó nadie
- En caso contrario devuelve el numero de enanito con mayor puntaje total
*/
int enanito_ganador(int puntajes[FILAS][COLUMNAS], int tope_fil, int tope_col){
    int puntaje_max = 0;
    int enanito_ganador = 0;
    
    for(int i = 0; i < tope_col; i++){ //recorre por enanito
        int puntos_enanito = 0;
        for(int j = 0; j < tope_fil; j++){ //recorre las partidas por enanito
            puntos_enanito += puntajes[j][i];
        }
        actualizar_maximo(puntos_enanito, i, &puntaje_max, &enanito_ganador);
    }

    return enanito_ganador;
}



int main() {
    int matriz[FILAS][COLUMNAS] = {
        {10, 8, 5, 12, 20, 18, 9},
        {15, 12, 10, 14, 30, 22, 18},
        {20, 16, 15, 16, 40, 26, 27},
        {25, 20, 20, 18, 50, 30, 36},
        {30, 24, 25, 20, 60, 34, 45},
        {35, 28, 30, 22, 70, 38, 54},
        {40, 32, 35, 24, 80, 42, 63},
        {45, 36, 40, 26, 90, 46, 72},
        {50, 40, 45, 28, 100, 50, 81},
        {55, 44, 50, 30, 110, 54, 90}
    };

    printf("El enanito con más puntos es el número %d\n", enanito_ganador(matriz, FILAS, COLUMNAS));

    return 0;
}