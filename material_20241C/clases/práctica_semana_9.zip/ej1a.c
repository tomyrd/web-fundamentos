#include <stdio.h>
#include <string.h>

#define MAX_ENANITOS 7
#define MAX_NOMBRE 20

void ordenar_alfabeticamente_por_seleccion(char enanitos[MAX_ENANITOS][MAX_NOMBRE], int tope_enanitos) {
    for(int i = 0; i < tope_enanitos - 1; i++) { // cantidad de veces que buscamos minimo
        int minimo = i;

        for(int j = i + 1; j < tope_enanitos; j++) {
            // < 0 -> el primer argumento es alfabeticamente menor
            // == 0 son iguales
            // > 0 -> el segundo argumento es alfabeticamente menor
            if(strcmp(enanitos[j], enanitos[minimo]) < 0) {
                minimo = j;
            }    
        }

        char temporal[MAX_NOMBRE];
        strcpy(temporal, enanitos[i]);
        strcpy(enanitos[i], enanitos[minimo]);
        strcpy(enanitos[minimo], temporal);
    }
}

int main() {
    char enanitos[MAX_ENANITOS][MAX_NOMBRE];
    strcpy(enanitos[0], "Sabio");
    strcpy(enanitos[1], "Mocoso");
    strcpy(enanitos[2], "Gruñón");
    strcpy(enanitos[3], "Feliz");
    strcpy(enanitos[4], "Tímido");
    strcpy(enanitos[5], "Dormilón");
    strcpy(enanitos[6], "Mudito");
    int tope_enanitos = MAX_ENANITOS; 

    for (int i = 0; i < tope_enanitos; i++) {
        printf("%s\n", enanitos[i]);
    }

    ordenar_alfabeticamente_por_seleccion(enanitos, tope_enanitos);
    printf("\n\n");
    for (int i = 0; i < tope_enanitos; i++) {
        printf("%s\n", enanitos[i]);
    }

    return 0;
}