#include "vector_din.h"
#include <stdbool.h>
#include <stdlib.h>

struct vector_din{
    size_t tope; // size_t == unsigned_int
    mascota_t *mascotas; // Va a apuntar a nuestro vector en el heap
};


vector_din_t* vec_crear(){
    vector_din_t* vector = malloc(sizeof(vector_din_t));
    if (vector == NULL){
        return NULL;
    }

    vector->tope = 0;
    vector->mascotas = NULL;

    return vector;
}

bool vec_guardar(vector_din_t* vec, mascota_t mascota){
    if(vec->mascotas == NULL) {
        // Es la primera mascota
        vec->mascotas = malloc(sizeof(mascota_t));
        if (vec->mascotas == NULL){
            return false;
        }

        vec->mascotas[0] = mascota;
        vec->tope++;
    } else {
        // Caso general
        vec->mascotas = realloc(vec->mascotas, sizeof(mascota_t)*((vec->tope) + 1));
        vec->mascotas[vec->tope] = mascota;
        vec->tope++;
    }

    return true;
}

void vec_destruir(vector_din_t* vec){
    free(vec->mascotas);
    free(vec);
}

size_t vec_largo(vector_din_t* vec){
    return vec->tope;
}

mascota_t* vec_obtener(vector_din_t* vec, size_t pos){
    if (pos > vec->tope){
        return NULL;
    }

    return &vec->mascotas[pos];
}
