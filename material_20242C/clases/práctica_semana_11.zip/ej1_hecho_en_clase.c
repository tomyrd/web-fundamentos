#include <stdio.h>
#include <stdlib.h>


typedef struct mascota {
    char animal;
    int edad;
} mascota_t;

typedef struct hogar {
    int cant_mascotas;
    mascota_t *mascotas;
} hogar_t;


#define ERROR_RESERVAR_MEMORIA -1


/* Pre condiciones: 'hogares' debe apuntar a una dirección de memoria de donde esten reservados n 'hogar_t's siendo n 'tope_hogares'.
 * Post condiciones: Imprime por pantalla los datos de los 'hogar_t's.
 */
void mostrar_hogares(hogar_t* hogares, int tope_hogares) {
    for(int i = 0; i < tope_hogares; i++){
        printf("El alumno %i tiene %i mascotas y son:\n", i+1, hogares[i].cant_mascotas);
        for(int j = 0; j < hogares[i].cant_mascotas; j++) {
            printf("\t\tMascota %i es: %c | Edad: %i\n", j+1, hogares[i].mascotas[j].animal, hogares[i].mascotas[j].edad);        
        }
    }

    printf("\n");
}


int main () {
    int cantidad_alumnos;
    printf("ingrese la cantidad de alumnos:\n");
    scanf("%i", &cantidad_alumnos);
    while(cantidad_alumnos <= 0) {
        printf("ingrese la cantidad de alumnos:\n");
        scanf("%i", &cantidad_alumnos);
    }

    hogar_t* hogares_alumnos;
    hogares_alumnos = malloc(sizeof(hogar_t) * cantidad_alumnos);
    if(hogares_alumnos == NULL) {
        printf("Hubo un error al reservar memoria\n");
        return ERROR_RESERVAR_MEMORIA;
    }

    for(int i = 0; i < cantidad_alumnos; i++){
        printf("ALUMNO %i: ingrese la cantidad de mascotas:\n", i+1);
        scanf("%i", &(hogares_alumnos[i].cant_mascotas));
        while(hogares_alumnos[i].cant_mascotas <= 0) {
            printf("Cantidad de mascota negativa! Intente de nuevo\n");
            printf("ALUMNO %i: ingrese la cantidad de mascotas:\n", i+1);
            scanf("%i", &(hogares_alumnos[i].cant_mascotas));
        }

        // '*(hogares_alumnos + i).' es equivalente a '(hogares_alumnos + i)->'
        // (hogares_alumnos + i)->mascotas = malloc(sizeof(mascota_t) * cantidad_mascotas);
        hogares_alumnos[i].mascotas = malloc(sizeof(mascota_t) * hogares_alumnos[i].cant_mascotas);
        if(hogares_alumnos[i].mascotas == NULL){
            printf("Hubo un error al reservar memoria\n");
            
            for(int k = 0; k < i; k++){ 
                free(hogares_alumnos[k].mascotas);
            }
            
            free(hogares_alumnos);
            return ERROR_RESERVAR_MEMORIA;
        }
        
        for(int j = 0; j < hogares_alumnos[i].cant_mascotas; j++) {
            printf("ALUMNO %i: ingrese tipo/animal de su mascotas %i:\n", i+1, j+1);
            scanf(" %c", &(hogares_alumnos[i].mascotas[j].animal));

            printf("ALUMNO %i: edad de su mascotas %i:\n", i+1, j+1);
            scanf("%i", &(hogares_alumnos[i].mascotas[j].edad));
        }
    }

    mostrar_hogares(hogares_alumnos, cantidad_alumnos);
    
    free(hogares_alumnos);

    for(int i = 0; i < cantidad_alumnos; i++){ 
        free(hogares_alumnos[i].mascotas);
    }

    return 0;
}