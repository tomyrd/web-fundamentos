import csv
import os

NOMBRE_ARCH_PROD = 'todas_prods.csv'
NOMBRE_ARCH_NUEVAS = 'nuevas_prods.csv'
NOMBRE_PROD_AUXILIAR = 'prods_aux.csv'
MODO_LECTURA = 'r'
MODO_ESCRITURA = 'w'
POS_NOMBRE = 1

def actualizar_producciones():
    try:
        arch_producciones = open(NOMBRE_ARCH_PROD, MODO_LECTURA)
    except: 
        print('Error abriendo el archivo de las producciones')
        return
    
    try:
        arch_producciones_nuevas = open(NOMBRE_ARCH_NUEVAS, MODO_LECTURA)
    except: 
        print('Error abriendo el archivo de las producciones nuevas')
        arch_producciones.close()
        return
    
    try:
        arch_auxiliar = open(NOMBRE_PROD_AUXILIAR, MODO_ESCRITURA)
    except: 
        print('Error abriendo el archivo de las producciones auxiliar')
        arch_producciones.close()
        arch_producciones_nuevas.close()
        return

    # lo podemos guardar en memoria porque sabemos que son POCAS
    reader_nuevas = csv.reader(arch_producciones_nuevas, delimiter=';')
    nuevas_prods = list(reader_nuevas) # con esto guardo toda la información en memoria

    reader_prods = csv.reader(arch_producciones, delimiter=';')

    prods_writer = csv.writer(arch_auxiliar, delimiter=';')

    for prod in reader_prods:
        prod_nueva = nuevas_prods[0]
        while prod_nueva[POS_NOMBRE] < prod[POS_NOMBRE]:
            prods_writer.writerow(prod_nueva)
            nuevas_prods.pop(0)
            prod_nueva = nuevas_prods[0]
        prods_writer.writerow(prod)


    arch_auxiliar.close()
    arch_producciones.close()
    arch_producciones_nuevas.close()

    os.rename(NOMBRE_PROD_AUXILIAR, NOMBRE_ARCH_PROD)



if __name__ == '__main__':
    actualizar_producciones()