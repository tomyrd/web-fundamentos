import os
import csv

MOUSKEHERRAMIENTAS = 'mouskeherramientas.csv'
ULTIMA_AVENTURA = 'ultima_aventura.csv'
ARCHIVO_AUXILIAR = 'aux.csv'

MODO_LECTURA = 'r'
MODO_ESCRITURA = 'w'


ID = 0
FUE_UTILIZADA = 1
HERRAMIENTA_UTILIZADA = 1


# Dado los dos archivos con cantidades de Mouskeherramientas que NO entran en memoria, crear una función que actualice el archivo de  Mouskeherramientas nunca utilizadas.
def actualizar_mouskeherramientas():
    try:
        mouskeherramientas_file = open(MOUSKEHERRAMIENTAS, MODO_LECTURA)
    except:
        print(f"Error al intentar abrir el archivo {MOUSKEHERRAMIENTAS}")
        return
    
    try:
        ultima_aventura_file = open(ULTIMA_AVENTURA, MODO_LECTURA)
    except:
        print(f"Error al intentar abrir el archivo {ULTIMA_AVENTURA}")
        mouskeherramientas_file.close()
        return
    
    try:
        aux_file = open(ARCHIVO_AUXILIAR, MODO_ESCRITURA)
    except:
        print(f"Error al intentar abrir el archivo {ARCHIVO_AUXILIAR}")
        mouskeherramientas_file.close()
        ultima_aventura_file.close()
        return

    mouskeherramientas_reader = csv.reader(mouskeherramientas_file, delimiter='-')
    ultima_aventura_reader = csv.reader(ultima_aventura_file, delimiter='-')
    writer = csv.writer(aux_file, delimiter='-')
    
    for mh in mouskeherramientas_reader:
        fue_usada = False
        for ua in ultima_aventura_reader:
            if ua[ID] == mh[ID] and int(ua[FUE_UTILIZADA]) == HERRAMIENTA_UTILIZADA:
                fue_usada = True
        
        ultima_aventura_file.seek(0)

        if not fue_usada:
            writer.writerow(mh)


    mouskeherramientas_file.close()
    ultima_aventura_file.close()
    aux_file.close()

    os.rename(ARCHIVO_AUXILIAR, MOUSKEHERRAMIENTAS)


if __name__ == "__main__":
    actualizar_mouskeherramientas()