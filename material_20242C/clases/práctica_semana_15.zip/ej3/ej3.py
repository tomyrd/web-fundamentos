import csv


ARCHIVO_HOBBIES_ANNIE = "hobbies_annie.csv"
ARCHIVO_HOBBIES_HALLIE = "hobbies_hallie.csv"
ARCHIVO_NUEVOS_HOBBIES = "nuevos_hobbies.csv"

MODO_LECTURA = "r"
MODO_ESCRITURA = "w"

IDX_NOMBRE=0
IDX_PUNTAJE=1

PUNTAJE_MIN = 7

# Pre: El archivo tiene la estructura "nombre_hobbie,puntaje"
# Post: Devuelve true si el hobby está en el archivo
def hay_hobbie_en_archivo(nombre_hobby, nombre_archivo):
    with open(nombre_archivo, MODO_LECTURA) as archivo_hobbies:
        reader = csv.reader(archivo_hobbies, delimiter=",")

        encontrado = False

        for hobby in reader:
            if nombre_hobby == hobby[IDX_NOMBRE]:
                encontrado = True

        return encontrado

def agregar_hobbies_diferentes(reader_hobbies, writer, nombre_archivo_opuesto):
    for hobby in reader_hobbies:
        if not hay_hobbie_en_archivo(hobby[IDX_NOMBRE], nombre_archivo_opuesto) and int(hobby[IDX_PUNTAJE]) > PUNTAJE_MIN:
            writer.writerow(hobby)

def hobbies_a_probar():
    try:
        hobbies_annie = open(ARCHIVO_HOBBIES_ANNIE, MODO_LECTURA)
    except:
        print("Hubo un problema al abrir el archivo de annie")
        return

    try:
        hobbies_hallie = open(ARCHIVO_HOBBIES_HALLIE, MODO_LECTURA)
    except:
        hobbies_annie.close()
        print("Hubo un problema al abrir el archivo de hallie")
        return

    try:
        nuevos_hobbies = open(ARCHIVO_NUEVOS_HOBBIES, MODO_ESCRITURA)
    except:
        hobbies_hallie.close()
        hobbies_annie.close()
        print("Hubo un problema al abrir el archivo de hallie")
        return

    # PROCESAMIENTO

    reader_annie = csv.reader(hobbies_annie, delimiter=",")
    reader_hallie = csv.reader(hobbies_hallie, delimiter=",")
    writer_nuevos_hobbies = csv.writer(nuevos_hobbies, delimiter=",")


    agregar_hobbies_diferentes(reader_annie, writer_nuevos_hobbies, ARCHIVO_HOBBIES_HALLIE)

    agregar_hobbies_diferentes(reader_hallie, writer_nuevos_hobbies, ARCHIVO_HOBBIES_ANNIE)

    hobbies_hallie.close()
    hobbies_annie.close()
    nuevos_hobbies.close()


if __name__ == "__main__":
    hobbies_a_probar()
