#include <stdio.h>

const char BUENO = 'B';

int main(){
    int respuesta_mickey;
    printf("Micky devuélveme mi dinero que tengo que cargar la sube. Ingresa B para que te deje de pedir\n");
    scanf(" %c", &respuesta_mickey);

    while(respuesta_mickey != BUENO){
        printf("Micky devuélveme mi dinero que tengo que cargar la sube. Ingresa B para que te deje de pedir\n");
        scanf(" %c", &respuesta_mickey);
    }

    // do{
    //     printf("Micky devuélveme mi dinero que tengo que cargar la sube. Ingresa B para que te deje de pedir\n");
    //     scanf(" %c", &respuesta_mickey);
    // }while(respuesta_mickey != BUENO);

    return 0;
}