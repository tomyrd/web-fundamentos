#include <stdio.h>

const int PRECIO_CHOCOLATE = 2000;
const int PRECIO_GOMITAS = 1000;

int main(){ 
    int dinero_mickey = -1;
    int dinero_donald = -1;
    int dinero_goofy = -1;

    printf("ingrese dinero de mickey:");
    scanf("%i", &dinero_mickey);
    printf("ingrese dinero de donald: \n");
    scanf("%i", &dinero_donald);
    printf("ingrese dinero de goofy: \n");
    scanf("%i", &dinero_goofy);
    
    int total_dinero = dinero_donald + dinero_goofy + dinero_mickey;

    if(total_dinero >= (PRECIO_CHOCOLATE + PRECIO_GOMITAS)){
        printf("¡Wii nos alcanza para el choco y las gomitas!");
    }else if(total_dinero >= PRECIO_CHOCOLATE && total_dinero < (PRECIO_CHOCOLATE + PRECIO_GOMITAS)){
        printf("Que bien, nos alcanzó para el chocolate");
    }else if(total_dinero >= PRECIO_GOMITAS && total_dinero < PRECIO_CHOCOLATE){
        printf("Buee, por lo menos nos alcanzó para las gomitas");
    }else{
        printf("Ufaaa no nos alcanza pa naaa :( ¿Y si pedimos un préstamo en m#Q*$?");
    }

    return 0;
}