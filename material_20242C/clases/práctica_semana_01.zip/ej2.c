#include <stdio.h>

const int DINERO_OBJETIVO = 3000;

int main(){
    int dinero_abuela = -1;
    printf("abuelita cuanta bishusha me vas a dar por cada chow? \n");
    scanf("%i", &dinero_abuela);

    int cant_chows = DINERO_OBJETIVO / dinero_abuela;

    for(int i = 0; i < cant_chows; i++){
        printf("Yo sé que algunas veces me equivoco demasiado ¡HYUCK!\n");
        printf("Yo sé que estás cansada de mirarme de costado ¡HYUCK!\n");
        printf("%i \n", i);
    }
    return 0;
}